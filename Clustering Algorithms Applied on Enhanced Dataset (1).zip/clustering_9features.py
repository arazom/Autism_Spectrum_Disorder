import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score, calinski_harabasz_score, davies_bouldin_score,
    adjusted_rand_score, normalized_mutual_info_score,
    confusion_matrix, classification_report, silhouette_samples
)
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.optimize import linear_sum_assignment
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. LOAD AND PREPARE DATA (9 Features)
# ============================================================
print("=" * 70)
print("STEP 1: Loading and Preparing Data (9 Features)")
print("=" * 70)

df = pd.read_excel('/home/ubuntu/upload/From_61_9_Features.xlsx')
df.columns = df.columns.str.strip()

true_labels = df['Class'].values
feature_cols = [c for c in df.columns if c != 'Class']
X = df[feature_cols].values

print(f"Dataset: {X.shape[0]} samples, {X.shape[1]} features")
print(f"Features: {feature_cols}")
print(f"True class distribution: {dict(zip(*np.unique(true_labels, return_counts=True)))}")

# Standardize
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
print("Data standardized (zero mean, unit variance)")

# PCA for visualization
pca_2d = PCA(n_components=2)
X_pca_2d = pca_2d.fit_transform(X_scaled)
print(f"PCA 2D: explained variance = {pca_2d.explained_variance_ratio_.sum():.4f} ({pca_2d.explained_variance_ratio_[0]:.4f}, {pca_2d.explained_variance_ratio_[1]:.4f})")

# ============================================================
# 2. APPLY CLUSTERING ALGORITHMS
# ============================================================
print("\n" + "=" * 70)
print("STEP 2: Applying Clustering Algorithms")
print("=" * 70)

# --- K-Means ---
print("\n--- K-Means Clustering (k=3) ---")
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10, max_iter=300)
kmeans_labels = kmeans.fit_predict(X_scaled)
print(f"K-Means cluster sizes: {dict(zip(*np.unique(kmeans_labels, return_counts=True)))}")
print(f"K-Means inertia: {kmeans.inertia_:.2f}")

# --- Hierarchical ---
print("\n--- Hierarchical Clustering (Agglomerative, Ward's linkage) ---")
hierarchical = AgglomerativeClustering(n_clusters=3, linkage='ward')
hier_labels = hierarchical.fit_predict(X_scaled)
print(f"Hierarchical cluster sizes: {dict(zip(*np.unique(hier_labels, return_counts=True)))}")

# --- GMM ---
print("\n--- Gaussian Mixture Model (3 components) ---")
gmm = GaussianMixture(n_components=3, random_state=42, n_init=5, covariance_type='full')
gmm_labels = gmm.fit_predict(X_scaled)
gmm_probs = gmm.predict_proba(X_scaled)
print(f"GMM cluster sizes: {dict(zip(*np.unique(gmm_labels, return_counts=True)))}")
print(f"GMM BIC: {gmm.bic(X_scaled):.2f}")
print(f"GMM AIC: {gmm.aic(X_scaled):.2f}")
print(f"GMM converged: {gmm.converged_}")

# ============================================================
# 3. EVALUATION METRICS
# ============================================================
print("\n" + "=" * 70)
print("STEP 3: Evaluation Metrics (9 Features)")
print("=" * 70)

def cluster_accuracy(true_labels, pred_labels):
    cm = confusion_matrix(true_labels, pred_labels)
    row_ind, col_ind = linear_sum_assignment(-cm)
    accuracy = cm[row_ind, col_ind].sum() / len(true_labels)
    mapping = dict(zip(col_ind, row_ind))
    mapped_labels = np.array([mapping[l] for l in pred_labels])
    return accuracy, mapped_labels, mapping

algorithms = {
    'K-Means': kmeans_labels,
    'Hierarchical': hier_labels,
    'GMM': gmm_labels
}

results_9f = {}
mapped_labels_dict = {}

for name, labels in algorithms.items():
    print(f"\n--- {name} ---")
    sil = silhouette_score(X_scaled, labels)
    ch = calinski_harabasz_score(X_scaled, labels)
    db = davies_bouldin_score(X_scaled, labels)
    ari = adjusted_rand_score(true_labels, labels)
    nmi = normalized_mutual_info_score(true_labels, labels)
    acc, mapped, mapping = cluster_accuracy(true_labels, labels)
    mapped_labels_dict[name] = mapped
    
    results_9f[name] = {
        'Silhouette Score': sil,
        'Calinski-Harabasz Index': ch,
        'Davies-Bouldin Index': db,
        'Adjusted Rand Index': ari,
        'Normalized Mutual Info': nmi,
        'Accuracy (Hungarian)': acc
    }
    
    print(f"  Silhouette Score:        {sil:.4f}")
    print(f"  Calinski-Harabasz Index: {ch:.4f}")
    print(f"  Davies-Bouldin Index:    {db:.4f}")
    print(f"  Adjusted Rand Index:     {ari:.4f}")
    print(f"  Normalized Mutual Info:  {nmi:.4f}")
    print(f"  Accuracy (Hungarian):    {acc:.4f}")
    print(f"  Label Mapping:           {mapping}")

# Save metrics
results_9f_df = pd.DataFrame(results_9f).T
results_9f_df.index.name = 'Algorithm'
results_9f_df.to_csv('/home/ubuntu/clustering_metrics_9f.csv')

print("\n" + "=" * 70)
print("9 FEATURES - COMPARISON TABLE")
print("=" * 70)
print(results_9f_df.to_string())

# ============================================================
# 4. COMPARISON WITH 60 FEATURES
# ============================================================
print("\n" + "=" * 70)
print("STEP 4: Comparison 60 Features vs 9 Features")
print("=" * 70)

results_60f = pd.read_csv('/home/ubuntu/clustering_metrics.csv', index_col=0)

print("\n--- 60 Features Results ---")
print(results_60f.to_string())
print("\n--- 9 Features Results ---")
print(results_9f_df.to_string())

# Compute differences
print("\n--- Difference (9F - 60F) ---")
diff = results_9f_df - results_60f
print(diff.to_string())

# Compute percentage change
print("\n--- Percentage Change ---")
pct = ((results_9f_df - results_60f) / results_60f * 100)
print(pct.to_string())

# Save comparison
comparison = pd.DataFrame()
for metric in results_60f.columns:
    for algo in results_60f.index:
        comparison.loc[algo, f'{metric} (60F)'] = results_60f.loc[algo, metric]
        comparison.loc[algo, f'{metric} (9F)'] = results_9f_df.loc[algo, metric]
        comparison.loc[algo, f'{metric} (Change%)'] = pct.loc[algo, metric]

comparison.to_csv('/home/ubuntu/comparison_60f_vs_9f.csv')
print("\nComparison saved to comparison_60f_vs_9f.csv")

# ============================================================
# 5. CONFUSION MATRICES
# ============================================================
print("\n" + "=" * 70)
print("STEP 5: Confusion Matrices (9 Features)")
print("=" * 70)

for name, mapped in mapped_labels_dict.items():
    print(f"\n--- {name} ---")
    cm = confusion_matrix(true_labels, mapped)
    print(cm)
    print(classification_report(true_labels, mapped, target_names=['Class 0', 'Class 1', 'Class 2']))

# ============================================================
# 6. SAVE ALL DATA
# ============================================================
cluster_df = df.copy()
cluster_df['KMeans_Cluster'] = kmeans_labels
cluster_df['Hierarchical_Cluster'] = hier_labels
cluster_df['GMM_Cluster'] = gmm_labels
cluster_df['KMeans_Mapped'] = mapped_labels_dict['K-Means']
cluster_df['Hierarchical_Mapped'] = mapped_labels_dict['Hierarchical']
cluster_df['GMM_Mapped'] = mapped_labels_dict['GMM']
for i in range(3):
    cluster_df[f'GMM_Prob_Cluster{i}'] = gmm_probs[:, i]
cluster_df.to_excel('/home/ubuntu/clustering_results_9f.xlsx', index=False)

# Save arrays for visualization
np.save('/home/ubuntu/X_pca_2d_9f.npy', X_pca_2d)
np.save('/home/ubuntu/X_scaled_9f.npy', X_scaled)
np.save('/home/ubuntu/kmeans_labels_9f.npy', kmeans_labels)
np.save('/home/ubuntu/hier_labels_9f.npy', hier_labels)
np.save('/home/ubuntu/gmm_labels_9f.npy', gmm_labels)
np.save('/home/ubuntu/gmm_probs_9f.npy', gmm_probs)

print("\nAll data saved. DONE!")
