import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score, calinski_harabasz_score, davies_bouldin_score,
    adjusted_rand_score, normalized_mutual_info_score,
    confusion_matrix, classification_report, accuracy_score
)
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.optimize import linear_sum_assignment
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. LOAD AND PREPARE DATA
# ============================================================
print("=" * 70)
print("STEP 1: Loading and Preparing Data")
print("=" * 70)

df = pd.read_excel('/home/ubuntu/upload/Enhanced_Dataset_61_Features.xlsx')
df.columns = df.columns.str.strip()

# Separate features and true labels
true_labels = df['Class'].values
feature_cols = [c for c in df.columns if c != 'Class']
X = df[feature_cols].values

print(f"Dataset: {X.shape[0]} samples, {X.shape[1]} features")
print(f"True class distribution: {dict(zip(*np.unique(true_labels, return_counts=True)))}")

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
print("Data standardized (zero mean, unit variance)")

# PCA for visualization (2D and 3D)
pca_2d = PCA(n_components=2)
X_pca_2d = pca_2d.fit_transform(X_scaled)
print(f"PCA 2D: explained variance = {pca_2d.explained_variance_ratio_.sum():.4f} ({pca_2d.explained_variance_ratio_[0]:.4f}, {pca_2d.explained_variance_ratio_[1]:.4f})")

pca_3d = PCA(n_components=3)
X_pca_3d = pca_3d.fit_transform(X_scaled)
print(f"PCA 3D: explained variance = {pca_3d.explained_variance_ratio_.sum():.4f}")

# ============================================================
# 2. APPLY CLUSTERING ALGORITHMS
# ============================================================
print("\n" + "=" * 70)
print("STEP 2: Applying Clustering Algorithms")
print("=" * 70)

# --- K-Means Clustering (k=3) ---
print("\n--- K-Means Clustering (k=3) ---")
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10, max_iter=300)
kmeans_labels = kmeans.fit_predict(X_scaled)
print(f"K-Means cluster sizes: {dict(zip(*np.unique(kmeans_labels, return_counts=True)))}")
print(f"K-Means inertia: {kmeans.inertia_:.2f}")

# --- Hierarchical Clustering (Agglomerative, Ward's linkage) ---
print("\n--- Hierarchical Clustering (Agglomerative, Ward's linkage) ---")
hierarchical = AgglomerativeClustering(n_clusters=3, linkage='ward')
hier_labels = hierarchical.fit_predict(X_scaled)
print(f"Hierarchical cluster sizes: {dict(zip(*np.unique(hier_labels, return_counts=True)))}")

# --- Gaussian Mixture Model (3 components) ---
print("\n--- Gaussian Mixture Model (3 components) ---")
gmm = GaussianMixture(n_components=3, random_state=42, n_init=5, covariance_type='full')
gmm_labels = gmm.fit_predict(X_scaled)
gmm_probs = gmm.predict_proba(X_scaled)
print(f"GMM cluster sizes: {dict(zip(*np.unique(gmm_labels, return_counts=True)))}")
print(f"GMM BIC: {gmm.bic(X_scaled):.2f}")
print(f"GMM AIC: {gmm.aic(X_scaled):.2f}")
print(f"GMM converged: {gmm.converged_}")
print(f"GMM n_iter: {gmm.n_iter_}")

# ============================================================
# 3. EVALUATION METRICS
# ============================================================
print("\n" + "=" * 70)
print("STEP 3: Evaluation Metrics")
print("=" * 70)

def cluster_accuracy(true_labels, pred_labels):
    """Calculate accuracy using Hungarian algorithm for optimal label matching."""
    cm = confusion_matrix(true_labels, pred_labels)
    row_ind, col_ind = linear_sum_assignment(-cm)
    accuracy = cm[row_ind, col_ind].sum() / len(true_labels)
    # Create mapping
    mapping = dict(zip(col_ind, row_ind))
    mapped_labels = np.array([mapping[l] for l in pred_labels])
    return accuracy, mapped_labels, mapping

algorithms = {
    'K-Means': kmeans_labels,
    'Hierarchical': hier_labels,
    'GMM': gmm_labels
}

results = {}
mapped_labels_dict = {}

for name, labels in algorithms.items():
    print(f"\n--- {name} ---")
    
    # Internal metrics (no true labels needed)
    sil = silhouette_score(X_scaled, labels)
    ch = calinski_harabasz_score(X_scaled, labels)
    db = davies_bouldin_score(X_scaled, labels)
    
    # External metrics (compare with true labels)
    ari = adjusted_rand_score(true_labels, labels)
    nmi = normalized_mutual_info_score(true_labels, labels)
    
    # Accuracy with Hungarian matching
    acc, mapped, mapping = cluster_accuracy(true_labels, labels)
    mapped_labels_dict[name] = mapped
    
    results[name] = {
        'Silhouette Score': sil,
        'Calinski-Harabasz Index': ch,
        'Davies-Bouldin Index': db,
        'Adjusted Rand Index': ari,
        'Normalized Mutual Info': nmi,
        'Accuracy (Hungarian)': acc
    }
    
    print(f"  Silhouette Score:        {sil:.4f}")
    print(f"  Calinski-Harabasz Index: {ch:.4f}")
    print(f"  Davies-Bouldin Index:    {db:.4f}")
    print(f"  Adjusted Rand Index:     {ari:.4f}")
    print(f"  Normalized Mutual Info:  {nmi:.4f}")
    print(f"  Accuracy (Hungarian):    {acc:.4f}")
    print(f"  Label Mapping:           {mapping}")

# Comparison table
print("\n" + "=" * 70)
print("COMPARISON TABLE")
print("=" * 70)
results_df = pd.DataFrame(results).T
results_df.index.name = 'Algorithm'
print(results_df.to_string())
results_df.to_csv('/home/ubuntu/clustering_metrics.csv')

# ============================================================
# 4. CONFUSION MATRICES
# ============================================================
print("\n" + "=" * 70)
print("STEP 4: Confusion Matrices (after Hungarian matching)")
print("=" * 70)

for name, mapped in mapped_labels_dict.items():
    print(f"\n--- {name} ---")
    cm = confusion_matrix(true_labels, mapped)
    print(cm)
    print(classification_report(true_labels, mapped, target_names=['Class 0', 'Class 1', 'Class 2']))

# ============================================================
# 5. SAVE RESULTS
# ============================================================
# Save cluster assignments
cluster_df = df.copy()
cluster_df['KMeans_Cluster'] = kmeans_labels
cluster_df['Hierarchical_Cluster'] = hier_labels
cluster_df['GMM_Cluster'] = gmm_labels
cluster_df['KMeans_Mapped'] = mapped_labels_dict['K-Means']
cluster_df['Hierarchical_Mapped'] = mapped_labels_dict['Hierarchical']
cluster_df['GMM_Mapped'] = mapped_labels_dict['GMM']

# Add GMM probabilities
for i in range(3):
    cluster_df[f'GMM_Prob_Cluster{i}'] = gmm_probs[:, i]

cluster_df.to_excel('/home/ubuntu/clustering_results.xlsx', index=False)
print("\nResults saved to clustering_results.xlsx")

# Save PCA components for plotting
np.save('/home/ubuntu/X_pca_2d.npy', X_pca_2d)
np.save('/home/ubuntu/X_pca_3d.npy', X_pca_3d)
np.save('/home/ubuntu/X_scaled.npy', X_scaled)
np.save('/home/ubuntu/true_labels.npy', true_labels)
np.save('/home/ubuntu/kmeans_labels.npy', kmeans_labels)
np.save('/home/ubuntu/hier_labels.npy', hier_labels)
np.save('/home/ubuntu/gmm_labels.npy', gmm_labels)
np.save('/home/ubuntu/gmm_probs.npy', gmm_probs)

print("\nAll data saved for visualization step.")
print("DONE!")
