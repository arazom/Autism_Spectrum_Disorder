import pandas as pd
import numpy as np

print("=" * 80)
print("COMPREHENSIVE DATA COLLECTION FOR ACADEMIC WRITING")
print("=" * 80)

# ============================================================
# 1. Dataset Description
# ============================================================
print("\n### 1. DATASET DESCRIPTION ###")
df_60 = pd.read_excel('/home/ubuntu/upload/Enhanced_Dataset_61_Features.xlsx')
df_60.columns = df_60.columns.str.strip()
df_9 = pd.read_excel('/home/ubuntu/upload/From_61_9_Features.xlsx')
df_9.columns = df_9.columns.str.strip()

print(f"Full dataset: {df_60.shape[0]} samples, {df_60.shape[1]} columns ({df_60.shape[1]-1} features + Class)")
print(f"Reduced dataset: {df_9.shape[0]} samples, {df_9.shape[1]} columns ({df_9.shape[1]-1} features + Class)")

print(f"\nClass distribution (both datasets):")
print(df_60['Class'].value_counts().sort_index())

print(f"\n9 Selected Features:")
feat_9 = [c for c in df_9.columns if c != 'Class']
for i, f in enumerate(feat_9, 1):
    print(f"  {i}. {f}")

# ============================================================
# 2. Metrics - 60 Features
# ============================================================
print("\n### 2. METRICS - 60 FEATURES ###")
m60 = pd.read_csv('/home/ubuntu/clustering_metrics.csv', index_col=0)
print(m60.to_string())

# ============================================================
# 3. Metrics - 9 Features
# ============================================================
print("\n### 3. METRICS - 9 FEATURES ###")
m9 = pd.read_csv('/home/ubuntu/clustering_metrics_9f.csv', index_col=0)
print(m9.to_string())

# ============================================================
# 4. Percentage Change
# ============================================================
print("\n### 4. PERCENTAGE CHANGE (9F vs 60F) ###")
pct = ((m9 - m60) / m60 * 100)
print(pct.to_string())

# ============================================================
# 5. Confusion Matrices - 60 Features
# ============================================================
print("\n### 5. CONFUSION MATRICES - 60 FEATURES ###")
from sklearn.metrics import confusion_matrix, classification_report
from scipy.optimize import linear_sum_assignment

true_labels = np.load('/home/ubuntu/true_labels.npy')

def get_mapped_and_cm(true_labels, pred_labels):
    cm = confusion_matrix(true_labels, pred_labels)
    row_ind, col_ind = linear_sum_assignment(-cm)
    mapping = dict(zip(col_ind, row_ind))
    mapped = np.array([mapping[l] for l in pred_labels])
    cm_mapped = confusion_matrix(true_labels, mapped)
    return cm_mapped, mapped

# 60F
for name, fname in [('K-Means', 'kmeans_labels.npy'), ('Hierarchical', 'hier_labels.npy'), ('GMM', 'gmm_labels.npy')]:
    labels = np.load(f'/home/ubuntu/{fname}')
    cm, mapped = get_mapped_and_cm(true_labels, labels)
    print(f"\n{name} (60F):")
    print(cm)
    print(classification_report(true_labels, mapped, target_names=['Class 0', 'Class 1', 'Class 2'], digits=4))

# ============================================================
# 6. Confusion Matrices - 9 Features
# ============================================================
print("\n### 6. CONFUSION MATRICES - 9 FEATURES ###")
for name, fname in [('K-Means', 'kmeans_labels_9f.npy'), ('Hierarchical', 'hier_labels_9f.npy'), ('GMM', 'gmm_labels_9f.npy')]:
    labels = np.load(f'/home/ubuntu/{fname}')
    cm, mapped = get_mapped_and_cm(true_labels, labels)
    print(f"\n{name} (9F):")
    print(cm)
    print(classification_report(true_labels, mapped, target_names=['Class 0', 'Class 1', 'Class 2'], digits=4))

# ============================================================
# 7. PCA Explained Variance
# ============================================================
print("\n### 7. PCA INFO ###")
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X60 = scaler.fit_transform(df_60.drop('Class', axis=1).values)
X9 = scaler.fit_transform(df_9.drop('Class', axis=1).values)

pca60 = PCA(n_components=2).fit(X60)
pca9 = PCA(n_components=2).fit(X9)

print(f"PCA 2D (60F): explained variance = {pca60.explained_variance_ratio_.sum():.4f} ({pca60.explained_variance_ratio_[0]:.4f}, {pca60.explained_variance_ratio_[1]:.4f})")
print(f"PCA 2D (9F): explained variance = {pca9.explained_variance_ratio_.sum():.4f} ({pca9.explained_variance_ratio_[0]:.4f}, {pca9.explained_variance_ratio_[1]:.4f})")

# ============================================================
# 8. K-Means Inertia
# ============================================================
print("\n### 8. K-MEANS INERTIA ###")
from sklearn.cluster import KMeans
km60 = KMeans(n_clusters=3, random_state=42, n_init=10).fit(X60)
km9 = KMeans(n_clusters=3, random_state=42, n_init=10).fit(X9)
print(f"K-Means Inertia (60F): {km60.inertia_:.2f}")
print(f"K-Means Inertia (9F): {km9.inertia_:.2f}")

# ============================================================
# 9. GMM BIC/AIC
# ============================================================
print("\n### 9. GMM BIC/AIC ###")
from sklearn.mixture import GaussianMixture
gmm60 = GaussianMixture(n_components=3, random_state=42, n_init=5).fit(X60)
gmm9 = GaussianMixture(n_components=3, random_state=42, n_init=5).fit(X9)
print(f"GMM BIC (60F): {gmm60.bic(X60):.2f}, AIC: {gmm60.aic(X60):.2f}")
print(f"GMM BIC (9F): {gmm9.bic(X9):.2f}, AIC: {gmm9.aic(X9):.2f}")

# ============================================================
# 10. Inter-algorithm agreement
# ============================================================
print("\n### 10. INTER-ALGORITHM AGREEMENT ###")
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

# 60F
km60_l = np.load('/home/ubuntu/kmeans_labels.npy')
hi60_l = np.load('/home/ubuntu/hier_labels.npy')
gm60_l = np.load('/home/ubuntu/gmm_labels.npy')

print("60 Features:")
print(f"  K-Means vs Hierarchical: ARI={adjusted_rand_score(km60_l, hi60_l):.4f}, NMI={normalized_mutual_info_score(km60_l, hi60_l):.4f}")
print(f"  K-Means vs GMM:          ARI={adjusted_rand_score(km60_l, gm60_l):.4f}, NMI={normalized_mutual_info_score(km60_l, gm60_l):.4f}")
print(f"  Hierarchical vs GMM:     ARI={adjusted_rand_score(hi60_l, gm60_l):.4f}, NMI={normalized_mutual_info_score(hi60_l, gm60_l):.4f}")

km9_l = np.load('/home/ubuntu/kmeans_labels_9f.npy')
hi9_l = np.load('/home/ubuntu/hier_labels_9f.npy')
gm9_l = np.load('/home/ubuntu/gmm_labels_9f.npy')

print("9 Features:")
print(f"  K-Means vs Hierarchical: ARI={adjusted_rand_score(km9_l, hi9_l):.4f}, NMI={normalized_mutual_info_score(km9_l, hi9_l):.4f}")
print(f"  K-Means vs GMM:          ARI={adjusted_rand_score(km9_l, gm9_l):.4f}, NMI={normalized_mutual_info_score(km9_l, gm9_l):.4f}")
print(f"  Hierarchical vs GMM:     ARI={adjusted_rand_score(hi9_l, gm9_l):.4f}, NMI={normalized_mutual_info_score(hi9_l, gm9_l):.4f}")

print("\n=== DONE ===")
