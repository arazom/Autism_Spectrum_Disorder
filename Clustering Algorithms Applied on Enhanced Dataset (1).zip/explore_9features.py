import pandas as pd
import numpy as np

df = pd.read_excel('/home/ubuntu/upload/From_61_9_Features.xlsx')
df.columns = df.columns.str.strip()

print("=== Dataset Shape ===")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")

print("\n=== Column Names ===")
for i, col in enumerate(df.columns):
    print(f"  {i+1}. {col}")

print("\n=== Feature Columns (excluding Class) ===")
feature_cols = [c for c in df.columns if c != 'Class']
print(f"Number of features: {len(feature_cols)}")
for f in feature_cols:
    print(f"  - {f}")

print("\n=== Class Distribution ===")
print(df['Class'].value_counts().sort_index())

print("\n=== Basic Statistics ===")
print(df.describe().to_string())

print("\n=== Missing Values ===")
missing = df.isnull().sum()
print(missing[missing > 0] if missing.sum() > 0 else "No missing values")
