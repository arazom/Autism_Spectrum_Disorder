import pandas as pd
import numpy as np

# Load data
df = pd.read_excel('/home/ubuntu/upload/Enhanced_Dataset_61_Features.xlsx')

# Clean column names
df.columns = df.columns.str.strip()

print("=== Dataset Shape ===")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")

print("\n=== Column Names ===")
for i, col in enumerate(df.columns):
    print(f"  {i+1}. {col}")

print("\n=== Data Types ===")
print(df.dtypes.value_counts())

print("\n=== First 5 Rows ===")
print(df.head())

print("\n=== Basic Statistics ===")
print(df.describe())

print("\n=== Missing Values ===")
missing = df.isnull().sum()
print(missing[missing > 0] if missing.sum() > 0 else "No missing values")

print("\n=== Class Distribution ===")
if 'Class' in df.columns:
    print(df['Class'].value_counts().sort_index())
    print(f"\nUnique Classes: {df['Class'].unique()}")
