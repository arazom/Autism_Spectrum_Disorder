import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import confusion_matrix, silhouette_samples
from scipy.cluster.hierarchy import dendrogram, linkage
import warnings
warnings.filterwarnings('ignore')

# Apply style first, then set fonts
plt.style.use('seaborn-v0_8-whitegrid')

# Color palette
colors_3 = ['#2196F3', '#FF5722', '#4CAF50']  # Blue, Orange, Green
colors_algo = ['#1976D2', '#D32F2F', '#388E3C']  # Darker variants

# Load saved data
X_pca_2d = np.load('/home/ubuntu/X_pca_2d.npy')
X_pca_3d = np.load('/home/ubuntu/X_pca_3d.npy')
X_scaled = np.load('/home/ubuntu/X_scaled.npy')
true_labels = np.load('/home/ubuntu/true_labels.npy')
kmeans_labels = np.load('/home/ubuntu/kmeans_labels.npy')
hier_labels = np.load('/home/ubuntu/hier_labels.npy')
gmm_labels = np.load('/home/ubuntu/gmm_labels.npy')
gmm_probs = np.load('/home/ubuntu/gmm_probs.npy')

df = pd.read_excel('/home/ubuntu/upload/Enhanced_Dataset_61_Features.xlsx')
df.columns = df.columns.str.strip()

# ============================================================
# FIGURE 1: PCA 2D Scatter - True Labels vs All Algorithms
# ============================================================
print("Creating Figure 1: PCA 2D Comparison...")
fig, axes = plt.subplots(2, 2, figsize=(16, 14))

titles = ['True Labels (Ground Truth)', 'K-Means Clustering (k=3)', 
          'Hierarchical Clustering (Ward)', 'Gaussian Mixture Model (k=3)']
all_labels = [true_labels, kmeans_labels, hier_labels, gmm_labels]

for ax, title, labels in zip(axes.flatten(), titles, all_labels):
    for i in range(3):
        mask = labels == i
        ax.scatter(X_pca_2d[mask, 0], X_pca_2d[mask, 1], 
                  c=colors_3[i], alpha=0.6, s=40, label=f'Cluster {i}',
                  edgecolors='white', linewidth=0.5)
    ax.set_xlabel('PC1', fontsize=12)
    ax.set_ylabel('PC2', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(fontsize=10)

plt.suptitle('PCA 2D Visualization: True Labels vs Clustering Algorithms', 
             fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig1_pca2d_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig1_pca2d_comparison.png")

# ============================================================
# FIGURE 2: Confusion Matrices (Heatmaps)
# ============================================================
print("Creating Figure 2: Confusion Matrices...")
from scipy.optimize import linear_sum_assignment

def get_mapped_labels(true_labels, pred_labels):
    cm = confusion_matrix(true_labels, pred_labels)
    row_ind, col_ind = linear_sum_assignment(-cm)
    mapping = dict(zip(col_ind, row_ind))
    return np.array([mapping[l] for l in pred_labels])

fig, axes = plt.subplots(1, 3, figsize=(18, 5))
algo_names = ['K-Means', 'Hierarchical', 'GMM']
algo_labels = [kmeans_labels, hier_labels, gmm_labels]

for ax, name, labels in zip(axes, algo_names, algo_labels):
    mapped = get_mapped_labels(true_labels, labels)
    cm = confusion_matrix(true_labels, mapped)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=['Class 0', 'Class 1', 'Class 2'],
                yticklabels=['Class 0', 'Class 1', 'Class 2'],
                annot_kws={'size': 14})
    ax.set_title(f'{name}', fontsize=14, fontweight='bold')
    ax.set_xlabel('Predicted', fontsize=12)
    ax.set_ylabel('True', fontsize=12)

plt.suptitle('Confusion Matrices (After Hungarian Matching)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig2_confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig2_confusion_matrices.png")

# ============================================================
# FIGURE 3: Metrics Comparison Bar Chart
# ============================================================
print("Creating Figure 3: Metrics Comparison...")
metrics_df = pd.read_csv('/home/ubuntu/clustering_metrics.csv', index_col=0)

fig, axes = plt.subplots(2, 3, figsize=(18, 10))

metrics_list = list(metrics_df.columns)
for idx, metric in enumerate(metrics_list):
    ax = axes.flatten()[idx]
    values = metrics_df[metric].values
    bars = ax.bar(metrics_df.index, values, color=colors_algo, width=0.6, edgecolor='white')
    ax.set_title(metric, fontsize=12, fontweight='bold')
    ax.set_ylabel('Score', fontsize=10)
    
    # Add value labels
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.005,
                f'{val:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    ax.tick_params(axis='x', rotation=15)

plt.suptitle('Clustering Evaluation Metrics Comparison', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig3_metrics_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig3_metrics_comparison.png")

# ============================================================
# FIGURE 4: Silhouette Analysis
# ============================================================
print("Creating Figure 4: Silhouette Analysis...")
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

for ax, name, labels in zip(axes, algo_names, algo_labels):
    sil_vals = silhouette_samples(X_scaled, labels)
    y_lower = 10
    
    for i in range(3):
        cluster_sil = sil_vals[labels == i]
        cluster_sil.sort()
        size_cluster = cluster_sil.shape[0]
        y_upper = y_lower + size_cluster
        
        ax.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                         facecolor=colors_3[i], edgecolor=colors_3[i], alpha=0.7)
        ax.text(-0.05, y_lower + 0.5 * size_cluster, f'C{i}', fontsize=10, fontweight='bold')
        y_lower = y_upper + 10
    
    avg_sil = np.mean(sil_vals)
    ax.axvline(x=avg_sil, color='red', linestyle='--', linewidth=2, label=f'Avg: {avg_sil:.3f}')
    ax.set_title(f'{name}', fontsize=14, fontweight='bold')
    ax.set_xlabel('Silhouette Coefficient', fontsize=11)
    ax.set_ylabel('Samples', fontsize=11)
    ax.legend(fontsize=10)

plt.suptitle('Silhouette Analysis for Each Algorithm', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig4_silhouette_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig4_silhouette_analysis.png")

# ============================================================
# FIGURE 5: Cluster Size Distribution
# ============================================================
print("Creating Figure 5: Cluster Size Distribution...")
fig, axes = plt.subplots(1, 4, figsize=(20, 5))

all_titles = ['True Labels', 'K-Means', 'Hierarchical', 'GMM']
all_lab = [true_labels, kmeans_labels, hier_labels, gmm_labels]

for ax, title, labels in zip(axes, all_titles, all_lab):
    unique, counts = np.unique(labels, return_counts=True)
    bars = ax.bar(unique, counts, color=colors_3, width=0.6, edgecolor='white')
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel('Cluster', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.set_xticks([0, 1, 2])
    
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 2,
                str(count), ha='center', va='bottom', fontsize=12, fontweight='bold')

plt.suptitle('Cluster Size Distribution', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig5_cluster_sizes.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig5_cluster_sizes.png")

# ============================================================
# FIGURE 6: Dendrogram for Hierarchical Clustering
# ============================================================
print("Creating Figure 6: Dendrogram...")
fig, ax = plt.subplots(figsize=(18, 8))
linked = linkage(X_scaled, method='ward')
dendrogram(linked, truncate_mode='lastp', p=30, leaf_rotation=90,
           leaf_font_size=10, show_contracted=True, ax=ax,
           color_threshold=0.7*max(linked[:, 2]))
ax.set_title("Hierarchical Clustering Dendrogram (Ward's Linkage)", fontsize=16, fontweight='bold')
ax.set_xlabel('Sample Index (or Cluster Size)', fontsize=12)
ax.set_ylabel('Distance', fontsize=12)
ax.axhline(y=0.7*max(linked[:, 2]), color='red', linestyle='--', linewidth=1.5, label='Cut threshold')
ax.legend(fontsize=11)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig6_dendrogram.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig6_dendrogram.png")

# ============================================================
# FIGURE 7: GMM Probability Distribution
# ============================================================
print("Creating Figure 7: GMM Probabilities...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

for i in range(3):
    ax = axes[i]
    ax.hist(gmm_probs[:, i], bins=30, color=colors_3[i], alpha=0.7, edgecolor='white')
    ax.set_title(f'GMM Probability - Component {i}', fontsize=13, fontweight='bold')
    ax.set_xlabel('Probability', fontsize=11)
    ax.set_ylabel('Frequency', fontsize=11)
    ax.axvline(x=0.5, color='red', linestyle='--', linewidth=1.5, alpha=0.7)

plt.suptitle('GMM Posterior Probability Distributions', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig7_gmm_probabilities.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig7_gmm_probabilities.png")

# ============================================================
# FIGURE 8: Elbow Method for K-Means
# ============================================================
print("Creating Figure 8: Elbow Method...")
from sklearn.cluster import KMeans

inertias = []
sil_scores = []
K_range = range(2, 11)

for k in K_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_samples(X_scaled, km.labels_).mean())

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

ax1.plot(K_range, inertias, 'bo-', linewidth=2, markersize=8)
ax1.axvline(x=3, color='red', linestyle='--', linewidth=1.5, label='k=3 (selected)')
ax1.set_xlabel('Number of Clusters (k)', fontsize=12)
ax1.set_ylabel('Inertia (Within-Cluster Sum of Squares)', fontsize=12)
ax1.set_title('Elbow Method', fontsize=14, fontweight='bold')
ax1.legend(fontsize=11)

ax2.plot(K_range, sil_scores, 'go-', linewidth=2, markersize=8)
ax2.axvline(x=3, color='red', linestyle='--', linewidth=1.5, label='k=3 (selected)')
ax2.set_xlabel('Number of Clusters (k)', fontsize=12)
ax2.set_ylabel('Silhouette Score', fontsize=12)
ax2.set_title('Silhouette Score vs k', fontsize=14, fontweight='bold')
ax2.legend(fontsize=11)

plt.suptitle('Optimal Number of Clusters Analysis', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig8_elbow_silhouette.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig8_elbow_silhouette.png")

# ============================================================
# FIGURE 9: Feature Importance by Cluster (Top Features)
# ============================================================
print("Creating Figure 9: Feature Importance...")
feature_cols = [c for c in df.columns if c != 'Class']

# K-Means cluster centers
from sklearn.cluster import KMeans as KM
km_model = KM(n_clusters=3, random_state=42, n_init=10).fit(X_scaled)
centers = km_model.cluster_centers_

# Find top 15 features with highest variance across cluster centers
center_var = np.var(centers, axis=0)
top_idx = np.argsort(center_var)[-15:][::-1]
top_features = [feature_cols[i] for i in top_idx]

fig, ax = plt.subplots(figsize=(14, 8))
x = np.arange(len(top_features))
width = 0.25

for i in range(3):
    vals = centers[i, top_idx]
    ax.barh(x + i*width, vals, width, color=colors_3[i], label=f'Cluster {i}', alpha=0.8)

ax.set_yticks(x + width)
ax.set_yticklabels(top_features, fontsize=10)
ax.set_xlabel('Standardized Feature Value (Cluster Center)', fontsize=12)
ax.set_title('Top 15 Discriminating Features (K-Means Cluster Centers)', fontsize=14, fontweight='bold')
ax.legend(fontsize=11)
ax.invert_yaxis()
plt.tight_layout()
plt.savefig('/home/ubuntu/fig9_feature_importance.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig9_feature_importance.png")

# ============================================================
# FIGURE 10: Radar Chart - Cluster Profiles
# ============================================================
print("Creating Figure 10: Radar Chart...")
# Select key behavioral features for radar chart
radar_features = ['Behavioral_Sum', 'Behavioral_Mean', 'Social_Interaction_Mean',
                  'Communication_Mean', 'Repetitive_Behaviors_Mean', 
                  'Sensory_Sensitivity_Mean', 'Language_Development_Mean']

scaler_radar = StandardScaler()
radar_data = scaler_radar.fit_transform(df[radar_features].values)

fig, axes = plt.subplots(1, 3, figsize=(18, 6), subplot_kw=dict(polar=True))
algo_titles = ['K-Means', 'Hierarchical', 'GMM']

for ax, title, labels in zip(axes, algo_titles, algo_labels):
    angles = np.linspace(0, 2*np.pi, len(radar_features), endpoint=False).tolist()
    angles += angles[:1]
    
    for i in range(3):
        mask = labels == i
        values = radar_data[mask].mean(axis=0).tolist()
        values += values[:1]
        ax.plot(angles, values, 'o-', color=colors_3[i], linewidth=2, label=f'Cluster {i}')
        ax.fill(angles, values, color=colors_3[i], alpha=0.1)
    
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels([f.replace('_', '\n') for f in radar_features], fontsize=7)
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=9)

plt.suptitle('Cluster Profiles - Key Behavioral Features', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig10_radar_profiles.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig10_radar_profiles.png")

# ============================================================
# FIGURE 11: Agreement Between Algorithms
# ============================================================
print("Creating Figure 11: Algorithm Agreement...")
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

algos = {'True Labels': true_labels, 'K-Means': kmeans_labels, 
         'Hierarchical': hier_labels, 'GMM': gmm_labels}
algo_names_all = list(algos.keys())

# ARI matrix
ari_matrix = np.zeros((4, 4))
nmi_matrix = np.zeros((4, 4))
for i, (n1, l1) in enumerate(algos.items()):
    for j, (n2, l2) in enumerate(algos.items()):
        ari_matrix[i, j] = adjusted_rand_score(l1, l2)
        nmi_matrix[i, j] = normalized_mutual_info_score(l1, l2)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

sns.heatmap(ari_matrix, annot=True, fmt='.3f', cmap='YlOrRd', ax=ax1,
            xticklabels=algo_names_all, yticklabels=algo_names_all,
            annot_kws={'size': 12}, vmin=0, vmax=1)
ax1.set_title('Adjusted Rand Index (ARI)', fontsize=14, fontweight='bold')

sns.heatmap(nmi_matrix, annot=True, fmt='.3f', cmap='YlOrRd', ax=ax2,
            xticklabels=algo_names_all, yticklabels=algo_names_all,
            annot_kws={'size': 12}, vmin=0, vmax=1)
ax2.set_title('Normalized Mutual Information (NMI)', fontsize=14, fontweight='bold')

plt.suptitle('Pairwise Agreement Between Algorithms', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig11_algorithm_agreement.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig11_algorithm_agreement.png")

print("\n=== All Visualizations Created Successfully! ===")
