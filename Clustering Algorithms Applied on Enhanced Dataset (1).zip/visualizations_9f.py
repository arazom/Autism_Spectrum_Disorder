import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, silhouette_samples
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.optimize import linear_sum_assignment
import warnings
warnings.filterwarnings('ignore')

plt.style.use('seaborn-v0_8-whitegrid')

colors_3 = ['#2196F3', '#FF5722', '#4CAF50']
colors_algo = ['#1976D2', '#D32F2F', '#388E3C']

# Load 9-feature data
X_pca_2d = np.load('/home/ubuntu/X_pca_2d_9f.npy')
X_scaled = np.load('/home/ubuntu/X_scaled_9f.npy')
true_labels = np.load('/home/ubuntu/true_labels.npy')
kmeans_labels = np.load('/home/ubuntu/kmeans_labels_9f.npy')
hier_labels = np.load('/home/ubuntu/hier_labels_9f.npy')
gmm_labels = np.load('/home/ubuntu/gmm_labels_9f.npy')
gmm_probs = np.load('/home/ubuntu/gmm_probs_9f.npy')

# Load 60-feature PCA for comparison
X_pca_2d_60f = np.load('/home/ubuntu/X_pca_2d.npy')
kmeans_labels_60f = np.load('/home/ubuntu/kmeans_labels.npy')
hier_labels_60f = np.load('/home/ubuntu/hier_labels.npy')
gmm_labels_60f = np.load('/home/ubuntu/gmm_labels.npy')

def get_mapped_labels(true_labels, pred_labels):
    cm = confusion_matrix(true_labels, pred_labels)
    row_ind, col_ind = linear_sum_assignment(-cm)
    mapping = dict(zip(col_ind, row_ind))
    return np.array([mapping[l] for l in pred_labels])

# ============================================================
# FIGURE 1: PCA 2D - 9 Features (True vs All Algorithms)
# ============================================================
print("Creating Figure 1: PCA 2D Comparison (9 Features)...")
fig, axes = plt.subplots(2, 2, figsize=(16, 14))
titles = ['True Labels (Ground Truth)', 'K-Means (k=3) - 9 Features',
          'Hierarchical (Ward) - 9 Features', 'GMM (k=3) - 9 Features']
all_labels = [true_labels, kmeans_labels, hier_labels, gmm_labels]

for ax, title, labels in zip(axes.flatten(), titles, all_labels):
    for i in range(3):
        mask = labels == i
        ax.scatter(X_pca_2d[mask, 0], X_pca_2d[mask, 1],
                  c=colors_3[i], alpha=0.6, s=40, label=f'Cluster {i}',
                  edgecolors='white', linewidth=0.5)
    ax.set_xlabel('PC1', fontsize=12)
    ax.set_ylabel('PC2', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(fontsize=10)

plt.suptitle('PCA 2D Visualization (9 Features): True Labels vs Clustering Algorithms',
             fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig1_9f_pca2d_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig1_9f_pca2d_comparison.png")

# ============================================================
# FIGURE 2: Confusion Matrices (9 Features)
# ============================================================
print("Creating Figure 2: Confusion Matrices (9 Features)...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
algo_names = ['K-Means', 'Hierarchical', 'GMM']
algo_labels_list = [kmeans_labels, hier_labels, gmm_labels]

for ax, name, labels in zip(axes, algo_names, algo_labels_list):
    mapped = get_mapped_labels(true_labels, labels)
    cm = confusion_matrix(true_labels, mapped)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=['Class 0', 'Class 1', 'Class 2'],
                yticklabels=['Class 0', 'Class 1', 'Class 2'],
                annot_kws={'size': 14})
    ax.set_title(f'{name} (9 Features)', fontsize=14, fontweight='bold')
    ax.set_xlabel('Predicted', fontsize=12)
    ax.set_ylabel('True', fontsize=12)

plt.suptitle('Confusion Matrices - 9 Features (After Hungarian Matching)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig2_9f_confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig2_9f_confusion_matrices.png")

# ============================================================
# FIGURE 3: SIDE-BY-SIDE Accuracy Comparison (60F vs 9F)
# ============================================================
print("Creating Figure 3: Accuracy Comparison 60F vs 9F...")
metrics_60f = pd.read_csv('/home/ubuntu/clustering_metrics.csv', index_col=0)
metrics_9f = pd.read_csv('/home/ubuntu/clustering_metrics_9f.csv', index_col=0)

fig, axes = plt.subplots(2, 3, figsize=(20, 12))
metric_names = list(metrics_60f.columns)

for idx, metric in enumerate(metric_names):
    ax = axes.flatten()[idx]
    x = np.arange(3)
    width = 0.35
    
    vals_60 = metrics_60f[metric].values
    vals_9 = metrics_9f[metric].values
    
    bars1 = ax.bar(x - width/2, vals_60, width, label='60 Features', color='#1565C0', alpha=0.85, edgecolor='white')
    bars2 = ax.bar(x + width/2, vals_9, width, label='9 Features', color='#E65100', alpha=0.85, edgecolor='white')
    
    ax.set_title(metric, fontsize=13, fontweight='bold')
    ax.set_ylabel('Score', fontsize=11)
    ax.set_xticks(x)
    ax.set_xticklabels(['K-Means', 'Hierarchical', 'GMM'], fontsize=10)
    ax.legend(fontsize=9)
    
    for bar, val in zip(bars1, vals_60):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.003,
                f'{val:.3f}', ha='center', va='bottom', fontsize=8, fontweight='bold', color='#1565C0')
    for bar, val in zip(bars2, vals_9):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.003,
                f'{val:.3f}', ha='center', va='bottom', fontsize=8, fontweight='bold', color='#E65100')

plt.suptitle('Metrics Comparison: 60 Features vs 9 Features', fontsize=18, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig3_9f_metrics_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig3_9f_metrics_comparison.png")

# ============================================================
# FIGURE 4: Silhouette Analysis (9 Features)
# ============================================================
print("Creating Figure 4: Silhouette Analysis (9 Features)...")
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

for ax, name, labels in zip(axes, algo_names, algo_labels_list):
    sil_vals = silhouette_samples(X_scaled, labels)
    y_lower = 10
    for i in range(3):
        cluster_sil = sil_vals[labels == i]
        cluster_sil.sort()
        size_cluster = cluster_sil.shape[0]
        y_upper = y_lower + size_cluster
        ax.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                         facecolor=colors_3[i], edgecolor=colors_3[i], alpha=0.7)
        ax.text(-0.05, y_lower + 0.5 * size_cluster, f'C{i}', fontsize=10, fontweight='bold')
        y_lower = y_upper + 10
    avg_sil = np.mean(sil_vals)
    ax.axvline(x=avg_sil, color='red', linestyle='--', linewidth=2, label=f'Avg: {avg_sil:.3f}')
    ax.set_title(f'{name} (9 Features)', fontsize=14, fontweight='bold')
    ax.set_xlabel('Silhouette Coefficient', fontsize=11)
    ax.set_ylabel('Samples', fontsize=11)
    ax.legend(fontsize=10)

plt.suptitle('Silhouette Analysis (9 Features)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig4_9f_silhouette.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig4_9f_silhouette.png")

# ============================================================
# FIGURE 5: Cluster Size Distribution (9F)
# ============================================================
print("Creating Figure 5: Cluster Size Distribution (9 Features)...")
fig, axes = plt.subplots(1, 4, figsize=(20, 5))
all_titles = ['True Labels', 'K-Means (9F)', 'Hierarchical (9F)', 'GMM (9F)']
all_lab = [true_labels, kmeans_labels, hier_labels, gmm_labels]

for ax, title, labels in zip(axes, all_titles, all_lab):
    unique, counts = np.unique(labels, return_counts=True)
    bars = ax.bar(unique, counts, color=colors_3[:len(unique)], width=0.6, edgecolor='white')
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel('Cluster', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.set_xticks(range(3))
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 2,
                str(count), ha='center', va='bottom', fontsize=12, fontweight='bold')

plt.suptitle('Cluster Size Distribution (9 Features)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig5_9f_cluster_sizes.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig5_9f_cluster_sizes.png")

# ============================================================
# FIGURE 6: Dendrogram (9 Features)
# ============================================================
print("Creating Figure 6: Dendrogram (9 Features)...")
fig, ax = plt.subplots(figsize=(18, 8))
linked = linkage(X_scaled, method='ward')
dendrogram(linked, truncate_mode='lastp', p=30, leaf_rotation=90,
           leaf_font_size=10, show_contracted=True, ax=ax,
           color_threshold=0.7*max(linked[:, 2]))
ax.set_title("Hierarchical Clustering Dendrogram - Ward's Linkage (9 Features)", fontsize=16, fontweight='bold')
ax.set_xlabel('Sample Index (or Cluster Size)', fontsize=12)
ax.set_ylabel('Distance', fontsize=12)
ax.axhline(y=0.7*max(linked[:, 2]), color='red', linestyle='--', linewidth=1.5, label='Cut threshold')
ax.legend(fontsize=11)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig6_9f_dendrogram.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig6_9f_dendrogram.png")

# ============================================================
# FIGURE 7: GMM Probability Distribution (9F)
# ============================================================
print("Creating Figure 7: GMM Probabilities (9 Features)...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for i in range(3):
    ax = axes[i]
    ax.hist(gmm_probs[:, i], bins=30, color=colors_3[i], alpha=0.7, edgecolor='white')
    ax.set_title(f'GMM Probability - Component {i} (9F)', fontsize=13, fontweight='bold')
    ax.set_xlabel('Probability', fontsize=11)
    ax.set_ylabel('Frequency', fontsize=11)
    ax.axvline(x=0.5, color='red', linestyle='--', linewidth=1.5, alpha=0.7)
plt.suptitle('GMM Posterior Probability Distributions (9 Features)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig7_9f_gmm_probabilities.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig7_9f_gmm_probabilities.png")

# ============================================================
# FIGURE 8: Elbow Method (9 Features)
# ============================================================
print("Creating Figure 8: Elbow Method (9 Features)...")
from sklearn.cluster import KMeans as KM

inertias = []
sil_scores = []
K_range = range(2, 11)
for k in K_range:
    km = KM(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_samples(X_scaled, km.labels_).mean())

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
ax1.plot(K_range, inertias, 'bo-', linewidth=2, markersize=8)
ax1.axvline(x=3, color='red', linestyle='--', linewidth=1.5, label='k=3 (selected)')
ax1.set_xlabel('Number of Clusters (k)', fontsize=12)
ax1.set_ylabel('Inertia', fontsize=12)
ax1.set_title('Elbow Method (9 Features)', fontsize=14, fontweight='bold')
ax1.legend(fontsize=11)

ax2.plot(K_range, sil_scores, 'go-', linewidth=2, markersize=8)
ax2.axvline(x=3, color='red', linestyle='--', linewidth=1.5, label='k=3 (selected)')
ax2.set_xlabel('Number of Clusters (k)', fontsize=12)
ax2.set_ylabel('Silhouette Score', fontsize=12)
ax2.set_title('Silhouette Score vs k (9 Features)', fontsize=14, fontweight='bold')
ax2.legend(fontsize=11)

plt.suptitle('Optimal Number of Clusters Analysis (9 Features)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig8_9f_elbow.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig8_9f_elbow.png")

# ============================================================
# FIGURE 9: Algorithm Agreement (9 Features)
# ============================================================
print("Creating Figure 9: Algorithm Agreement (9 Features)...")
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

algos = {'True Labels': true_labels, 'K-Means': kmeans_labels,
         'Hierarchical': hier_labels, 'GMM': gmm_labels}
algo_names_all = list(algos.keys())

ari_matrix = np.zeros((4, 4))
nmi_matrix = np.zeros((4, 4))
for i, (n1, l1) in enumerate(algos.items()):
    for j, (n2, l2) in enumerate(algos.items()):
        ari_matrix[i, j] = adjusted_rand_score(l1, l2)
        nmi_matrix[i, j] = normalized_mutual_info_score(l1, l2)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
sns.heatmap(ari_matrix, annot=True, fmt='.3f', cmap='YlOrRd', ax=ax1,
            xticklabels=algo_names_all, yticklabels=algo_names_all,
            annot_kws={'size': 12}, vmin=0, vmax=1)
ax1.set_title('ARI (9 Features)', fontsize=14, fontweight='bold')

sns.heatmap(nmi_matrix, annot=True, fmt='.3f', cmap='YlOrRd', ax=ax2,
            xticklabels=algo_names_all, yticklabels=algo_names_all,
            annot_kws={'size': 12}, vmin=0, vmax=1)
ax2.set_title('NMI (9 Features)', fontsize=14, fontweight='bold')

plt.suptitle('Pairwise Agreement Between Algorithms (9 Features)', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig9_9f_agreement.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig9_9f_agreement.png")

# ============================================================
# FIGURE 10: KEY COMPARISON - Accuracy Bar Chart (60F vs 9F)
# ============================================================
print("Creating Figure 10: Key Accuracy Comparison...")
fig, ax = plt.subplots(figsize=(10, 7))

algos_list = ['K-Means', 'Hierarchical', 'GMM']
acc_60f = [0.6000, 0.5265, 0.5941]
acc_9f = [0.5882, 0.4971, 0.4147]

x = np.arange(len(algos_list))
width = 0.35

bars1 = ax.bar(x - width/2, acc_60f, width, label='60 Features', color='#1565C0', alpha=0.9, edgecolor='white', linewidth=1.5)
bars2 = ax.bar(x + width/2, acc_9f, width, label='9 Features', color='#E65100', alpha=0.9, edgecolor='white', linewidth=1.5)

for bar, val in zip(bars1, acc_60f):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.008,
            f'{val:.1%}', ha='center', va='bottom', fontsize=13, fontweight='bold', color='#1565C0')
for bar, val in zip(bars2, acc_9f):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.008,
            f'{val:.1%}', ha='center', va='bottom', fontsize=13, fontweight='bold', color='#E65100')

# Add change arrows
for i, (v60, v9) in enumerate(zip(acc_60f, acc_9f)):
    change = v9 - v60
    pct = change / v60 * 100
    color = '#D32F2F' if change < 0 else '#388E3C'
    symbol = '▼' if change < 0 else '▲'
    ax.text(i, max(v60, v9) + 0.06, f'{symbol} {abs(pct):.1f}%',
            ha='center', fontsize=12, fontweight='bold', color=color)

ax.set_ylabel('Accuracy (Hungarian Matching)', fontsize=13)
ax.set_title('Clustering Accuracy: 60 Features vs 9 Features', fontsize=16, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(algos_list, fontsize=13)
ax.legend(fontsize=12, loc='upper right')
ax.set_ylim(0, 0.85)
ax.axhline(y=0.333, color='gray', linestyle=':', linewidth=1, alpha=0.5, label='Random baseline (33.3%)')
ax.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig10_9f_accuracy_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig10_9f_accuracy_comparison.png")

# ============================================================
# FIGURE 11: Comprehensive Radar - All Metrics Comparison
# ============================================================
print("Creating Figure 11: Comprehensive Metrics Radar...")
fig, axes = plt.subplots(1, 3, figsize=(20, 7), subplot_kw=dict(polar=True))

# Metrics to compare (normalize for radar)
metric_labels = ['Silhouette\nScore', 'Calinski-\nHarabasz', 'Davies-\nBouldin (inv)', 
                 'ARI', 'NMI', 'Accuracy']

for idx, algo in enumerate(algos_list):
    ax = axes[idx]
    
    # 60F values
    v60 = [
        metrics_60f.loc[algo, 'Silhouette Score'],
        metrics_60f.loc[algo, 'Calinski-Harabasz Index'] / 100,  # normalize
        1 / (1 + metrics_60f.loc[algo, 'Davies-Bouldin Index']),  # invert
        metrics_60f.loc[algo, 'Adjusted Rand Index'],
        metrics_60f.loc[algo, 'Normalized Mutual Info'],
        metrics_60f.loc[algo, 'Accuracy (Hungarian)']
    ]
    
    # 9F values
    v9 = [
        metrics_9f.loc[algo, 'Silhouette Score'],
        metrics_9f.loc[algo, 'Calinski-Harabasz Index'] / 100,
        1 / (1 + metrics_9f.loc[algo, 'Davies-Bouldin Index']),
        metrics_9f.loc[algo, 'Adjusted Rand Index'],
        metrics_9f.loc[algo, 'Normalized Mutual Info'],
        metrics_9f.loc[algo, 'Accuracy (Hungarian)']
    ]
    
    angles = np.linspace(0, 2*np.pi, len(metric_labels), endpoint=False).tolist()
    angles += angles[:1]
    v60 += v60[:1]
    v9 += v9[:1]
    
    ax.plot(angles, v60, 'o-', color='#1565C0', linewidth=2, label='60 Features')
    ax.fill(angles, v60, color='#1565C0', alpha=0.1)
    ax.plot(angles, v9, 's-', color='#E65100', linewidth=2, label='9 Features')
    ax.fill(angles, v9, color='#E65100', alpha=0.1)
    
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metric_labels, fontsize=8)
    ax.set_title(algo, fontsize=14, fontweight='bold', pad=20)
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=9)

plt.suptitle('Comprehensive Metrics Comparison: 60F vs 9F', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig11_9f_radar_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("  Saved: fig11_9f_radar_comparison.png")

print("\n=== All Visualizations Created Successfully! ===")
