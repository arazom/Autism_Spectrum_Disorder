#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Optimized Autism Severity Classification
=========================================

This script implements SVM and Random Forest classifiers with:
1. SMOTE for class imbalance handling
2. Grid Search with 10-fold cross-validation for hyperparameter tuning
3. Weighted Voting Ensemble Learning

Author: Arazo M. Mustafa
Date: February 2026
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Machine Learning Libraries
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score
)
from imblearn.over_sampling import SMOTE

print("=" * 80)
print("Optimized Autism Severity Classification")
print("تصنيف شدة اضطراب طيف التوحد المحسّن")
print("=" * 80)
print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)
print()

# ============================================================================
# Phase 1: Load and Prepare Enhanced Dataset
# المرحلة 1: تحميل وإعداد البيانات المحسنة
# ============================================================================

print("=" * 80)
print("Phase 1: Loading Enhanced Dataset")
print("المرحلة 1: تحميل البيانات المحسنة")
print("=" * 80)
print()

# Load the enhanced dataset with 56 features
print("📂 Loading enhanced dataset...")
df = pd.read_excel('test_output.xlsx')

print(f"✓ Dataset loaded successfully!")
print(f"  - Number of rows: {len(df)}")
print(f"  - Number of columns: {len(df.columns)}")
print()

# Identify feature columns and target
print("🔍 Identifying features and target...")

# Find the Class column
class_col = None
for col in df.columns:
    if 'class' in col.lower():
        class_col = col
        break

if class_col is None:
    print("❌ Error: Class column not found!")
    exit(1)

print(f"✓ Target column: {class_col}")

# Exclude non-feature columns
exclude_cols = ['ID', 'Name', 'Gender', 'Gender ', 'Age', 'Age  ', 
                'Ethnicity', 'Jaundice', 'Fam_Hist', class_col]
exclude_cols = [col for col in exclude_cols if col in df.columns]

# Get feature columns
feature_cols = [col for col in df.columns if col not in exclude_cols]

print(f"✓ Number of features: {len(feature_cols)}")
print(f"✓ Excluded columns: {len(exclude_cols)}")
print()

# Prepare X and y
X = df[feature_cols].values
y = df[class_col].values

print(f"📊 Dataset shape:")
print(f"  - Features (X): {X.shape}")
print(f"  - Target (y): {y.shape}")
print()

# Check class distribution
print("📊 Original Class Distribution:")
unique, counts = np.unique(y, return_counts=True)
for cls, count in zip(unique, counts):
    percentage = (count / len(y)) * 100
    class_name = ['Mild', 'Moderate', 'Severe'][int(cls)]
    print(f"  - Class {int(cls)} ({class_name}): {count} samples ({percentage:.2f}%)")
print()

# Split data into train and test sets
print("✂️ Splitting data into train (80%) and test (20%) sets...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"✓ Train set: {X_train.shape[0]} samples")
print(f"✓ Test set: {X_test.shape[0]} samples")
print()

# ============================================================================
# Phase 2: Apply SMOTE for Class Imbalance Handling
# المرحلة 2: تطبيق SMOTE لمعالجة عدم التوازن في الفئات
# ============================================================================

print("=" * 80)
print("Phase 2: Applying SMOTE for Class Imbalance Handling")
print("المرحلة 2: تطبيق SMOTE لمعالجة عدم التوازن في الفئات")
print("=" * 80)
print()

print("🔄 Applying SMOTE to balance class distribution...")

# Apply SMOTE
smote = SMOTE(random_state=42, k_neighbors=5)
X_train_balanced, y_train_balanced = smote.fit_resample(X_train, y_train)

print(f"✓ SMOTE applied successfully!")
print()

print("📊 Balanced Class Distribution (Training Set):")
unique, counts = np.unique(y_train_balanced, return_counts=True)
for cls, count in zip(unique, counts):
    percentage = (count / len(y_train_balanced)) * 100
    class_name = ['Mild', 'Moderate', 'Severe'][int(cls)]
    print(f"  - Class {int(cls)} ({class_name}): {count} samples ({percentage:.2f}%)")
print()

print(f"📈 Dataset size after SMOTE:")
print(f"  - Before: {X_train.shape[0]} samples")
print(f"  - After: {X_train_balanced.shape[0]} samples")
print(f"  - Increase: {X_train_balanced.shape[0] - X_train.shape[0]} samples")
print()

# Feature Scaling
print("📏 Applying feature scaling (StandardScaler)...")
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_balanced)
X_test_scaled = scaler.transform(X_test)

print("✓ Feature scaling completed")
print()

# ============================================================================
# Phase 3: Hyperparameter Tuning with Grid Search + 10-fold CV
# المرحلة 3: تحسين المعاملات باستخدام Grid Search + 10-fold CV
# ============================================================================

print("=" * 80)
print("Phase 3: Hyperparameter Tuning with Grid Search + 10-fold CV")
print("المرحلة 3: تحسين المعاملات باستخدام Grid Search + 10-fold CV")
print("=" * 80)
print()

# ============================================================================
# 3.1: SVM Hyperparameter Tuning
# ============================================================================

print("-" * 80)
print("3.1: SVM Hyperparameter Tuning")
print("3.1: تحسين معاملات SVM")
print("-" * 80)
print()

print("🔍 Defining SVM parameter grid...")

# Define parameter grid for SVM
svm_param_grid = {
    'C': [0.1, 1, 10, 100],
    'gamma': ['scale', 'auto', 0.001, 0.01, 0.1],
    'kernel': ['rbf', 'poly', 'sigmoid']
}

print("✓ Parameter grid defined:")
print(f"  - C: {svm_param_grid['C']}")
print(f"  - gamma: {svm_param_grid['gamma']}")
print(f"  - kernel: {svm_param_grid['kernel']}")
print(f"  - Total combinations: {len(svm_param_grid['C']) * len(svm_param_grid['gamma']) * len(svm_param_grid['kernel'])}")
print()

print("⚙️ Running Grid Search for SVM (this may take a few minutes)...")
print("   Using 10-fold cross-validation...")

# Create SVM classifier
svm_base = SVC(random_state=42, probability=True)

# Grid Search with 10-fold CV
svm_grid_search = GridSearchCV(
    estimator=svm_base,
    param_grid=svm_param_grid,
    cv=10,
    scoring='accuracy',
    n_jobs=-1,
    verbose=1
)

# Fit Grid Search
svm_grid_search.fit(X_train_scaled, y_train_balanced)

print()
print("✓ Grid Search completed for SVM!")
print()

print("🏆 Best SVM Parameters:")
for param, value in svm_grid_search.best_params_.items():
    print(f"  - {param}: {value}")
print()

print(f"📊 Best CV Accuracy: {svm_grid_search.best_score_:.4f} ({svm_grid_search.best_score_*100:.2f}%)")
print()

# Get best SVM model
best_svm = svm_grid_search.best_estimator_

# ============================================================================
# 3.2: Random Forest Hyperparameter Tuning
# ============================================================================

print("-" * 80)
print("3.2: Random Forest Hyperparameter Tuning")
print("3.2: تحسين معاملات Random Forest")
print("-" * 80)
print()

print("🔍 Defining Random Forest parameter grid...")

# Define parameter grid for Random Forest
rf_param_grid = {
    'n_estimators': [100, 200, 300, 500],
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2']
}

print("✓ Parameter grid defined:")
print(f"  - n_estimators: {rf_param_grid['n_estimators']}")
print(f"  - max_depth: {rf_param_grid['max_depth']}")
print(f"  - min_samples_split: {rf_param_grid['min_samples_split']}")
print(f"  - min_samples_leaf: {rf_param_grid['min_samples_leaf']}")
print(f"  - max_features: {rf_param_grid['max_features']}")
print(f"  - Total combinations: {len(rf_param_grid['n_estimators']) * len(rf_param_grid['max_depth']) * len(rf_param_grid['min_samples_split']) * len(rf_param_grid['min_samples_leaf']) * len(rf_param_grid['max_features'])}")
print()

print("⚙️ Running Grid Search for Random Forest (this may take a few minutes)...")
print("   Using 10-fold cross-validation...")

# Create Random Forest classifier
rf_base = RandomForestClassifier(random_state=42)

# Grid Search with 10-fold CV
rf_grid_search = GridSearchCV(
    estimator=rf_base,
    param_grid=rf_param_grid,
    cv=10,
    scoring='accuracy',
    n_jobs=-1,
    verbose=1
)

# Fit Grid Search
rf_grid_search.fit(X_train_scaled, y_train_balanced)

print()
print("✓ Grid Search completed for Random Forest!")
print()

print("🏆 Best Random Forest Parameters:")
for param, value in rf_grid_search.best_params_.items():
    print(f"  - {param}: {value}")
print()

print(f"📊 Best CV Accuracy: {rf_grid_search.best_score_:.4f} ({rf_grid_search.best_score_*100:.2f}%)")
print()

# Get best Random Forest model
best_rf = rf_grid_search.best_estimator_

# ============================================================================
# Phase 4: Ensemble Learning - Weighted Voting
# المرحلة 4: التعلم الجماعي - التصويت الموزون
# ============================================================================

print("=" * 80)
print("Phase 4: Ensemble Learning - Weighted Voting")
print("المرحلة 4: التعلم الجماعي - التصويت الموزون")
print("=" * 80)
print()

print("🔧 Creating Weighted Voting Ensemble...")

# Create ensemble with weighted voting
# Weights are based on cross-validation performance
svm_weight = svm_grid_search.best_score_
rf_weight = rf_grid_search.best_score_

# Normalize weights
total_weight = svm_weight + rf_weight
svm_weight_norm = svm_weight / total_weight
rf_weight_norm = rf_weight / total_weight

print(f"📊 Ensemble Weights (based on CV performance):")
print(f"  - SVM weight: {svm_weight_norm:.4f} (CV accuracy: {svm_weight:.4f})")
print(f"  - Random Forest weight: {rf_weight_norm:.4f} (CV accuracy: {rf_weight:.4f})")
print()

# Create voting classifier
ensemble = VotingClassifier(
    estimators=[
        ('svm', best_svm),
        ('rf', best_rf)
    ],
    voting='soft',
    weights=[svm_weight_norm, rf_weight_norm]
)

print("⚙️ Training Ensemble Model...")
ensemble.fit(X_train_scaled, y_train_balanced)

print("✓ Ensemble model trained successfully!")
print()

# ============================================================================
# Phase 5: Model Evaluation
# المرحلة 5: تقييم النماذج
# ============================================================================

print("=" * 80)
print("Phase 5: Model Evaluation")
print("المرحلة 5: تقييم النماذج")
print("=" * 80)
print()

# Evaluate all three models
models = {
    'SVM': best_svm,
    'Random Forest': best_rf,
    'Ensemble (Weighted Voting)': ensemble
}

results = {}

for model_name, model in models.items():
    print("-" * 80)
    print(f"Evaluating: {model_name}")
    print("-" * 80)
    print()
    
    # Make predictions
    y_pred = model.predict(X_test_scaled)
    y_pred_proba = model.predict_proba(X_test_scaled)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
    
    # Store results
    results[model_name] = {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'y_pred': y_pred,
        'y_pred_proba': y_pred_proba,
        'confusion_matrix': confusion_matrix(y_test, y_pred)
    }
    
    # Print metrics
    print(f"📊 Performance Metrics:")
    print(f"  - Accuracy:  {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"  - Precision: {precision:.4f} ({precision*100:.2f}%)")
    print(f"  - Recall:    {recall:.4f} ({recall*100:.2f}%)")
    print(f"  - F1-Score:  {f1:.4f} ({f1*100:.2f}%)")
    print()
    
    # Print confusion matrix
    print("📊 Confusion Matrix:")
    cm = results[model_name]['confusion_matrix']
    print("           Predicted")
    print("           Mild  Moderate  Severe")
    print(f"Actual Mild      {cm[0][0]:3d}     {cm[0][1]:3d}     {cm[0][2]:3d}")
    print(f"       Moderate  {cm[1][0]:3d}     {cm[1][1]:3d}     {cm[1][2]:3d}")
    print(f"       Severe    {cm[2][0]:3d}     {cm[2][1]:3d}     {cm[2][2]:3d}")
    print()
    
    # Classification report
    print("📊 Classification Report:")
    print(classification_report(y_test, y_pred, 
                                target_names=['Mild', 'Moderate', 'Severe'],
                                zero_division=0))
    print()

# ============================================================================
# Summary and Comparison
# ============================================================================

print("=" * 80)
print("Summary and Comparison")
print("الملخص والمقارنة")
print("=" * 80)
print()

print("📊 Model Performance Comparison:")
print()
print(f"{'Model':<30} {'Accuracy':<12} {'Precision':<12} {'Recall':<12} {'F1-Score':<12}")
print("-" * 78)

for model_name, metrics in results.items():
    print(f"{model_name:<30} {metrics['accuracy']:.4f} ({metrics['accuracy']*100:.2f}%)  "
          f"{metrics['precision']:.4f} ({metrics['precision']*100:.2f}%)  "
          f"{metrics['recall']:.4f} ({metrics['recall']*100:.2f}%)  "
          f"{metrics['f1']:.4f} ({metrics['f1']*100:.2f}%)")

print()

# Find best model
best_model_name = max(results, key=lambda x: results[x]['accuracy'])
best_accuracy = results[best_model_name]['accuracy']

print(f"🏆 Best Model: {best_model_name}")
print(f"🏆 Best Accuracy: {best_accuracy:.4f} ({best_accuracy*100:.2f}%)")
print()

# Save results to file
print("💾 Saving results to file...")

with open('classification_results.txt', 'w', encoding='utf-8') as f:
    f.write("=" * 80 + "\n")
    f.write("Optimized Autism Severity Classification Results\n")
    f.write("نتائج تصنيف شدة اضطراب طيف التوحد المحسّن\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    
    f.write("Dataset Information:\n")
    f.write(f"  - Total samples: {len(df)}\n")
    f.write(f"  - Number of features: {len(feature_cols)}\n")
    f.write(f"  - Train samples: {X_train.shape[0]}\n")
    f.write(f"  - Test samples: {X_test.shape[0]}\n")
    f.write(f"  - Samples after SMOTE: {X_train_balanced.shape[0]}\n\n")
    
    f.write("Optimization Techniques Applied:\n")
    f.write("  1. SMOTE for class imbalance handling\n")
    f.write("  2. Grid Search with 10-fold cross-validation\n")
    f.write("  3. Weighted Voting Ensemble Learning\n\n")
    
    f.write("=" * 80 + "\n")
    f.write("Model Performance Comparison\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"{'Model':<30} {'Accuracy':<12} {'Precision':<12} {'Recall':<12} {'F1-Score':<12}\n")
    f.write("-" * 78 + "\n")
    
    for model_name, metrics in results.items():
        f.write(f"{model_name:<30} {metrics['accuracy']:.4f} ({metrics['accuracy']*100:.2f}%)  "
                f"{metrics['precision']:.4f} ({metrics['precision']*100:.2f}%)  "
                f"{metrics['recall']:.4f} ({metrics['recall']*100:.2f}%)  "
                f"{metrics['f1']:.4f} ({metrics['f1']*100:.2f}%)\n")
    
    f.write("\n")
    f.write(f"Best Model: {best_model_name}\n")
    f.write(f"Best Accuracy: {best_accuracy:.4f} ({best_accuracy*100:.2f}%)\n")

print("✓ Results saved to: classification_results.txt")
print()

# Create visualization
print("📊 Creating performance visualization...")

fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# Plot 1: Accuracy Comparison
model_names = list(results.keys())
accuracies = [results[m]['accuracy'] * 100 for m in model_names]

axes[0].bar(range(len(model_names)), accuracies, color=['#3498db', '#2ecc71', '#e74c3c'])
axes[0].set_xticks(range(len(model_names)))
axes[0].set_xticklabels(model_names, rotation=15, ha='right')
axes[0].set_ylabel('Accuracy (%)')
axes[0].set_title('Model Accuracy Comparison')
axes[0].set_ylim([0, 100])
axes[0].grid(axis='y', alpha=0.3)

for i, v in enumerate(accuracies):
    axes[0].text(i, v + 1, f'{v:.2f}%', ha='center', va='bottom', fontweight='bold')

# Plot 2: All Metrics Comparison
metrics_names = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
x = np.arange(len(metrics_names))
width = 0.25

for i, model_name in enumerate(model_names):
    metrics_values = [
        results[model_name]['accuracy'] * 100,
        results[model_name]['precision'] * 100,
        results[model_name]['recall'] * 100,
        results[model_name]['f1'] * 100
    ]
    axes[1].bar(x + i*width, metrics_values, width, label=model_name)

axes[1].set_ylabel('Score (%)')
axes[1].set_title('All Metrics Comparison')
axes[1].set_xticks(x + width)
axes[1].set_xticklabels(metrics_names)
axes[1].legend()
axes[1].set_ylim([0, 100])
axes[1].grid(axis='y', alpha=0.3)

# Plot 3: Confusion Matrix for Best Model
cm = results[best_model_name]['confusion_matrix']
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[2],
            xticklabels=['Mild', 'Moderate', 'Severe'],
            yticklabels=['Mild', 'Moderate', 'Severe'])
axes[2].set_title(f'Confusion Matrix - {best_model_name}')
axes[2].set_ylabel('Actual')
axes[2].set_xlabel('Predicted')

plt.tight_layout()
plt.savefig('classification_results.png', dpi=300, bbox_inches='tight')
print("✓ Visualization saved to: classification_results.png")
print()

# ============================================================================
# Final Summary
# ============================================================================

print("=" * 80)
print("✅ Classification Completed Successfully!")
print("✅ اكتمل التصنيف بنجاح!")
print("=" * 80)
print()

print("📁 Output Files:")
print("  1. classification_results.txt - Detailed results report")
print("  2. classification_results.png - Performance visualization")
print()

print(f"End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)
