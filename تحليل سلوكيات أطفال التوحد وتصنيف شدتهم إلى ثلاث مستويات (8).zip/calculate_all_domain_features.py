import pandas as pd
import numpy as np

print("=" * 80)
print("حساب المتوسطات والمجاميع لجميع الأطفال")
print("Calculating Means and Totals for All Children")
print("=" * 80)
print()

# Load the original dataset
df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

print(f"عدد الأطفال / Number of children: {len(df)}")
print(f"عدد الأعمدة الأصلية / Original columns: {len(df.columns)}")
print()

# Define clinical domains with their attributes (exact column names)
domains = {
    'Social_Interaction_Mean': [
        '1childName_response',
        '2ChildEye_contact',
        '9ChildSymbolic_play',
        '10ChildShared_attention',
        '15Child_empathy',
        '21ChildChecks_reactions'
    ],
    'Communication_Mean': [
        '4ChildSpeech_clarity',
        '5ChildRequest_pointing ',
        '6ChildJoint_attention',
        '12ChildHand_prompting',
        '18ChildEchoin_voice',
        '19ChildGesture_use'
    ],
    'Repetitive_Behaviors_Mean': [
        '3ChildObject_lining',
        '7ChildRestriced_interests\n',
        '13Child_walkONtiptoe',
        '16Child_Repetitive_behaviors',
        '20ChildFinger_move',
        '22ChildFocused_attention',
        '23ChildRepetitive_manipulation',
        '25ChildBlank_staring'
    ],
    'Sensory_Sensitivity_Mean': [
        '11ChildSensory_seeking',
        '24ChildNoise_sensitivity'
    ],
    'Language_Development_Mean': [
        '8ChildVocabulary_size',
        '17ChildFirst_words\n',
        '14ChildAdaptability_Flexibility'
    ]
}

print("حساب المتوسطات لكل مجال سريري...")
print("Calculating means for each clinical domain...")
print()

# Calculate means for each domain
for domain_name, attributes in domains.items():
    df[domain_name] = df[attributes].mean(axis=1)
    print(f"✓ {domain_name} محسوب / calculated")

print()
print("حساب المجموع الكلي والمعدل العام...")
print("Calculating Total Sum and General Average...")
print()

# Get all behavioral attribute columns (25 columns)
behavioral_cols = [col for col in df.columns if 'Child' in col or 'child' in col]
print(f"عدد السمات السلوكية / Number of behavioral attributes: {len(behavioral_cols)}")

# Calculate Total_Sum: sum of all 25 behavioral attributes
df['Total_Sum'] = df[behavioral_cols].sum(axis=1)
print("✓ Total_Sum محسوب / calculated")

# Calculate General_Average: average of all 25 behavioral attributes
df['General_Average'] = df[behavioral_cols].mean(axis=1)
print("✓ General_Average محسوب / calculated")

print()
print("=" * 80)
print("ملخص الأعمدة الجديدة / Summary of New Columns")
print("=" * 80)
print()

new_columns = [
    'Social_Interaction_Mean',
    'Communication_Mean',
    'Repetitive_Behaviors_Mean',
    'Sensory_Sensitivity_Mean',
    'Language_Development_Mean',
    'Total_Sum',
    'General_Average'
]

print(f"عدد الأعمدة الجديدة / Number of new columns: {len(new_columns)}")
print()
print("الأعمدة الجديدة / New columns:")
for i, col in enumerate(new_columns, 1):
    print(f"  {i}. {col}")

print()
print("=" * 80)
print("عينة من البيانات (أول 5 أطفال)")
print("Sample Data (First 5 Children)")
print("=" * 80)
print()

# Display sample data
sample_df = df[['Class'] + new_columns].head(5)
print(sample_df.to_string(index=True))

print()
print("=" * 80)
print("الإحصائيات الوصفية / Descriptive Statistics")
print("=" * 80)
print()

stats_df = df[new_columns].describe()
print(stats_df.to_string())

print()
print("=" * 80)
print("حفظ البيانات في ملف Excel جديد...")
print("Saving data to new Excel file...")
print("=" * 80)
print()

# Create new dataset with original columns + new columns
output_df = df.copy()

# Save to Excel
output_file = '/home/ubuntu/Dataset_With_Domain_Means.xlsx'
output_df.to_excel(output_file, index=False)

print(f"✓ تم الحفظ بنجاح / Saved successfully!")
print(f"✓ اسم الملف / File name: Dataset_With_Domain_Means.xlsx")
print(f"✓ عدد الصفوف / Number of rows: {len(output_df)}")
print(f"✓ عدد الأعمدة / Number of columns: {len(output_df.columns)}")
print(f"  - الأعمدة الأصلية / Original columns: {len(df.columns) - len(new_columns)}")
print(f"  - الأعمدة الجديدة / New columns: {len(new_columns)}")

print()
print("=" * 80)
print("تفاصيل الأعمدة الجديدة / Details of New Columns")
print("=" * 80)
print()

print("1. Social_Interaction_Mean")
print("   - عدد السمات / Number of attributes: 6")
print("   - النطاق / Range: [0.0, 4.0]")
print()

print("2. Communication_Mean")
print("   - عدد السمات / Number of attributes: 6")
print("   - النطاق / Range: [0.0, 4.0]")
print()

print("3. Repetitive_Behaviors_Mean")
print("   - عدد السمات / Number of attributes: 8")
print("   - النطاق / Range: [0.0, 4.0]")
print()

print("4. Sensory_Sensitivity_Mean")
print("   - عدد السمات / Number of attributes: 2")
print("   - النطاق / Range: [0.0, 4.0]")
print()

print("5. Language_Development_Mean")
print("   - عدد السمات / Number of attributes: 3")
print("   - النطاق / Range: [0.0, 4.0]")
print()

print("6. Total_Sum")
print("   - الوصف / Description: مجموع جميع السمات السلوكية الـ 25")
print("   - Description: Sum of all 25 behavioral attributes")
print("   - النطاق / Range: [0, 100]")
print()

print("7. General_Average")
print("   - الوصف / Description: متوسط جميع السمات السلوكية الـ 25")
print("   - Description: Average of all 25 behavioral attributes")
print("   - النطاق / Range: [0.0, 4.0]")
print()

print("=" * 80)
print("✓ العملية اكتملت بنجاح!")
print("✓ Process completed successfully!")
print("=" * 80)
