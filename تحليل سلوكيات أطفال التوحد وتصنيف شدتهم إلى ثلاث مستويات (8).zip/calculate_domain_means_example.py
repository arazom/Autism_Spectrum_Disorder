import pandas as pd
import numpy as np

# Load the original dataset
df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

# Get first 5 children
first_5 = df.head(5)

# Define clinical domains with their attributes (exact column names from dataset)
domains = {
    'Social_Interaction': [
        '1childName_response',
        '2ChildEye_contact',
        '9ChildSymbolic_play',
        '10ChildShared_attention',
        '15Child_empathy',
        '21ChildChecks_reactions'
    ],
    'Communication': [
        '4ChildSpeech_clarity',
        '5ChildRequest_pointing ',
        '6ChildJoint_attention',
        '12ChildHand_prompting',
        '18ChildEchoin_voice',
        '19ChildGesture_use'
    ],
    'Repetitive_Behaviors': [
        '3ChildObject_lining',
        '7ChildRestriced_interests\n',
        '13Child_walkONtiptoe',
        '16Child_Repetitive_behaviors',
        '20ChildFinger_move',
        '22ChildFocused_attention',
        '23ChildRepetitive_manipulation',
        '25ChildBlank_staring'
    ],
    'Sensory_Sensitivity': [
        '11ChildSensory_seeking',
        '24ChildNoise_sensitivity'
    ],
    'Language_Development': [
        '8ChildVocabulary_size',
        '17ChildFirst_words\n',
        '14ChildAdaptability_Flexibility'
    ]
}

print("=" * 80)
print("بيانات أول 5 أطفال من الملف الأصلي")
print("First 5 Children from Original Dataset")
print("=" * 80)
print()

# Display class distribution
print("توزيع الفئات / Class distribution:")
for idx in range(5):
    class_label = int(first_5.iloc[idx]['Class'])
    class_name = {0: 'خفيف/Mild', 1: 'متوسط/Moderate', 2: 'شديد/Severe'}[class_label]
    print(f"  طفل {idx+1} / Child {idx+1}: {class_name}")
print()

# Calculate means for each child and domain
for child_idx in range(5):
    print(f"\n{'='*80}")
    print(f"الطفل {child_idx+1} / CHILD {child_idx+1}")
    print(f"{'='*80}")
    
    child_data = first_5.iloc[child_idx]
    class_label = int(child_data['Class'])
    class_name = {0: 'خفيف/Mild', 1: 'متوسط/Moderate', 2: 'شديد/Severe'}[class_label]
    print(f"الفئة / Class: {class_name}\n")
    
    for domain_name, attributes in domains.items():
        print(f"\n{domain_name}:")
        print("-" * 60)
        
        values = []
        for attr in attributes:
            value = int(child_data[attr])
            values.append(value)
            # Clean attribute name for display
            clean_name = attr.strip().replace('Child', '').replace('child', '').replace('\n', '')
            print(f"  {clean_name:30s} = {value}")
        
        # Calculate mean
        mean_value = np.mean(values)
        print(f"\n  المتوسط الحسابي / Mean = ({' + '.join(map(str, values))}) / {len(values)}")
        print(f"  المتوسط الحسابي / Mean = {sum(values)} / {len(values)} = {mean_value:.4f}")
        print(f"  النطاق / Range: [0, 4]")

print("\n" + "=" * 80)
print("ملخص المتوسطات لجميع الأطفال")
print("Summary of Means for All Children")
print("=" * 80)
print()

# Create summary table
summary_data = []
for child_idx in range(5):
    child_data = first_5.iloc[child_idx]
    class_label = int(child_data['Class'])
    row = {'Child': child_idx + 1, 'Class': {0: 'Mild', 1: 'Moderate', 2: 'Severe'}[class_label]}
    
    for domain_name, attributes in domains.items():
        values = [int(child_data[attr]) for attr in attributes]
        mean_value = np.mean(values)
        row[domain_name] = round(mean_value, 4)
    
    summary_data.append(row)

summary_df = pd.DataFrame(summary_data)
print(summary_df.to_string(index=False))

print("\n" + "=" * 80)
print("الصيغة الرياضية العامة")
print("General Mathematical Formula")
print("=" * 80)
print()
print("لكل مجال سريري:")
print("For each clinical domain:")
print()
print("Mean_Domain = (Σ attributes) / n")
print()
print("حيث / where:")
print("  - Σ attributes = مجموع قيم جميع السمات في المجال")
print("  - Σ attributes = sum of all attribute values in the domain")
print("  - n = عدد السمات في المجال")
print("  - n = number of attributes in the domain")
print()
print("مثال / Example:")
print("  Social_Interaction_Mean = (Name_response + Eye_contact + Symbolic_play +")
print("                             Shared_attention + empathy + Checks_reactions) / 6")
print()
print("النطاق / Range:")
print("  - جميع القيم الأصلية: [0, 4]")
print("  - All original values: [0, 4]")
print("  - المتوسط الحسابي: [0.0, 4.0]")
print("  - Mean values: [0.0, 4.0]")
print()
print("=" * 80)
print("ملاحظات مهمة / Important Notes")
print("=" * 80)
print()
print("1. المتوسط الحسابي يحافظ على النطاق الأصلي [0, 4]")
print("   The mean preserves the original range [0, 4]")
print()
print("2. يتم حساب متوسط منفصل لكل مجال سريري")
print("   A separate mean is calculated for each clinical domain")
print()
print("3. هذه الخاصية الجديدة تُضاف إلى مجموعة البيانات المحسّنة")
print("   This new feature is added to the enhanced dataset")
print()
print("4. المتوسط يعكس الشدة العامة في كل مجال")
print("   The mean reflects the overall severity in each domain")
