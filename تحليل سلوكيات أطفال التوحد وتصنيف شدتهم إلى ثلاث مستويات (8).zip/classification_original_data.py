#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Classification on Original Data (25 Behavioral Features Only)
==============================================================

This script applies SVM and Random Forest with all optimizations
on the original dataset (25 behavioral features only, no feature engineering).

Optimizations applied:
1. SMOTE for class imbalance handling
2. Grid Search with 10-fold cross-validation
3. Weighted Voting Ensemble

Author: Arazo M. Mustafa
Date: February 2026
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Machine Learning Libraries
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                            f1_score, classification_report, confusion_matrix)
from imblearn.over_sampling import SMOTE

print("=" * 80)
print("Classification on Original Data (25 Behavioral Features)")
print("التصنيف على البيانات الأصلية (25 سمة سلوكية)")
print("=" * 80)
print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)
print()

# ============================================================================
# Phase 1: Load and Prepare Original Data
# المرحلة 1: تحميل وإعداد البيانات الأصلية
# ============================================================================

print("=" * 80)
print("Phase 1: Loading Original Dataset")
print("المرحلة 1: تحميل البيانات الأصلية")
print("=" * 80)
print()

# Load original dataset
print("📂 Loading original dataset...")
df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

print(f"✓ Dataset loaded: {len(df)} rows × {len(df.columns)} columns")
print()

# Display first few rows
print("First 5 rows:")
print(df.head())
print()

# Identify target column
class_col = None
for col in df.columns:
    if 'class' in col.lower():
        class_col = col
        break

print(f"Target column: {class_col}")
print()

# Identify behavioral features (columns with "Child" in name)
behavioral_cols = [col for col in df.columns if 'Child' in col or 'child' in col]

print(f"📊 Behavioral features identified: {len(behavioral_cols)}")
print()

# Display behavioral features
print("Behavioral Features:")
for i, col in enumerate(behavioral_cols, 1):
    print(f"  {i:2d}. {col}")
print()

# Check class distribution
print("Class Distribution:")
print(df[class_col].value_counts())
print()
print("Class Percentages:")
print(df[class_col].value_counts(normalize=True) * 100)
print()

# Prepare X and y
X = df[behavioral_cols].values
y = df[class_col].values

print(f"✓ X shape: {X.shape}")
print(f"✓ y shape: {y.shape}")
print()

# Check for missing values
missing_count = np.sum(np.isnan(X))
if missing_count > 0:
    print(f"⚠️ Warning: {missing_count} missing values detected")
    print("   Filling with column means...")
    from sklearn.impute import SimpleImputer
    imputer = SimpleImputer(strategy='mean')
    X = imputer.fit_transform(X)
    print("✓ Missing values filled")
    print()

# Split data (80% train, 20% test)
print("Splitting data (80% train, 20% test)...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"✓ Train set: {X_train.shape[0]} samples")
print(f"✓ Test set: {X_test.shape[0]} samples")
print()

print("Train set class distribution:")
unique, counts = np.unique(y_train, return_counts=True)
for cls, cnt in zip(unique, counts):
    print(f"  {cls}: {cnt} ({cnt/len(y_train)*100:.1f}%)")
print()

# ============================================================================
# Phase 2: Apply SMOTE
# المرحلة 2: تطبيق SMOTE
# ============================================================================

print("=" * 80)
print("Phase 2: Applying SMOTE for Class Imbalance")
print("المرحلة 2: تطبيق SMOTE لمعالجة عدم التوازن")
print("=" * 80)
print()

print("🔄 Applying SMOTE...")
smote = SMOTE(random_state=42, k_neighbors=5)
X_train_balanced, y_train_balanced = smote.fit_resample(X_train, y_train)

print(f"✓ Original training set: {X_train.shape[0]} samples")
print(f"✓ Balanced training set: {X_train_balanced.shape[0]} samples")
print()

print("Balanced train set class distribution:")
unique, counts = np.unique(y_train_balanced, return_counts=True)
for cls, cnt in zip(unique, counts):
    print(f"  {cls}: {cnt} ({cnt/len(y_train_balanced)*100:.1f}%)")
print()

# Feature Scaling
print("📏 Applying feature scaling (StandardScaler)...")
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_balanced)
X_test_scaled = scaler.transform(X_test)

print("✓ Feature scaling completed")
print()

# ============================================================================
# Phase 3: Grid Search for SVM
# المرحلة 3: Grid Search لـ SVM
# ============================================================================

print("=" * 80)
print("Phase 3: Grid Search for SVM with 10-Fold CV")
print("المرحلة 3: Grid Search لـ SVM مع 10-Fold CV")
print("=" * 80)
print()

print("⚙️ Setting up SVM Grid Search...")
print("   This may take several minutes...")
print()

# SVM parameter grid
svm_param_grid = {
    'C': [0.1, 1, 10],
    'kernel': ['linear', 'rbf', 'sigmoid'],
    'gamma': ['scale', 'auto']
}

print("Parameter grid:")
for param, values in svm_param_grid.items():
    print(f"  {param}: {values}")
print()

total_combinations = np.prod([len(v) for v in svm_param_grid.values()])
print(f"Total combinations: {total_combinations}")
print(f"Total fits: {total_combinations * 10} (10-fold CV)")
print()

# Create SVM model
svm_model = SVC(random_state=42, probability=True)

# Grid Search with 10-fold CV
svm_grid_search = GridSearchCV(
    estimator=svm_model,
    param_grid=svm_param_grid,
    cv=10,
    scoring='accuracy',
    n_jobs=-1,
    verbose=1
)

print("🔍 Running Grid Search for SVM...")
svm_grid_search.fit(X_train_scaled, y_train_balanced)

print()
print("✓ SVM Grid Search completed!")
print()

# Best parameters
print("Best SVM Parameters:")
for param, value in svm_grid_search.best_params_.items():
    print(f"  {param}: {value}")
print()

# Best CV score
print(f"Best CV Accuracy: {svm_grid_search.best_score_:.4f} ({svm_grid_search.best_score_*100:.2f}%)")
print()

# Train final SVM with best parameters
print("⚙️ Training final SVM model with best parameters...")
best_svm = svm_grid_search.best_estimator_
svm_pred = best_svm.predict(X_test_scaled)
svm_accuracy = accuracy_score(y_test, svm_pred)

print(f"✓ SVM Test Accuracy: {svm_accuracy:.4f} ({svm_accuracy*100:.2f}%)")
print()

# ============================================================================
# Phase 4: Grid Search for Random Forest
# المرحلة 4: Grid Search لـ Random Forest
# ============================================================================

print("=" * 80)
print("Phase 4: Grid Search for Random Forest with 10-Fold CV")
print("المرحلة 4: Grid Search لـ Random Forest مع 10-Fold CV")
print("=" * 80)
print()

print("⚙️ Setting up Random Forest Grid Search...")
print("   This may take several minutes...")
print()

# Random Forest parameter grid
rf_param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2']
}

print("Parameter grid:")
for param, values in rf_param_grid.items():
    print(f"  {param}: {values}")
print()

total_combinations = np.prod([len(v) for v in rf_param_grid.values()])
print(f"Total combinations: {total_combinations}")
print(f"Total fits: {total_combinations * 10} (10-fold CV)")
print()

# Create Random Forest model
rf_model = RandomForestClassifier(random_state=42, n_jobs=-1)

# Grid Search with 10-fold CV
rf_grid_search = GridSearchCV(
    estimator=rf_model,
    param_grid=rf_param_grid,
    cv=10,
    scoring='accuracy',
    n_jobs=-1,
    verbose=1
)

print("🔍 Running Grid Search for Random Forest...")
rf_grid_search.fit(X_train_scaled, y_train_balanced)

print()
print("✓ Random Forest Grid Search completed!")
print()

# Best parameters
print("Best Random Forest Parameters:")
for param, value in rf_grid_search.best_params_.items():
    print(f"  {param}: {value}")
print()

# Best CV score
print(f"Best CV Accuracy: {rf_grid_search.best_score_:.4f} ({rf_grid_search.best_score_*100:.2f}%)")
print()

# Train final Random Forest with best parameters
print("⚙️ Training final Random Forest model with best parameters...")
best_rf = rf_grid_search.best_estimator_
rf_pred = best_rf.predict(X_test_scaled)
rf_accuracy = accuracy_score(y_test, rf_pred)

print(f"✓ Random Forest Test Accuracy: {rf_accuracy:.4f} ({rf_accuracy*100:.2f}%)")
print()

# ============================================================================
# Phase 5: Weighted Voting Ensemble
# المرحلة 5: Weighted Voting Ensemble
# ============================================================================

print("=" * 80)
print("Phase 5: Creating Weighted Voting Ensemble")
print("المرحلة 5: إنشاء Weighted Voting Ensemble")
print("=" * 80)
print()

# Calculate weights based on CV scores
svm_cv_score = svm_grid_search.best_score_
rf_cv_score = rf_grid_search.best_score_

total_score = svm_cv_score + rf_cv_score
svm_weight = svm_cv_score / total_score
rf_weight = rf_cv_score / total_score

print("Calculating weights based on CV scores:")
print(f"  SVM CV Score: {svm_cv_score:.4f}")
print(f"  RF CV Score: {rf_cv_score:.4f}")
print()
print(f"  SVM Weight: {svm_weight:.4f} ({svm_weight*100:.2f}%)")
print(f"  RF Weight: {rf_weight:.4f} ({rf_weight*100:.2f}%)")
print()

# Create Weighted Voting Ensemble
print("⚙️ Creating Weighted Voting Ensemble...")
ensemble = VotingClassifier(
    estimators=[
        ('svm', best_svm),
        ('rf', best_rf)
    ],
    voting='soft',
    weights=[svm_weight, rf_weight]
)

ensemble.fit(X_train_scaled, y_train_balanced)
ensemble_pred = ensemble.predict(X_test_scaled)
ensemble_accuracy = accuracy_score(y_test, ensemble_pred)

print(f"✓ Ensemble Test Accuracy: {ensemble_accuracy:.4f} ({ensemble_accuracy*100:.2f}%)")
print()

# ============================================================================
# Phase 6: Detailed Evaluation
# المرحلة 6: التقييم التفصيلي
# ============================================================================

print("=" * 80)
print("Phase 6: Detailed Model Evaluation")
print("المرحلة 6: التقييم التفصيلي للنماذج")
print("=" * 80)
print()

# Calculate all metrics for each model
models = {
    'SVM': (best_svm, svm_pred),
    'Random Forest': (best_rf, rf_pred),
    'Ensemble': (ensemble, ensemble_pred)
}

results = []

for model_name, (model, predictions) in models.items():
    print(f"{'='*60}")
    print(f"{model_name} Results")
    print(f"{'='*60}")
    print()
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, average='weighted', zero_division=0)
    recall = recall_score(y_test, predictions, average='weighted', zero_division=0)
    f1 = f1_score(y_test, predictions, average='weighted', zero_division=0)
    
    results.append({
        'Model': model_name,
        'Accuracy': accuracy,
        'Precision': precision,
        'Recall': recall,
        'F1-Score': f1
    })
    
    print(f"Accuracy:  {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"Precision: {precision:.4f} ({precision*100:.2f}%)")
    print(f"Recall:    {recall:.4f} ({recall*100:.2f}%)")
    print(f"F1-Score:  {f1:.4f} ({f1*100:.2f}%)")
    print()
    
    # Classification report
    print("Classification Report:")
    print(classification_report(y_test, predictions, zero_division=0))
    print()
    
    # Confusion matrix
    print("Confusion Matrix:")
    cm = confusion_matrix(y_test, predictions)
    print(cm)
    print()

# ============================================================================
# Phase 7: Visualization
# المرحلة 7: التصور البياني
# ============================================================================

print("=" * 80)
print("Phase 7: Creating Visualizations")
print("المرحلة 7: إنشاء الرسوم البيانية")
print("=" * 80)
print()

# Create comprehensive visualization
fig = plt.figure(figsize=(20, 12))

# Plot 1: Accuracy Comparison
ax1 = plt.subplot(2, 3, 1)
model_names = [r['Model'] for r in results]
accuracies = [r['Accuracy'] * 100 for r in results]
colors = ['#3498db', '#2ecc71', '#9b59b6']
bars = ax1.bar(model_names, accuracies, color=colors, alpha=0.8, edgecolor='black')
ax1.set_ylabel('Accuracy (%)', fontsize=12, fontweight='bold')
ax1.set_title('Model Accuracy Comparison\nمقارنة دقة النماذج', fontsize=14, fontweight='bold')
ax1.set_ylim([0, 100])
ax1.grid(axis='y', alpha=0.3)

# Add value labels on bars
for bar in bars:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height,
            f'{height:.2f}%', ha='center', va='bottom', fontsize=11, fontweight='bold')

# Plot 2: All Metrics Comparison
ax2 = plt.subplot(2, 3, 2)
metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
x = np.arange(len(metrics))
width = 0.25

for i, result in enumerate(results):
    values = [result[m] * 100 for m in metrics]
    ax2.bar(x + i*width, values, width, label=result['Model'], color=colors[i], alpha=0.8)

ax2.set_ylabel('Score (%)', fontsize=12, fontweight='bold')
ax2.set_title('All Metrics Comparison\nمقارنة جميع المقاييس', fontsize=14, fontweight='bold')
ax2.set_xticks(x + width)
ax2.set_xticklabels(metrics, rotation=45, ha='right')
ax2.legend()
ax2.set_ylim([0, 100])
ax2.grid(axis='y', alpha=0.3)

# Plot 3: Confusion Matrix for Best Model (Ensemble)
ax3 = plt.subplot(2, 3, 3)
cm = confusion_matrix(y_test, ensemble_pred)
classes = np.unique(y_test)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, 
            yticklabels=classes, ax=ax3, cbar_kws={'label': 'Count'})
ax3.set_xlabel('Predicted Label', fontsize=12, fontweight='bold')
ax3.set_ylabel('True Label', fontsize=12, fontweight='bold')
ax3.set_title('Confusion Matrix - Ensemble\nمصفوفة الالتباس', fontsize=14, fontweight='bold')

# Plot 4: Per-Class Performance (Ensemble)
ax4 = plt.subplot(2, 3, 4)
report = classification_report(y_test, ensemble_pred, output_dict=True, zero_division=0)
classes_list = [c for c in report.keys() if c not in ['accuracy', 'macro avg', 'weighted avg']]
metrics_per_class = ['precision', 'recall', 'f1-score']

x = np.arange(len(classes_list))
width = 0.25

for i, metric in enumerate(metrics_per_class):
    values = [report[c][metric] * 100 for c in classes_list]
    ax4.bar(x + i*width, values, width, label=metric.capitalize(), alpha=0.8)

ax4.set_ylabel('Score (%)', fontsize=12, fontweight='bold')
ax4.set_title('Per-Class Performance - Ensemble\nالأداء لكل فئة', fontsize=14, fontweight='bold')
ax4.set_xticks(x + width)
ax4.set_xticklabels(classes_list, rotation=45, ha='right')
ax4.legend()
ax4.set_ylim([0, 100])
ax4.grid(axis='y', alpha=0.3)

# Plot 5: Class Distribution (Original vs SMOTE)
ax5 = plt.subplot(2, 3, 5)
unique_orig, counts_orig = np.unique(y_train, return_counts=True)
unique_smote, counts_smote = np.unique(y_train_balanced, return_counts=True)

x = np.arange(len(unique_orig))
width = 0.35

bars1 = ax5.bar(x - width/2, counts_orig, width, label='Original', color='#e74c3c', alpha=0.8)
bars2 = ax5.bar(x + width/2, counts_smote, width, label='After SMOTE', color='#2ecc71', alpha=0.8)

ax5.set_ylabel('Count', fontsize=12, fontweight='bold')
ax5.set_title('Class Distribution: Original vs SMOTE\nتوزيع الفئات', fontsize=14, fontweight='bold')
ax5.set_xticks(x)
ax5.set_xticklabels(unique_orig)
ax5.legend()
ax5.grid(axis='y', alpha=0.3)

# Add value labels
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        ax5.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom', fontsize=9)

# Plot 6: Model Comparison Summary
ax6 = plt.subplot(2, 3, 6)
ax6.axis('off')

summary_text = f"""
{'='*50}
CLASSIFICATION RESULTS SUMMARY
ملخص نتائج التصنيف
{'='*50}

Dataset: Original (25 Behavioral Features)
مجموعة البيانات: الأصلية (25 سمة سلوكية)

Total Samples: {len(df)}
Training Samples: {X_train.shape[0]} → {X_train_balanced.shape[0]} (after SMOTE)
Test Samples: {X_test.shape[0]}

{'='*50}
MODEL PERFORMANCE
أداء النماذج
{'='*50}

SVM:
  Accuracy: {svm_accuracy*100:.2f}%
  CV Score: {svm_cv_score*100:.2f}%

Random Forest:
  Accuracy: {rf_accuracy*100:.2f}%
  CV Score: {rf_cv_score*100:.2f}%

Ensemble (Weighted Voting):
  Accuracy: {ensemble_accuracy*100:.2f}%
  Weights: SVM={svm_weight:.2f}, RF={rf_weight:.2f}

{'='*50}
BEST MODEL: {max(results, key=lambda x: x['Accuracy'])['Model']}
أفضل نموذج
Accuracy: {max(results, key=lambda x: x['Accuracy'])['Accuracy']*100:.2f}%
{'='*50}
"""

ax6.text(0.1, 0.5, summary_text, fontsize=10, family='monospace',
         verticalalignment='center', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))

plt.tight_layout()
plt.savefig('classification_original_data_results.png', dpi=300, bbox_inches='tight')
print("✓ Visualization saved to: classification_original_data_results.png")
print()

# ============================================================================
# Save Results
# ============================================================================

print("💾 Saving results...")

# Save results to text file
with open('classification_original_data_results.txt', 'w', encoding='utf-8') as f:
    f.write("=" * 80 + "\n")
    f.write("Classification Results on Original Data (25 Behavioral Features)\n")
    f.write("نتائج التصنيف على البيانات الأصلية (25 سمة سلوكية)\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    
    f.write("Dataset Information:\n")
    f.write(f"  Total samples: {len(df)}\n")
    f.write(f"  Features: {len(behavioral_cols)} behavioral features\n")
    f.write(f"  Train samples: {X_train.shape[0]} → {X_train_balanced.shape[0]} (after SMOTE)\n")
    f.write(f"  Test samples: {X_test.shape[0]}\n\n")
    
    f.write("Optimizations Applied:\n")
    f.write("  1. SMOTE for class imbalance handling\n")
    f.write("  2. Grid Search with 10-fold cross-validation\n")
    f.write("  3. Weighted Voting Ensemble\n\n")
    
    f.write("=" * 80 + "\n")
    f.write("MODEL RESULTS\n")
    f.write("=" * 80 + "\n\n")
    
    for result in results:
        f.write(f"{result['Model']}:\n")
        f.write(f"  Accuracy:  {result['Accuracy']:.4f} ({result['Accuracy']*100:.2f}%)\n")
        f.write(f"  Precision: {result['Precision']:.4f} ({result['Precision']*100:.2f}%)\n")
        f.write(f"  Recall:    {result['Recall']:.4f} ({result['Recall']*100:.2f}%)\n")
        f.write(f"  F1-Score:  {result['F1-Score']:.4f} ({result['F1-Score']*100:.2f}%)\n\n")
    
    f.write("=" * 80 + "\n")
    f.write(f"BEST MODEL: {max(results, key=lambda x: x['Accuracy'])['Model']}\n")
    f.write(f"Best Accuracy: {max(results, key=lambda x: x['Accuracy'])['Accuracy']*100:.2f}%\n")
    f.write("=" * 80 + "\n")

print("✓ Results saved to: classification_original_data_results.txt")
print()

# Save results to Excel
results_df = pd.DataFrame(results)
results_df.to_excel('classification_original_data_results.xlsx', index=False)
print("✓ Results saved to: classification_original_data_results.xlsx")
print()

# ============================================================================
# Final Summary
# ============================================================================

print("=" * 80)
print("✅ Classification Completed Successfully!")
print("✅ اكتمل التصنيف بنجاح!")
print("=" * 80)
print()

print("📊 Final Results:")
print()
print(f"{'Model':<20} {'Accuracy':<12} {'Precision':<12} {'Recall':<12} {'F1-Score':<12}")
print("-" * 68)
for result in results:
    print(f"{result['Model']:<20} {result['Accuracy']:.4f}      {result['Precision']:.4f}      "
          f"{result['Recall']:.4f}      {result['F1']:.4f}")
print()

best_model = max(results, key=lambda x: x['Accuracy'])
print(f"🏆 Best Model: {best_model['Model']}")
print(f"🏆 Best Accuracy: {best_model['Accuracy']:.4f} ({best_model['Accuracy']*100:.2f}%)")
print()

print(f"End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)
