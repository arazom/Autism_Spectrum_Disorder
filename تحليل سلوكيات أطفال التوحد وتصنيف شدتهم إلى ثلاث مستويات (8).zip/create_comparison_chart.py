import matplotlib.pyplot as plt
import numpy as np

# Data from the experiments
experiments = ['Experiment 1\n(Engineered Features)', 'Experiment 2\n(Original Features)']
models = ['Random Forest\n(9 features)', 'SVM\n(22 features)']
accuracies = [76.5, 70.6]
colors = ['#2E86AB', '#A23B72']

# Create figure
fig, ax = plt.subplots(figsize=(10, 6))

# Create bar chart
x = np.arange(len(experiments))
width = 0.35
bars = ax.bar(x, accuracies, width, color=colors, edgecolor='black', linewidth=1.5)

# Add value labels on bars
for i, (bar, acc) in enumerate(zip(bars, accuracies)):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.5,
            f'{acc}%',
            ha='center', va='bottom', fontsize=14, fontweight='bold')
    
    # Add model name below the bar
    ax.text(bar.get_x() + bar.get_width()/2., -3,
            models[i],
            ha='center', va='top', fontsize=11, style='italic')

# Customize the plot
ax.set_ylabel('Test Accuracy (%)', fontsize=13, fontweight='bold')
ax.set_title('Comparison of Best Model Performance:\nEngineered vs. Original Features', 
             fontsize=15, fontweight='bold', pad=20)
ax.set_xticks(x)
ax.set_xticklabels(experiments, fontsize=12)
ax.set_ylim(0, 85)
ax.grid(axis='y', alpha=0.3, linestyle='--')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Add annotation showing the improvement
improvement = accuracies[0] - accuracies[1]
ax.annotate('', xy=(0, accuracies[0]), xytext=(1, accuracies[1]),
            arrowprops=dict(arrowstyle='<->', color='red', lw=2))
ax.text(0.5, (accuracies[0] + accuracies[1])/2 + 1.5,
        f'+{improvement}%\nimprovement',
        ha='center', va='bottom', fontsize=11, color='red', fontweight='bold',
        bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.3))

plt.tight_layout()
plt.savefig('/home/ubuntu/experiment_comparison_chart.png', dpi=300, bbox_inches='tight')
print("Chart saved successfully!")
