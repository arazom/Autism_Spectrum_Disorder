import pandas as pd
import numpy as np
from scipy import stats

print("=" * 80)
print("استخراج 22 ميزة جديدة من البيانات الأصلية")
print("Extracting 22 New Features from Original Dataset")
print("=" * 80)
print()

# Load the original dataset
df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

print(f"عدد الأطفال / Number of children: {len(df)}")
print(f"عدد الأعمدة الأصلية / Original columns: {len(df.columns)}")
print()
print("أسماء الأعمدة / Column names:")
for i, col in enumerate(df.columns, 1):
    print(f"  {i}. {col}")
print()

# Identify behavioral columns (25 behavioral attributes)
behavioral_cols = [col for col in df.columns if 'Child' in col or 'child' in col]
print(f"عدد السمات السلوكية / Number of behavioral attributes: {len(behavioral_cols)}")
print()

# Define clinical domains for ratio-based features
domains = {
    'Social_Interaction': [
        '1childName_response',
        '2ChildEye_contact',
        '9ChildSymbolic_play',
        '10ChildShared_attention',
        '15Child_empathy',
        '21ChildChecks_reactions'
    ],
    'Communication': [
        '4ChildSpeech_clarity',
        '5ChildRequest_pointing ',
        '6ChildJoint_attention',
        '12ChildHand_prompting',
        '18ChildEchoin_voice',
        '19ChildGesture_use'
    ],
    'Repetitive_Behaviors': [
        '3ChildObject_lining',
        '7ChildRestriced_interests\n',
        '13Child_walkONtiptoe',
        '16Child_Repetitive_behaviors',
        '20ChildFinger_move',
        '22ChildFocused_attention',
        '23ChildRepetitive_manipulation',
        '25ChildBlank_staring'
    ],
    'Sensory_Sensitivity': [
        '11ChildSensory_seeking',
        '24ChildNoise_sensitivity'
    ],
    'Language_Development': [
        '8ChildVocabulary_size',
        '17ChildFirst_words\n',
        '14ChildAdaptability_Flexibility'
    ]
}

print("=" * 80)
print("المرحلة 1: استخراج الميزات الإحصائية الإجمالية (13 ميزة)")
print("Phase 1: Extracting Aggregate Statistical Features (13 features)")
print("=" * 80)
print()

# 1. Aggregate Statistical Features (13 features)
print("1. Behavioral_Sum - مجموع جميع السمات السلوكية")
df['Behavioral_Sum'] = df[behavioral_cols].sum(axis=1)

print("2. Behavioral_Mean - متوسط جميع السمات السلوكية")
df['Behavioral_Mean'] = df[behavioral_cols].mean(axis=1)

print("3. Behavioral_Std - الانحراف المعياري")
df['Behavioral_Std'] = df[behavioral_cols].std(axis=1)

print("4. Behavioral_Variance - التباين")
df['Behavioral_Variance'] = df[behavioral_cols].var(axis=1)

print("5. Behavioral_Min - أقل قيمة")
df['Behavioral_Min'] = df[behavioral_cols].min(axis=1)

print("6. Behavioral_Max - أعلى قيمة")
df['Behavioral_Max'] = df[behavioral_cols].max(axis=1)

print("7. Behavioral_Range - المدى (Max - Min)")
df['Behavioral_Range'] = df['Behavioral_Max'] - df['Behavioral_Min']

print("8. Behavioral_Median - الوسيط")
df['Behavioral_Median'] = df[behavioral_cols].median(axis=1)

print("9. Behavioral_Q1 - الربيع الأول (25th percentile)")
df['Behavioral_Q1'] = df[behavioral_cols].quantile(0.25, axis=1)

print("10. Behavioral_Q3 - الربيع الثالث (75th percentile)")
df['Behavioral_Q3'] = df[behavioral_cols].quantile(0.75, axis=1)

print("11. Behavioral_IQR - المدى الربيعي (Q3 - Q1)")
df['Behavioral_IQR'] = df['Behavioral_Q3'] - df['Behavioral_Q1']

print("12. Behavioral_Skewness - الالتواء")
df['Behavioral_Skewness'] = df[behavioral_cols].apply(lambda x: stats.skew(x), axis=1)

print("13. Behavioral_Kurtosis - التفرطح")
df['Behavioral_Kurtosis'] = df[behavioral_cols].apply(lambda x: stats.kurtosis(x), axis=1)

print()
print("=" * 80)
print("المرحلة 2: استخراج الميزات النسبية (5 ميزات)")
print("Phase 2: Extracting Ratio-Based Features (5 features)")
print("=" * 80)
print()

# Calculate domain means for ratio features
for domain_name, attributes in domains.items():
    df[f'{domain_name}_Mean'] = df[attributes].mean(axis=1)

print("14. Social_Communication_Ratio - نسبة التفاعل الاجتماعي إلى التواصل")
df['Social_Communication_Ratio'] = df['Social_Interaction_Mean'] / (df['Communication_Mean'] + 0.001)

print("15. Repetitive_Sensory_Ratio - نسبة السلوكيات التكرارية إلى الحساسية الحسية")
df['Repetitive_Sensory_Ratio'] = df['Repetitive_Behaviors_Mean'] / (df['Sensory_Sensitivity_Mean'] + 0.001)

print("16. Language_Social_Ratio - نسبة تطور اللغة إلى التفاعل الاجتماعي")
df['Language_Social_Ratio'] = df['Language_Development_Mean'] / (df['Social_Interaction_Mean'] + 0.001)

print("17. Social_Repetitive_Ratio - نسبة التفاعل الاجتماعي إلى السلوكيات التكرارية")
df['Social_Repetitive_Ratio'] = df['Social_Interaction_Mean'] / (df['Repetitive_Behaviors_Mean'] + 0.001)

print("18. Communication_Language_Ratio - نسبة التواصل إلى تطور اللغة")
df['Communication_Language_Ratio'] = df['Communication_Mean'] / (df['Language_Development_Mean'] + 0.001)

print()
print("=" * 80)
print("المرحلة 3: استخراج ميزات التفاعل (4 ميزات)")
print("Phase 3: Extracting Interaction Features (4 features)")
print("=" * 80)
print()

print("19. Age_x_BehavioralSum - العمر × المجموع السلوكي")
df['Age_x_BehavioralSum'] = df['Age  '] * df['Behavioral_Sum']

print("20. Gender_x_SocialMean - الجنس × متوسط التفاعل الاجتماعي")
df['Gender_x_SocialMean'] = df['Gender '] * df['Social_Interaction_Mean']

print("21. Age_x_CommunicationMean - العمر × متوسط التواصل")
df['Age_x_CommunicationMean'] = df['Age  '] * df['Communication_Mean']

print("22. FamilyHistory_x_BehavioralMean - التاريخ العائلي × المتوسط السلوكي")
df['FamilyHistory_x_BehavioralMean'] = df['Fam_Hist'] * df['Behavioral_Mean']

print()
print("=" * 80)
print("ملخص الميزات الجديدة / Summary of New Features")
print("=" * 80)
print()

new_features = [
    'Behavioral_Sum', 'Behavioral_Mean', 'Behavioral_Std', 'Behavioral_Variance',
    'Behavioral_Min', 'Behavioral_Max', 'Behavioral_Range', 'Behavioral_Median',
    'Behavioral_Q1', 'Behavioral_Q3', 'Behavioral_IQR', 'Behavioral_Skewness',
    'Behavioral_Kurtosis', 'Social_Communication_Ratio', 'Repetitive_Sensory_Ratio',
    'Language_Social_Ratio', 'Social_Repetitive_Ratio', 'Communication_Language_Ratio',
    'Age_x_BehavioralSum', 'Gender_x_SocialMean', 'Age_x_CommunicationMean',
    'FamilyHistory_x_BehavioralMean'
]

print(f"عدد الميزات الجديدة / Number of new features: {len(new_features)}")
print()

print("قائمة الميزات الجديدة / List of new features:")
for i, feature in enumerate(new_features, 1):
    print(f"  {i}. {feature}")

print()
print("=" * 80)
print("عينة من البيانات (أول 5 أطفال)")
print("Sample Data (First 5 Children)")
print("=" * 80)
print()

# Display sample of new features
sample_cols = ['Class', 'Behavioral_Sum', 'Behavioral_Mean', 'Behavioral_Std', 
               'Social_Communication_Ratio', 'Age_x_BehavioralSum']
sample_df = df[sample_cols].head(5)
print(sample_df.to_string(index=True))

print()
print("=" * 80)
print("الإحصائيات الوصفية للميزات الجديدة")
print("Descriptive Statistics for New Features")
print("=" * 80)
print()

stats_df = df[new_features].describe()
print(stats_df.to_string())

print()
print("=" * 80)
print("حفظ البيانات المحسنة في ملف Excel")
print("Saving Enhanced Dataset to Excel")
print("=" * 80)
print()

# Create enhanced dataset with all features
# Original columns + 5 domain means + 22 new features
output_file = '/home/ubuntu/Enhanced_Dataset_56_Features.xlsx'
df.to_excel(output_file, index=False)

print(f"✓ تم الحفظ بنجاح / Saved successfully!")
print(f"✓ اسم الملف / File name: Enhanced_Dataset_56_Features.xlsx")
print(f"✓ عدد الصفوف / Number of rows: {len(df)}")
print(f"✓ عدد الأعمدة الكلي / Total columns: {len(df.columns)}")
print()

# Calculate feature breakdown
original_cols = len(df.columns) - len(new_features) - 5  # minus new features and domain means
print("تفصيل الأعمدة / Column Breakdown:")
print(f"  - الأعمدة الأصلية / Original columns: {original_cols}")
print(f"  - متوسطات المجالات / Domain means: 5")
print(f"  - الميزات الجديدة / New features: {len(new_features)}")
print(f"  - المجموع / Total: {len(df.columns)}")

print()
print("=" * 80)
print("تفاصيل الميزات الجديدة / Details of New Features")
print("=" * 80)
print()

print("الفئة 1: الميزات الإحصائية الإجمالية (13 ميزة)")
print("Category 1: Aggregate Statistical Features (13 features)")
print("  1. Behavioral_Sum: مجموع جميع السمات السلوكية")
print("  2. Behavioral_Mean: متوسط جميع السمات السلوكية")
print("  3. Behavioral_Std: الانحراف المعياري")
print("  4. Behavioral_Variance: التباين")
print("  5. Behavioral_Min: أقل قيمة")
print("  6. Behavioral_Max: أعلى قيمة")
print("  7. Behavioral_Range: المدى")
print("  8. Behavioral_Median: الوسيط")
print("  9. Behavioral_Q1: الربيع الأول")
print("  10. Behavioral_Q3: الربيع الثالث")
print("  11. Behavioral_IQR: المدى الربيعي")
print("  12. Behavioral_Skewness: الالتواء")
print("  13. Behavioral_Kurtosis: التفرطح")
print()

print("الفئة 2: الميزات النسبية (5 ميزات)")
print("Category 2: Ratio-Based Features (5 features)")
print("  14. Social_Communication_Ratio: نسبة التفاعل الاجتماعي إلى التواصل")
print("  15. Repetitive_Sensory_Ratio: نسبة السلوكيات التكرارية إلى الحساسية الحسية")
print("  16. Language_Social_Ratio: نسبة تطور اللغة إلى التفاعل الاجتماعي")
print("  17. Social_Repetitive_Ratio: نسبة التفاعل الاجتماعي إلى السلوكيات التكرارية")
print("  18. Communication_Language_Ratio: نسبة التواصل إلى تطور اللغة")
print()

print("الفئة 3: ميزات التفاعل (4 ميزات)")
print("Category 3: Interaction Features (4 features)")
print("  19. Age_x_BehavioralSum: العمر × المجموع السلوكي")
print("  20. Gender_x_SocialMean: الجنس × متوسط التفاعل الاجتماعي")
print("  21. Age_x_CommunicationMean: العمر × متوسط التواصل")
print("  22. FamilyHistory_x_BehavioralMean: التاريخ العائلي × المتوسط السلوكي")
print()

print("=" * 80)
print("✓ العملية اكتملت بنجاح!")
print("✓ Process completed successfully!")
print("=" * 80)
