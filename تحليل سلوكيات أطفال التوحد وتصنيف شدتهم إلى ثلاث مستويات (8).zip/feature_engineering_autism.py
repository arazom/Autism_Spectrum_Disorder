#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Feature Engineering for Autism Severity Classification
========================================================

This script extracts 22 new features from the original autism dataset
using advanced feature engineering techniques.

Author: Arazo M. Mustafa
Date: February 2026
Version: 1.0

Usage:
    python feature_engineering_autism.py input_file.xlsx output_file.xlsx

Requirements:
    - pandas
    - numpy
    - scipy
    - openpyxl
"""

import pandas as pd
import numpy as np
from scipy import stats
import sys
import os
from datetime import datetime


def print_header():
    """Print script header"""
    print("=" * 80)
    print("Feature Engineering for Autism Severity Classification")
    print("استخراج الميزات لتصنيف شدة اضطراب طيف التوحد")
    print("=" * 80)
    print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    print()


def validate_input_file(file_path):
    """
    Validate that the input file exists and is readable
    
    Args:
        file_path (str): Path to input file
        
    Returns:
        bool: True if valid, False otherwise
    """
    if not os.path.exists(file_path):
        print(f"❌ Error: File not found: {file_path}")
        return False
    
    if not file_path.endswith(('.xlsx', '.xls', '.csv')):
        print(f"❌ Error: Unsupported file format. Please use .xlsx, .xls, or .csv")
        return False
    
    return True


def load_dataset(file_path):
    """
    Load the dataset from Excel or CSV file
    
    Args:
        file_path (str): Path to input file
        
    Returns:
        pd.DataFrame: Loaded dataset
    """
    print(f"📂 Loading dataset from: {file_path}")
    
    try:
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        else:
            df = pd.read_excel(file_path)
        
        print(f"✓ Dataset loaded successfully!")
        print(f"  - Number of rows: {len(df)}")
        print(f"  - Number of columns: {len(df.columns)}")
        print()
        
        return df
    
    except Exception as e:
        print(f"❌ Error loading file: {str(e)}")
        sys.exit(1)


def identify_behavioral_columns(df):
    """
    Identify behavioral attribute columns in the dataset
    
    Args:
        df (pd.DataFrame): Input dataset
        
    Returns:
        list: List of behavioral column names
    """
    print("🔍 Identifying behavioral attribute columns...")
    
    # Identify columns containing 'Child' or 'child'
    behavioral_cols = [col for col in df.columns if 'Child' in col or 'child' in col]
    
    print(f"✓ Found {len(behavioral_cols)} behavioral attributes")
    print()
    
    if len(behavioral_cols) == 0:
        print("❌ Warning: No behavioral columns found!")
        print("   Expected columns containing 'Child' or 'child' in their names")
        print()
    
    return behavioral_cols


def define_clinical_domains():
    """
    Define the 5 clinical domains and their corresponding attributes
    
    Returns:
        dict: Dictionary mapping domain names to attribute lists
    """
    domains = {
        'Social_Interaction': [
            '1childName_response',
            '2ChildEye_contact',
            '9ChildSymbolic_play',
            '10ChildShared_attention',
            '15Child_empathy',
            '21ChildChecks_reactions'
        ],
        'Communication': [
            '4ChildSpeech_clarity',
            '5ChildRequest_pointing ',
            '6ChildJoint_attention',
            '12ChildHand_prompting',
            '18ChildEchoin_voice',
            '19ChildGesture_use'
        ],
        'Repetitive_Behaviors': [
            '3ChildObject_lining',
            '7ChildRestriced_interests\n',
            '13Child_walkONtiptoe',
            '16Child_Repetitive_behaviors',
            '20ChildFinger_move',
            '22ChildFocused_attention',
            '23ChildRepetitive_manipulation',
            '25ChildBlank_staring'
        ],
        'Sensory_Sensitivity': [
            '11ChildSensory_seeking',
            '24ChildNoise_sensitivity'
        ],
        'Language_Development': [
            '8ChildVocabulary_size',
            '17ChildFirst_words\n',
            '14ChildAdaptability_Flexibility'
        ]
    }
    
    return domains


def extract_aggregate_features(df, behavioral_cols):
    """
    Extract 13 aggregate statistical features
    
    Args:
        df (pd.DataFrame): Input dataset
        behavioral_cols (list): List of behavioral column names
        
    Returns:
        pd.DataFrame: Dataset with new aggregate features
    """
    print("=" * 80)
    print("Phase 1: Extracting Aggregate Statistical Features (13 features)")
    print("المرحلة 1: استخراج الميزات الإحصائية الإجمالية (13 ميزة)")
    print("=" * 80)
    print()
    
    features_added = []
    
    # 1. Sum
    print("1/13 Behavioral_Sum - مجموع جميع السمات السلوكية")
    df['Behavioral_Sum'] = df[behavioral_cols].sum(axis=1)
    features_added.append('Behavioral_Sum')
    
    # 2. Mean
    print("2/13 Behavioral_Mean - متوسط جميع السمات السلوكية")
    df['Behavioral_Mean'] = df[behavioral_cols].mean(axis=1)
    features_added.append('Behavioral_Mean')
    
    # 3. Standard Deviation
    print("3/13 Behavioral_Std - الانحراف المعياري")
    df['Behavioral_Std'] = df[behavioral_cols].std(axis=1)
    features_added.append('Behavioral_Std')
    
    # 4. Variance
    print("4/13 Behavioral_Variance - التباين")
    df['Behavioral_Variance'] = df[behavioral_cols].var(axis=1)
    features_added.append('Behavioral_Variance')
    
    # 5. Min
    print("5/13 Behavioral_Min - أقل قيمة")
    df['Behavioral_Min'] = df[behavioral_cols].min(axis=1)
    features_added.append('Behavioral_Min')
    
    # 6. Max
    print("6/13 Behavioral_Max - أعلى قيمة")
    df['Behavioral_Max'] = df[behavioral_cols].max(axis=1)
    features_added.append('Behavioral_Max')
    
    # 7. Range
    print("7/13 Behavioral_Range - المدى (Max - Min)")
    df['Behavioral_Range'] = df['Behavioral_Max'] - df['Behavioral_Min']
    features_added.append('Behavioral_Range')
    
    # 8. Median
    print("8/13 Behavioral_Median - الوسيط")
    df['Behavioral_Median'] = df[behavioral_cols].median(axis=1)
    features_added.append('Behavioral_Median')
    
    # 9. Q1 (25th percentile)
    print("9/13 Behavioral_Q1 - الربيع الأول (25th percentile)")
    df['Behavioral_Q1'] = df[behavioral_cols].quantile(0.25, axis=1)
    features_added.append('Behavioral_Q1')
    
    # 10. Q3 (75th percentile)
    print("10/13 Behavioral_Q3 - الربيع الثالث (75th percentile)")
    df['Behavioral_Q3'] = df[behavioral_cols].quantile(0.75, axis=1)
    features_added.append('Behavioral_Q3')
    
    # 11. IQR (Interquartile Range)
    print("11/13 Behavioral_IQR - المدى الربيعي (Q3 - Q1)")
    df['Behavioral_IQR'] = df['Behavioral_Q3'] - df['Behavioral_Q1']
    features_added.append('Behavioral_IQR')
    
    # 12. Skewness
    print("12/13 Behavioral_Skewness - الالتواء")
    df['Behavioral_Skewness'] = df[behavioral_cols].apply(lambda x: stats.skew(x), axis=1)
    features_added.append('Behavioral_Skewness')
    
    # 13. Kurtosis
    print("13/13 Behavioral_Kurtosis - التفرطح")
    df['Behavioral_Kurtosis'] = df[behavioral_cols].apply(lambda x: stats.kurtosis(x), axis=1)
    features_added.append('Behavioral_Kurtosis')
    
    print()
    print(f"✓ Successfully added {len(features_added)} aggregate features")
    print()
    
    return df, features_added


def extract_ratio_features(df, domains):
    """
    Extract 5 ratio-based features
    
    Args:
        df (pd.DataFrame): Input dataset
        domains (dict): Dictionary of clinical domains
        
    Returns:
        pd.DataFrame: Dataset with new ratio features
    """
    print("=" * 80)
    print("Phase 2: Extracting Ratio-Based Features (5 features)")
    print("المرحلة 2: استخراج الميزات النسبية (5 ميزات)")
    print("=" * 80)
    print()
    
    features_added = []
    
    # Calculate domain means first
    print("Calculating domain means...")
    for domain_name, attributes in domains.items():
        # Filter attributes that exist in the dataframe
        existing_attrs = [attr for attr in attributes if attr in df.columns]
        if existing_attrs:
            df[f'{domain_name}_Mean'] = df[existing_attrs].mean(axis=1)
    print("✓ Domain means calculated")
    print()
    
    # 14. Social to Communication Ratio
    print("1/5 Social_Communication_Ratio - نسبة التفاعل الاجتماعي إلى التواصل")
    df['Social_Communication_Ratio'] = df['Social_Interaction_Mean'] / (df['Communication_Mean'] + 0.001)
    features_added.append('Social_Communication_Ratio')
    
    # 15. Repetitive to Sensory Ratio
    print("2/5 Repetitive_Sensory_Ratio - نسبة السلوكيات التكرارية إلى الحساسية الحسية")
    df['Repetitive_Sensory_Ratio'] = df['Repetitive_Behaviors_Mean'] / (df['Sensory_Sensitivity_Mean'] + 0.001)
    features_added.append('Repetitive_Sensory_Ratio')
    
    # 16. Language to Social Ratio
    print("3/5 Language_Social_Ratio - نسبة تطور اللغة إلى التفاعل الاجتماعي")
    df['Language_Social_Ratio'] = df['Language_Development_Mean'] / (df['Social_Interaction_Mean'] + 0.001)
    features_added.append('Language_Social_Ratio')
    
    # 17. Social to Repetitive Ratio
    print("4/5 Social_Repetitive_Ratio - نسبة التفاعل الاجتماعي إلى السلوكيات التكرارية")
    df['Social_Repetitive_Ratio'] = df['Social_Interaction_Mean'] / (df['Repetitive_Behaviors_Mean'] + 0.001)
    features_added.append('Social_Repetitive_Ratio')
    
    # 18. Communication to Language Ratio
    print("5/5 Communication_Language_Ratio - نسبة التواصل إلى تطور اللغة")
    df['Communication_Language_Ratio'] = df['Communication_Mean'] / (df['Language_Development_Mean'] + 0.001)
    features_added.append('Communication_Language_Ratio')
    
    print()
    print(f"✓ Successfully added {len(features_added)} ratio features")
    print()
    
    return df, features_added


def extract_interaction_features(df):
    """
    Extract 4 interaction features
    
    Args:
        df (pd.DataFrame): Input dataset
        
    Returns:
        pd.DataFrame: Dataset with new interaction features
    """
    print("=" * 80)
    print("Phase 3: Extracting Interaction Features (4 features)")
    print("المرحلة 3: استخراج ميزات التفاعل (4 ميزات)")
    print("=" * 80)
    print()
    
    features_added = []
    
    # Find age column (could be 'Age', 'Age  ', 'age', etc.)
    age_col = None
    for col in df.columns:
        if 'age' in col.lower():
            age_col = col
            break
    
    # Find gender column
    gender_col = None
    for col in df.columns:
        if 'gender' in col.lower():
            gender_col = col
            break
    
    # Find family history column
    family_col = None
    for col in df.columns:
        if 'fam' in col.lower() or 'history' in col.lower():
            family_col = col
            break
    
    # 19. Age × Behavioral Sum
    if age_col:
        print("1/4 Age_x_BehavioralSum - العمر × المجموع السلوكي")
        df['Age_x_BehavioralSum'] = df[age_col] * df['Behavioral_Sum']
        features_added.append('Age_x_BehavioralSum')
    else:
        print("⚠ Warning: Age column not found, skipping Age_x_BehavioralSum")
    
    # 20. Gender × Social Mean
    if gender_col:
        print("2/4 Gender_x_SocialMean - الجنس × متوسط التفاعل الاجتماعي")
        df['Gender_x_SocialMean'] = df[gender_col] * df['Social_Interaction_Mean']
        features_added.append('Gender_x_SocialMean')
    else:
        print("⚠ Warning: Gender column not found, skipping Gender_x_SocialMean")
    
    # 21. Age × Communication Mean
    if age_col:
        print("3/4 Age_x_CommunicationMean - العمر × متوسط التواصل")
        df['Age_x_CommunicationMean'] = df[age_col] * df['Communication_Mean']
        features_added.append('Age_x_CommunicationMean')
    else:
        print("⚠ Warning: Age column not found, skipping Age_x_CommunicationMean")
    
    # 22. Family History × Behavioral Mean
    if family_col:
        print("4/4 FamilyHistory_x_BehavioralMean - التاريخ العائلي × المتوسط السلوكي")
        df['FamilyHistory_x_BehavioralMean'] = df[family_col] * df['Behavioral_Mean']
        features_added.append('FamilyHistory_x_BehavioralMean')
    else:
        print("⚠ Warning: Family history column not found, skipping FamilyHistory_x_BehavioralMean")
    
    print()
    print(f"✓ Successfully added {len(features_added)} interaction features")
    print()
    
    return df, features_added


def print_summary(df, all_new_features, original_cols):
    """
    Print summary of feature engineering results
    
    Args:
        df (pd.DataFrame): Enhanced dataset
        all_new_features (list): List of all new feature names
        original_cols (int): Number of original columns
    """
    print("=" * 80)
    print("Summary / ملخص")
    print("=" * 80)
    print()
    
    print(f"📊 Dataset Information:")
    print(f"  - Number of rows / عدد الصفوف: {len(df)}")
    print(f"  - Original columns / الأعمدة الأصلية: {original_cols}")
    print(f"  - New features / الميزات الجديدة: {len(all_new_features)}")
    print(f"  - Total columns / إجمالي الأعمدة: {len(df.columns)}")
    print()
    
    print(f"✓ New Features Added ({len(all_new_features)}):")
    for i, feature in enumerate(all_new_features, 1):
        print(f"  {i:2d}. {feature}")
    print()
    
    # Display sample statistics
    print("📈 Sample Statistics (first 5 rows):")
    sample_cols = ['Behavioral_Sum', 'Behavioral_Mean', 'Behavioral_Std']
    sample_cols = [col for col in sample_cols if col in df.columns]
    if sample_cols:
        print(df[sample_cols].head().to_string())
    print()


def save_dataset(df, output_path):
    """
    Save the enhanced dataset to Excel file
    
    Args:
        df (pd.DataFrame): Enhanced dataset
        output_path (str): Path to output file
    """
    print("=" * 80)
    print("Saving Enhanced Dataset / حفظ البيانات المحسنة")
    print("=" * 80)
    print()
    
    print(f"💾 Saving to: {output_path}")
    
    try:
        df.to_excel(output_path, index=False, engine='openpyxl')
        
        file_size = os.path.getsize(output_path) / 1024  # KB
        
        print(f"✓ Dataset saved successfully!")
        print(f"  - File size: {file_size:.2f} KB")
        print(f"  - Location: {output_path}")
        print()
        
    except Exception as e:
        print(f"❌ Error saving file: {str(e)}")
        sys.exit(1)


def main():
    """Main function"""
    
    print_header()
    
    # Check command line arguments
    if len(sys.argv) < 2:
        print("Usage: python feature_engineering_autism.py <input_file> [output_file]")
        print()
        print("Example:")
        print("  python feature_engineering_autism.py data.xlsx output.xlsx")
        print("  python feature_engineering_autism.py data.xlsx")
        print()
        sys.exit(1)
    
    # Get input and output file paths
    input_file = sys.argv[1]
    
    if len(sys.argv) >= 3:
        output_file = sys.argv[2]
    else:
        # Generate output filename
        base_name = os.path.splitext(input_file)[0]
        output_file = f"{base_name}_enhanced.xlsx"
    
    # Validate input file
    if not validate_input_file(input_file):
        sys.exit(1)
    
    # Load dataset
    df = load_dataset(input_file)
    original_cols = len(df.columns)
    
    # Identify behavioral columns
    behavioral_cols = identify_behavioral_columns(df)
    
    if len(behavioral_cols) == 0:
        print("❌ Error: No behavioral columns found. Cannot proceed.")
        sys.exit(1)
    
    # Define clinical domains
    domains = define_clinical_domains()
    
    # Track all new features
    all_new_features = []
    
    # Extract aggregate features
    df, agg_features = extract_aggregate_features(df, behavioral_cols)
    all_new_features.extend(agg_features)
    
    # Extract ratio features
    df, ratio_features = extract_ratio_features(df, domains)
    all_new_features.extend(ratio_features)
    
    # Extract interaction features
    df, interaction_features = extract_interaction_features(df)
    all_new_features.extend(interaction_features)
    
    # Print summary
    print_summary(df, all_new_features, original_cols)
    
    # Save enhanced dataset
    save_dataset(df, output_file)
    
    # Print completion message
    print("=" * 80)
    print("✅ Feature Engineering Completed Successfully!")
    print("✅ اكتملت عملية استخراج الميزات بنجاح!")
    print("=" * 80)
    print(f"End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)


if __name__ == "__main__":
    main()
