#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Feature Selection Analysis for Autism Classification
=====================================================

This script applies three feature selection techniques:
1. Random Forest Feature Importance
2. LASSO Regularization (L1)
3. Recursive Feature Elimination (RFE)

Author: Arazo M. Mustafa
Date: February 2026
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Machine Learning Libraries
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE, SelectFromModel
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from imblearn.over_sampling import SMOTE

print("=" * 80)
print("Feature Selection Analysis for Autism Classification")
print("تحليل اختيار الميزات لتصنيف اضطراب طيف التوحد")
print("=" * 80)
print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)
print()

# ============================================================================
# Phase 1: Load and Prepare Data
# المرحلة 1: تحميل وإعداد البيانات
# ============================================================================

print("=" * 80)
print("Phase 1: Loading and Preparing Data")
print("المرحلة 1: تحميل وإعداد البيانات")
print("=" * 80)
print()

# Load dataset
print("📂 Loading enhanced dataset...")
df = pd.read_excel('test_output.xlsx')

print(f"✓ Dataset loaded: {len(df)} rows × {len(df.columns)} columns")
print()

# Identify features and target
class_col = None
for col in df.columns:
    if 'class' in col.lower():
        class_col = col
        break

# Exclude non-feature columns
exclude_cols = ['ID', 'Name', 'Gender', 'Gender ', 'Age', 'Age  ', 
                'Ethnicity', 'Jaundice', 'Fam_Hist', class_col]
exclude_cols = [col for col in exclude_cols if col in df.columns]

# Get feature columns
feature_cols = [col for col in df.columns if col not in exclude_cols]

print(f"📊 Features: {len(feature_cols)}")
print(f"📊 Target: {class_col}")
print()

# Prepare X and y
X = df[feature_cols].values
y = df[class_col].values
feature_names = np.array(feature_cols)

print(f"✓ X shape: {X.shape}")
print(f"✓ y shape: {y.shape}")
print()

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"✓ Train set: {X_train.shape[0]} samples")
print(f"✓ Test set: {X_test.shape[0]} samples")
print()

# Apply SMOTE
print("🔄 Applying SMOTE...")
smote = SMOTE(random_state=42, k_neighbors=5)
X_train_balanced, y_train_balanced = smote.fit_resample(X_train, y_train)

print(f"✓ Balanced training set: {X_train_balanced.shape[0]} samples")
print()

# Feature Scaling
print("📏 Applying feature scaling...")
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_balanced)
X_test_scaled = scaler.transform(X_test)

print("✓ Feature scaling completed")
print()

# ============================================================================
# Phase 2: Random Forest Feature Importance
# المرحلة 2: أهمية الميزات باستخدام Random Forest
# ============================================================================

print("=" * 80)
print("Phase 2: Random Forest Feature Importance")
print("المرحلة 2: أهمية الميزات باستخدام Random Forest")
print("=" * 80)
print()

print("⚙️ Training Random Forest model...")
rf_model = RandomForestClassifier(
    n_estimators=300,
    max_depth=None,
    min_samples_split=10,
    min_samples_leaf=1,
    max_features='log2',
    random_state=42,
    n_jobs=-1
)

rf_model.fit(X_train_scaled, y_train_balanced)

print("✓ Random Forest trained successfully")
print()

# Get feature importances
rf_importances = rf_model.feature_importances_
rf_indices = np.argsort(rf_importances)[::-1]

print("📊 Top 20 Features by Random Forest Importance:")
print()
print(f"{'Rank':<6} {'Feature Name':<40} {'Importance':<12}")
print("-" * 58)

for i in range(min(20, len(feature_names))):
    idx = rf_indices[i]
    print(f"{i+1:<6} {feature_names[idx]:<40} {rf_importances[idx]:.6f}")

print()

# Create DataFrame for RF results
rf_results = pd.DataFrame({
    'Feature': feature_names,
    'RF_Importance': rf_importances,
    'RF_Rank': [np.where(rf_indices == i)[0][0] + 1 for i in range(len(feature_names))]
})

# ============================================================================
# Phase 3: LASSO Regularization (L1)
# المرحلة 3: تنظيم LASSO (L1)
# ============================================================================

print("=" * 80)
print("Phase 3: LASSO Regularization (L1)")
print("المرحلة 3: تنظيم LASSO (L1)")
print("=" * 80)
print()

print("⚙️ Training LASSO (Logistic Regression with L1) model...")

# Try different C values to find optimal regularization
C_values = [0.001, 0.01, 0.1, 1, 10]
best_C = None
best_score = 0

for C in C_values:
    lasso_model = LogisticRegression(
        penalty='l1',
        C=C,
        solver='saga',
        max_iter=5000,
        random_state=42
    )
    
    scores = cross_val_score(lasso_model, X_train_scaled, y_train_balanced, cv=5)
    mean_score = scores.mean()
    
    print(f"  C={C:6.3f} → CV Accuracy: {mean_score:.4f}")
    
    if mean_score > best_score:
        best_score = mean_score
        best_C = C

print()
print(f"✓ Best C: {best_C} (CV Accuracy: {best_score:.4f})")
print()

# Train final LASSO model with best C
print(f"⚙️ Training final LASSO model with C={best_C}...")
lasso_model = LogisticRegression(
    penalty='l1',
    C=best_C,
    solver='saga',
    max_iter=5000,
    random_state=42
)

lasso_model.fit(X_train_scaled, y_train_balanced)

print("✓ LASSO model trained successfully")
print()

# Get feature coefficients (use mean absolute value across classes)
lasso_coefs = np.abs(lasso_model.coef_).mean(axis=0)
lasso_indices = np.argsort(lasso_coefs)[::-1]

# Count non-zero features
non_zero_features = np.sum(lasso_coefs > 1e-5)
print(f"📊 Non-zero features: {non_zero_features} out of {len(feature_names)}")
print()

print("📊 Top 20 Features by LASSO Coefficient:")
print()
print(f"{'Rank':<6} {'Feature Name':<40} {'Coefficient':<12}")
print("-" * 58)

for i in range(min(20, len(feature_names))):
    idx = lasso_indices[i]
    print(f"{i+1:<6} {feature_names[idx]:<40} {lasso_coefs[idx]:.6f}")

print()

# Create DataFrame for LASSO results
lasso_results = pd.DataFrame({
    'Feature': feature_names,
    'LASSO_Coef': lasso_coefs,
    'LASSO_Rank': [np.where(lasso_indices == i)[0][0] + 1 for i in range(len(feature_names))]
})

# ============================================================================
# Phase 4: Recursive Feature Elimination (RFE)
# المرحلة 4: الإزالة التكرارية للميزات (RFE)
# ============================================================================

print("=" * 80)
print("Phase 4: Recursive Feature Elimination (RFE)")
print("المرحلة 4: الإزالة التكرارية للميزات (RFE)")
print("=" * 80)
print()

print("⚙️ Running RFE with SVM estimator...")
print("   This may take a few minutes...")
print()

# Use Linear SVM as estimator for RFE (has coef_ attribute)
from sklearn.svm import LinearSVC
svm_estimator = LinearSVC(C=1, random_state=42, max_iter=5000)

# Try different numbers of features
n_features_to_select_list = [10, 15, 20, 25, 30, 35, 40]
rfe_results_list = []

for n_features in n_features_to_select_list:
    print(f"  Testing with {n_features} features...")
    
    rfe = RFE(estimator=svm_estimator, n_features_to_select=n_features, step=1)
    rfe.fit(X_train_scaled, y_train_balanced)
    
    # Evaluate on test set
    X_train_rfe = rfe.transform(X_train_scaled)
    X_test_rfe = rfe.transform(X_test_scaled)
    
    # Use a fresh estimator for each test
    test_estimator = LinearSVC(C=1, random_state=42, max_iter=5000)
    test_estimator.fit(X_train_rfe, y_train_balanced)
    accuracy = test_estimator.score(X_test_rfe, y_test)
    
    rfe_results_list.append({
        'n_features': n_features,
        'accuracy': accuracy,
        'selected_features': feature_names[rfe.support_],
        'ranking': rfe.ranking_
    })
    
    print(f"    → Test Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

print()

# Find best number of features
best_rfe_result = max(rfe_results_list, key=lambda x: x['accuracy'])
best_n_features = best_rfe_result['n_features']
best_rfe_accuracy = best_rfe_result['accuracy']

print(f"✓ Best number of features: {best_n_features}")
print(f"✓ Best RFE accuracy: {best_rfe_accuracy:.4f} ({best_rfe_accuracy*100:.2f}%)")
print()

# Train final RFE with best number of features
print(f"⚙️ Training final RFE with {best_n_features} features...")
rfe_final = RFE(estimator=svm_estimator, n_features_to_select=best_n_features, step=1)
rfe_final.fit(X_train_scaled, y_train_balanced)

print("✓ RFE completed successfully")
print()

# Get RFE rankings
rfe_ranking = rfe_final.ranking_
rfe_selected = rfe_final.support_

print(f"📊 Top {best_n_features} Features Selected by RFE:")
print()
print(f"{'Rank':<6} {'Feature Name':<40} {'Selected':<10}")
print("-" * 56)

rfe_indices = np.argsort(rfe_ranking)
for i in range(min(20, len(feature_names))):
    idx = rfe_indices[i]
    selected = "✓" if rfe_selected[idx] else "✗"
    print(f"{rfe_ranking[idx]:<6} {feature_names[idx]:<40} {selected:<10}")

print()

# Create DataFrame for RFE results
rfe_results_df = pd.DataFrame({
    'Feature': feature_names,
    'RFE_Ranking': rfe_ranking,
    'RFE_Selected': rfe_selected
})

# ============================================================================
# Phase 5: Combine Results and Select Best Features
# المرحلة 5: دمج النتائج واختيار أفضل الميزات
# ============================================================================

print("=" * 80)
print("Phase 5: Combining Results and Selecting Best Features")
print("المرحلة 5: دمج النتائج واختيار أفضل الميزات")
print("=" * 80)
print()

# Merge all results
combined_results = rf_results.merge(lasso_results, on='Feature').merge(rfe_results_df, on='Feature')

# Calculate composite score
# Normalize ranks to 0-1 scale
combined_results['RF_Score'] = 1 - (combined_results['RF_Rank'] - 1) / (len(feature_names) - 1)
combined_results['LASSO_Score'] = 1 - (combined_results['LASSO_Rank'] - 1) / (len(feature_names) - 1)
combined_results['RFE_Score'] = 1 - (combined_results['RFE_Ranking'] - 1) / (len(feature_names) - 1)

# Composite score (weighted average)
combined_results['Composite_Score'] = (
    0.4 * combined_results['RF_Score'] +
    0.3 * combined_results['LASSO_Score'] +
    0.3 * combined_results['RFE_Score']
)

# Sort by composite score
combined_results = combined_results.sort_values('Composite_Score', ascending=False)

print("📊 Top 30 Features by Composite Score:")
print()
print(f"{'Rank':<6} {'Feature Name':<40} {'Composite':<12} {'RF':<8} {'LASSO':<8} {'RFE':<8}")
print("-" * 82)

for i in range(min(30, len(combined_results))):
    row = combined_results.iloc[i]
    print(f"{i+1:<6} {row['Feature']:<40} {row['Composite_Score']:.4f}      "
          f"{row['RF_Rank']:<8} {row['LASSO_Rank']:<8} {row['RFE_Ranking']:<8}")

print()

# Select top features
top_n_features = 30  # Select top 30 features
selected_features = combined_results.head(top_n_features)['Feature'].values

print(f"✓ Selected {len(selected_features)} features based on composite score")
print()

# Save combined results
combined_results.to_excel('feature_selection_results.xlsx', index=False)
print("✓ Results saved to: feature_selection_results.xlsx")
print()

# ============================================================================
# Phase 6: Train Models with Selected Features
# المرحلة 6: تدريب النماذج على الميزات المختارة
# ============================================================================

print("=" * 80)
print("Phase 6: Training Models with Selected Features")
print("المرحلة 6: تدريب النماذج على الميزات المختارة")
print("=" * 80)
print()

# Get indices of selected features
selected_indices = [np.where(feature_names == feat)[0][0] for feat in selected_features]

# Extract selected features
X_train_selected = X_train_scaled[:, selected_indices]
X_test_selected = X_test_scaled[:, selected_indices]

print(f"📊 Training with {len(selected_features)} selected features")
print(f"   Original: {X_train_scaled.shape[1]} features")
print(f"   Selected: {X_train_selected.shape[1]} features")
print(f"   Reduction: {X_train_scaled.shape[1] - X_train_selected.shape[1]} features ({(1 - X_train_selected.shape[1]/X_train_scaled.shape[1])*100:.1f}%)")
print()

# Train SVM with selected features
print("⚙️ Training SVM with selected features...")
svm_selected = SVC(kernel='sigmoid', C=1, gamma='scale', random_state=42, probability=True)
svm_selected.fit(X_train_selected, y_train_balanced)
svm_selected_pred = svm_selected.predict(X_test_selected)
svm_selected_acc = accuracy_score(y_test, svm_selected_pred)

print(f"✓ SVM Accuracy (selected features): {svm_selected_acc:.4f} ({svm_selected_acc*100:.2f}%)")
print()

# Train Random Forest with selected features
print("⚙️ Training Random Forest with selected features...")
rf_selected = RandomForestClassifier(
    n_estimators=300,
    max_depth=None,
    min_samples_split=10,
    min_samples_leaf=1,
    max_features='log2',
    random_state=42,
    n_jobs=-1
)
rf_selected.fit(X_train_selected, y_train_balanced)
rf_selected_pred = rf_selected.predict(X_test_selected)
rf_selected_acc = accuracy_score(y_test, rf_selected_pred)

print(f"✓ Random Forest Accuracy (selected features): {rf_selected_acc:.4f} ({rf_selected_acc*100:.2f}%)")
print()

# Train Ensemble with selected features
print("⚙️ Training Ensemble with selected features...")
ensemble_selected = VotingClassifier(
    estimators=[
        ('svm', svm_selected),
        ('rf', rf_selected)
    ],
    voting='soft',
    weights=[0.49, 0.51]
)
ensemble_selected.fit(X_train_selected, y_train_balanced)
ensemble_selected_pred = ensemble_selected.predict(X_test_selected)
ensemble_selected_acc = accuracy_score(y_test, ensemble_selected_pred)

print(f"✓ Ensemble Accuracy (selected features): {ensemble_selected_acc:.4f} ({ensemble_selected_acc*100:.2f}%)")
print()

# ============================================================================
# Comparison: All Features vs Selected Features
# ============================================================================

print("=" * 80)
print("Performance Comparison: All Features vs Selected Features")
print("مقارنة الأداء: جميع الميزات مقابل الميزات المختارة")
print("=" * 80)
print()

# Load previous results (all features)
# For comparison, we'll use the accuracies from previous run
all_features_results = {
    'SVM': 0.7059,
    'Random Forest': 0.6912,
    'Ensemble': 0.7206
}

selected_features_results = {
    'SVM': svm_selected_acc,
    'Random Forest': rf_selected_acc,
    'Ensemble': ensemble_selected_acc
}

print(f"{'Model':<20} {'All Features (57)':<20} {'Selected Features (30)':<25} {'Difference':<15}")
print("-" * 80)

for model_name in ['SVM', 'Random Forest', 'Ensemble']:
    all_acc = all_features_results[model_name]
    sel_acc = selected_features_results[model_name]
    diff = sel_acc - all_acc
    diff_str = f"{diff:+.4f} ({diff*100:+.2f}%)"
    
    print(f"{model_name:<20} {all_acc:.4f} ({all_acc*100:.2f}%){' '*5} "
          f"{sel_acc:.4f} ({sel_acc*100:.2f}%){' '*10} {diff_str:<15}")

print()

# Determine if feature selection improved performance
best_all = max(all_features_results.values())
best_selected = max(selected_features_results.values())

if best_selected > best_all:
    improvement = best_selected - best_all
    print(f"✅ Feature selection IMPROVED performance by {improvement:.4f} ({improvement*100:.2f}%)")
elif best_selected < best_all:
    degradation = best_all - best_selected
    print(f"⚠️ Feature selection DECREASED performance by {degradation:.4f} ({degradation*100:.2f}%)")
else:
    print(f"➡️ Feature selection maintained the same performance")

print()
print(f"📊 Feature reduction: {X_train_scaled.shape[1]} → {X_train_selected.shape[1]} features")
print(f"   Reduction rate: {(1 - X_train_selected.shape[1]/X_train_scaled.shape[1])*100:.1f}%")
print()

# ============================================================================
# Visualization
# ============================================================================

print("📊 Creating visualizations...")

fig = plt.figure(figsize=(20, 12))

# Plot 1: Top 20 Features by RF Importance
ax1 = plt.subplot(2, 3, 1)
top_20_rf = combined_results.nsmallest(20, 'RF_Rank')
ax1.barh(range(20), top_20_rf['RF_Importance'].values, color='#2ecc71')
ax1.set_yticks(range(20))
ax1.set_yticklabels(top_20_rf['Feature'].values, fontsize=8)
ax1.set_xlabel('Importance')
ax1.set_title('Top 20 Features - Random Forest Importance')
ax1.invert_yaxis()
ax1.grid(axis='x', alpha=0.3)

# Plot 2: Top 20 Features by LASSO Coefficient
ax2 = plt.subplot(2, 3, 2)
top_20_lasso = combined_results.nsmallest(20, 'LASSO_Rank')
ax2.barh(range(20), top_20_lasso['LASSO_Coef'].values, color='#3498db')
ax2.set_yticks(range(20))
ax2.set_yticklabels(top_20_lasso['Feature'].values, fontsize=8)
ax2.set_xlabel('Coefficient')
ax2.set_title('Top 20 Features - LASSO Coefficient')
ax2.invert_yaxis()
ax2.grid(axis='x', alpha=0.3)

# Plot 3: Top 20 Features by RFE Ranking
ax3 = plt.subplot(2, 3, 3)
top_20_rfe = combined_results.nsmallest(20, 'RFE_Ranking')
ax3.barh(range(20), 1/(top_20_rfe['RFE_Ranking'].values + 1), color='#e74c3c')
ax3.set_yticks(range(20))
ax3.set_yticklabels(top_20_rfe['Feature'].values, fontsize=8)
ax3.set_xlabel('Score (1/Ranking)')
ax3.set_title('Top 20 Features - RFE Ranking')
ax3.invert_yaxis()
ax3.grid(axis='x', alpha=0.3)

# Plot 4: Top 30 Features by Composite Score
ax4 = plt.subplot(2, 3, 4)
top_30_composite = combined_results.head(30)
ax4.barh(range(30), top_30_composite['Composite_Score'].values, color='#9b59b6')
ax4.set_yticks(range(30))
ax4.set_yticklabels(top_30_composite['Feature'].values, fontsize=7)
ax4.set_xlabel('Composite Score')
ax4.set_title('Top 30 Features - Composite Score')
ax4.invert_yaxis()
ax4.grid(axis='x', alpha=0.3)

# Plot 5: RFE Performance vs Number of Features
ax5 = plt.subplot(2, 3, 5)
n_features_list = [r['n_features'] for r in rfe_results_list]
accuracies_list = [r['accuracy'] * 100 for r in rfe_results_list]
ax5.plot(n_features_list, accuracies_list, marker='o', linewidth=2, markersize=8, color='#e67e22')
ax5.axvline(x=best_n_features, color='red', linestyle='--', label=f'Best: {best_n_features} features')
ax5.set_xlabel('Number of Features')
ax5.set_ylabel('Test Accuracy (%)')
ax5.set_title('RFE: Performance vs Number of Features')
ax5.legend()
ax5.grid(alpha=0.3)

# Plot 6: Performance Comparison
ax6 = plt.subplot(2, 3, 6)
models = ['SVM', 'Random Forest', 'Ensemble']
all_accs = [all_features_results[m] * 100 for m in models]
sel_accs = [selected_features_results[m] * 100 for m in models]

x = np.arange(len(models))
width = 0.35

bars1 = ax6.bar(x - width/2, all_accs, width, label='All Features (57)', color='#3498db')
bars2 = ax6.bar(x + width/2, sel_accs, width, label='Selected Features (30)', color='#2ecc71')

ax6.set_ylabel('Accuracy (%)')
ax6.set_title('Performance Comparison: All vs Selected Features')
ax6.set_xticks(x)
ax6.set_xticklabels(models)
ax6.legend()
ax6.grid(axis='y', alpha=0.3)

# Add value labels on bars
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        ax6.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}%', ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig('feature_selection_analysis.png', dpi=300, bbox_inches='tight')
print("✓ Visualization saved to: feature_selection_analysis.png")
print()

# Save selected features list
with open('selected_features_list.txt', 'w', encoding='utf-8') as f:
    f.write("=" * 80 + "\n")
    f.write("Selected Features for Autism Classification\n")
    f.write("الميزات المختارة لتصنيف اضطراب طيف التوحد\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"Total Features Selected: {len(selected_features)}\n")
    f.write(f"Feature Reduction: {X_train_scaled.shape[1]} → {len(selected_features)} "
            f"({(1 - len(selected_features)/X_train_scaled.shape[1])*100:.1f}% reduction)\n\n")
    
    f.write("Selected Features (ranked by composite score):\n")
    f.write("-" * 80 + "\n\n")
    
    for i, feat in enumerate(selected_features, 1):
        row = combined_results[combined_results['Feature'] == feat].iloc[0]
        f.write(f"{i:2d}. {feat}\n")
        f.write(f"    Composite Score: {row['Composite_Score']:.4f}\n")
        f.write(f"    RF Rank: {row['RF_Rank']}, LASSO Rank: {row['LASSO_Rank']}, RFE Rank: {row['RFE_Ranking']}\n\n")

print("✓ Selected features list saved to: selected_features_list.txt")
print()

# ============================================================================
# Final Summary
# ============================================================================

print("=" * 80)
print("✅ Feature Selection Analysis Completed!")
print("✅ اكتمل تحليل اختيار الميزات!")
print("=" * 80)
print()

print("📁 Output Files:")
print("  1. feature_selection_results.xlsx - Complete feature ranking results")
print("  2. feature_selection_analysis.png - Visualization of all methods")
print("  3. selected_features_list.txt - List of selected features")
print()

print(f"End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)
