"""
Autism Spectrum Disorder (ASD) Classification - Complete Pipeline
================================================================
Three classifiers: SVM, Random Forest, XGBoost
Before and After Optimization Techniques:
1. Hybrid Feature Selection (LASSO → RF → RFE)
2. SMOTE for Class Imbalance
3. Grid Search with 10-fold CV for Hyperparameter Tuning
4. Weighted Voting Ensemble
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import json
import time
import pickle

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             classification_report, confusion_matrix, roc_auc_score)
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
from imblearn.over_sampling import SMOTE

# ============================================================
# UTILITY FUNCTIONS
# ============================================================
def evaluate_model(model, X_tr, X_te, y_tr, y_te, model_name, cv=10):
    """Comprehensive model evaluation"""
    start_time = time.time()
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)
    
    cv_strategy = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X_tr, y_tr, cv=cv_strategy, scoring='accuracy')
    
    acc = accuracy_score(y_te, y_pred)
    prec = precision_score(y_te, y_pred, average='weighted', zero_division=0)
    rec = recall_score(y_te, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_te, y_pred, average='weighted', zero_division=0)
    
    # Per-class metrics
    prec_per = precision_score(y_te, y_pred, average=None, zero_division=0)
    rec_per = recall_score(y_te, y_pred, average=None, zero_division=0)
    f1_per = f1_score(y_te, y_pred, average=None, zero_division=0)
    
    try:
        if hasattr(model, 'predict_proba'):
            y_prob = model.predict_proba(X_te)
        else:
            y_prob = model.decision_function(X_te)
        auc = roc_auc_score(y_te, y_prob, multi_class='ovr', average='weighted')
    except:
        auc = None
    
    elapsed = time.time() - start_time
    cm = confusion_matrix(y_te, y_pred)
    report = classification_report(y_te, y_pred, digits=4)
    
    results = {
        'Model': model_name,
        'Accuracy': acc,
        'Precision': prec,
        'Recall': rec,
        'F1-Score': f1,
        'AUC-ROC': auc,
        'CV_Mean': cv_scores.mean(),
        'CV_Std': cv_scores.std(),
        'Time(s)': elapsed,
        'Confusion_Matrix': cm.tolist(),
        'Per_Class_Precision': prec_per.tolist(),
        'Per_Class_Recall': rec_per.tolist(),
        'Per_Class_F1': f1_per.tolist()
    }
    
    print(f"\n{'─' * 60}")
    print(f"  {model_name}")
    print(f"{'─' * 60}")
    print(f"  Accuracy:     {acc:.4f}")
    print(f"  Precision:    {prec:.4f}")
    print(f"  Recall:       {rec:.4f}")
    print(f"  F1-Score:     {f1:.4f}")
    if auc is not None:
        print(f"  AUC-ROC:      {auc:.4f}")
    print(f"  CV Mean±Std:  {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
    print(f"  Time:         {elapsed:.2f}s")
    print(f"\n  Confusion Matrix:\n{cm}")
    print(f"\n  Classification Report:\n{report}")
    
    return results, model

def convert_numpy(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {k: convert_numpy(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy(i) for i in obj]
    return obj

# ============================================================
# 1. DATA LOADING AND PREPROCESSING
# ============================================================
print("=" * 80)
print("PHASE 1: DATA LOADING AND PREPROCESSING")
print("=" * 80)

df = pd.read_excel('/home/ubuntu/upload/Enhanced_Dataset_61_Features.xlsx')
df.columns = df.columns.str.strip()

X = df.drop('Class', axis=1)
y = df['Class']

print(f"Dataset shape: {X.shape}")
print(f"Target distribution:\n{y.value_counts().sort_index()}")

# Handle infinity values
X = X.replace([np.inf, -np.inf], np.nan)
for col in X.columns:
    if X[col].isnull().any():
        X[col].fillna(X[col].median(), inplace=True)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
print(f"\nTrain set: {X_train.shape}, Test set: {X_test.shape}")
print(f"Train distribution:\n{y_train.value_counts().sort_index()}")
print(f"Test distribution:\n{y_test.value_counts().sort_index()}")

# Scale features
scaler = StandardScaler()
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=X_train.columns, index=X_train.index)
X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns, index=X_test.index)

# ============================================================
# 2. BASELINE MODELS (Before Optimization)
# ============================================================
print("\n" + "=" * 80)
print("PHASE 2: BASELINE MODELS (Before Optimization)")
print("=" * 80)

baseline_models = {
    'SVM': SVC(kernel='rbf', random_state=42, probability=True),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
    'XGBoost': XGBClassifier(n_estimators=100, random_state=42, eval_metric='mlogloss', use_label_encoder=False)
}

baseline_results = []
for name, model in baseline_models.items():
    results, _ = evaluate_model(model, X_train_scaled, X_test_scaled, y_train, y_test, f"Baseline {name}")
    baseline_results.append(results)

baseline_df = pd.DataFrame(baseline_results)
print("\n\nBASELINE RESULTS SUMMARY:")
print(baseline_df[['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'CV_Mean']].to_string(index=False))

# ============================================================
# 3. HYBRID FEATURE SELECTION (LASSO → RF → RFE)
# ============================================================
print("\n\n" + "=" * 80)
print("PHASE 3: HYBRID FEATURE SELECTION (LASSO → RF → RFE)")
print("=" * 80)

# Stage 1: LASSO
print("\n--- Stage 1: LASSO Feature Selection ---")
# Try multiple C values and aggregate
lasso_importances = np.zeros(X_train_scaled.shape[1])
for c_val in [0.1, 0.5, 1.0, 2.0]:
    lasso_m = LogisticRegression(penalty='l1', solver='saga', C=c_val, max_iter=10000, random_state=42)
    lasso_m.fit(X_train_scaled, y_train)
    lasso_importances += np.abs(lasso_m.coef_).mean(axis=0)

lasso_importances /= 4
lasso_mask = lasso_importances > 0
lasso_features = X_train.columns[lasso_mask].tolist()

print(f"  Original features: {X_train.shape[1]}")
print(f"  Features after LASSO: {len(lasso_features)}")
print(f"  Removed features: {X_train.shape[1] - len(lasso_features)}")

# Stage 2: Random Forest Importance
print("\n--- Stage 2: Random Forest Feature Importance ---")
X_train_lasso = X_train_scaled[lasso_features]
X_test_lasso = X_test_scaled[lasso_features]

rf_selector = RandomForestClassifier(n_estimators=1000, random_state=42, n_jobs=-1)
rf_selector.fit(X_train_lasso, y_train)

rf_importance = pd.Series(rf_selector.feature_importances_, index=lasso_features)
rf_importance = rf_importance.sort_values(ascending=False)

n_top = min(30, len(lasso_features))
top_rf_features = rf_importance.head(n_top).index.tolist()

print(f"  Features after RF ranking (top {n_top}): {len(top_rf_features)}")
print(f"\n  Feature Importance Ranking:")
for i, (feat, imp) in enumerate(rf_importance.head(n_top).items()):
    print(f"    {i+1:2d}. {feat:45s} {imp:.6f}")

# Stage 3: RFE with XGBoost
print("\n--- Stage 3: RFE with XGBoost ---")
X_train_rf = X_train_scaled[top_rf_features]
X_test_rf = X_test_scaled[top_rf_features]

rfe_cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
best_score = 0
best_n = 0
best_rfe = None

print("  Searching for optimal number of features...")
for n_features in range(5, min(n_top + 1, 26)):
    rfe = RFE(estimator=XGBClassifier(n_estimators=200, random_state=42, eval_metric='mlogloss', 
                                        use_label_encoder=False),
              n_features_to_select=n_features, step=1)
    rfe.fit(X_train_rf, y_train)
    
    selected_mask = rfe.support_
    X_train_rfe_temp = X_train_rf.loc[:, selected_mask]
    
    scores = cross_val_score(XGBClassifier(n_estimators=200, random_state=42, eval_metric='mlogloss',
                                            use_label_encoder=False),
                             X_train_rfe_temp, y_train, cv=rfe_cv, scoring='accuracy')
    mean_score = scores.mean()
    
    if mean_score > best_score:
        best_score = mean_score
        best_n = n_features
        best_rfe = rfe
    
    print(f"    n_features={n_features:2d}, CV Accuracy={mean_score:.4f} ± {scores.std():.4f}")

final_selected_mask = best_rfe.support_
final_features = [f for f, s in zip(top_rf_features, final_selected_mask) if s]

print(f"\n  ★ Optimal number of features: {best_n}")
print(f"  ★ Best CV Accuracy: {best_score:.4f}")
print(f"  ★ Final selected features ({len(final_features)}):")
for i, feat in enumerate(final_features):
    print(f"    {i+1}. {feat}")

X_train_selected = X_train_scaled[final_features]
X_test_selected = X_test_scaled[final_features]

# ============================================================
# 4. SMOTE FOR CLASS IMBALANCE
# ============================================================
print("\n\n" + "=" * 80)
print("PHASE 4: SMOTE FOR CLASS IMBALANCE HANDLING")
print("=" * 80)

print(f"\nBefore SMOTE:")
print(f"  Train set shape: {X_train_selected.shape}")
print(f"  Class distribution:\n{y_train.value_counts().sort_index()}")

smote = SMOTE(random_state=42, k_neighbors=5)
X_train_smote, y_train_smote = smote.fit_resample(X_train_selected, y_train)

print(f"\nAfter SMOTE:")
print(f"  Train set shape: {X_train_smote.shape}")
print(f"  Class distribution:\n{pd.Series(y_train_smote).value_counts().sort_index()}")

# ============================================================
# 5. HYPERPARAMETER TUNING WITH GRID SEARCH (10-fold CV)
# ============================================================
print("\n\n" + "=" * 80)
print("PHASE 5: HYPERPARAMETER TUNING (Grid Search + 10-fold CV)")
print("=" * 80)

cv_strategy = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)

# --- SVM Grid Search ---
print("\n--- SVM Hyperparameter Tuning ---")
svm_param_grid = {
    'C': [0.01, 0.1, 0.5, 1, 5, 10, 50, 100],
    'gamma': ['scale', 'auto', 0.001, 0.01, 0.1],
    'kernel': ['rbf', 'poly', 'sigmoid']
}

svm_grid = GridSearchCV(
    SVC(random_state=42, probability=True),
    svm_param_grid,
    cv=cv_strategy, scoring='accuracy', n_jobs=-1, verbose=0
)
svm_grid.fit(X_train_smote, y_train_smote)
print(f"  Best SVM Parameters: {svm_grid.best_params_}")
print(f"  Best SVM CV Score: {svm_grid.best_score_:.4f}")

# --- Random Forest Grid Search ---
print("\n--- Random Forest Hyperparameter Tuning ---")
rf_param_grid = {
    'n_estimators': [100, 200, 300, 500],
    'max_depth': [3, 5, 10, 15, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2', None]
}

rf_grid = GridSearchCV(
    RandomForestClassifier(random_state=42),
    rf_param_grid, cv=cv_strategy, scoring='accuracy', n_jobs=-1, verbose=0
)
rf_grid.fit(X_train_smote, y_train_smote)
print(f"  Best RF Parameters: {rf_grid.best_params_}")
print(f"  Best RF CV Score: {rf_grid.best_score_:.4f}")

# --- XGBoost Grid Search ---
print("\n--- XGBoost Hyperparameter Tuning ---")
xgb_param_grid = {
    'n_estimators': [100, 200, 300, 500],
    'max_depth': [3, 5, 7, 10],
    'learning_rate': [0.01, 0.05, 0.1, 0.2],
    'subsample': [0.6, 0.7, 0.8, 1.0],
    'colsample_bytree': [0.6, 0.7, 0.8, 1.0],
    'reg_alpha': [0, 0.1, 1],
    'reg_lambda': [1, 2, 5]
}

# Use RandomizedSearchCV for XGBoost due to large param space
from sklearn.model_selection import RandomizedSearchCV
xgb_grid = RandomizedSearchCV(
    XGBClassifier(random_state=42, eval_metric='mlogloss', use_label_encoder=False),
    xgb_param_grid, n_iter=200, cv=cv_strategy, scoring='accuracy', n_jobs=-1, verbose=0, random_state=42
)
xgb_grid.fit(X_train_smote, y_train_smote)
print(f"  Best XGBoost Parameters: {xgb_grid.best_params_}")
print(f"  Best XGBoost CV Score: {xgb_grid.best_score_:.4f}")

# ============================================================
# 6. OPTIMIZED MODELS EVALUATION
# ============================================================
print("\n\n" + "=" * 80)
print("PHASE 6: OPTIMIZED MODELS (After All Optimization Techniques)")
print("=" * 80)

optimized_results = []
opt_models_dict = {
    'SVM': svm_grid.best_estimator_,
    'Random Forest': rf_grid.best_estimator_,
    'XGBoost': xgb_grid.best_estimator_
}

for name, model in opt_models_dict.items():
    results, _ = evaluate_model(
        model, X_train_smote, X_test_selected, y_train_smote, y_test, f"Optimized {name}"
    )
    optimized_results.append(results)

optimized_df = pd.DataFrame(optimized_results)
print("\n\nOPTIMIZED RESULTS SUMMARY:")
print(optimized_df[['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'CV_Mean']].to_string(index=False))

# ============================================================
# 7. WEIGHTED VOTING ENSEMBLE
# ============================================================
print("\n\n" + "=" * 80)
print("PHASE 7: WEIGHTED VOTING ENSEMBLE MODEL")
print("=" * 80)

# Weights based on CV scores
weights = [svm_grid.best_score_, rf_grid.best_score_, xgb_grid.best_score_]
total_w = sum(weights)
normalized_weights = [w/total_w for w in weights]

print(f"\nEnsemble Weights (based on CV scores):")
print(f"  SVM:           {normalized_weights[0]:.4f} (CV: {weights[0]:.4f})")
print(f"  Random Forest: {normalized_weights[1]:.4f} (CV: {weights[1]:.4f})")
print(f"  XGBoost:       {normalized_weights[2]:.4f} (CV: {weights[2]:.4f})")

# Build ensemble with best params
svm_best_params = {k: v for k, v in svm_grid.best_params_.items()}
rf_best_params = {k: v for k, v in rf_grid.best_params_.items()}
xgb_best_params = {k: v for k, v in xgb_grid.best_params_.items()}

ensemble = VotingClassifier(
    estimators=[
        ('svm', SVC(**svm_best_params, random_state=42, probability=True)),
        ('rf', RandomForestClassifier(**rf_best_params, random_state=42)),
        ('xgb', XGBClassifier(**xgb_best_params, random_state=42, eval_metric='mlogloss', use_label_encoder=False))
    ],
    voting='soft',
    weights=normalized_weights
)

ensemble_results, ensemble_model = evaluate_model(
    ensemble, X_train_smote, X_test_selected, y_train_smote, y_test, "Weighted Voting Ensemble"
)

# ============================================================
# 8. COMPREHENSIVE COMPARISON
# ============================================================
print("\n\n" + "=" * 80)
print("PHASE 8: COMPREHENSIVE COMPARISON (Before vs After Optimization)")
print("=" * 80)

print("\n╔══════════════════════════════════════════════════════════════════════╗")
print("║                    BEFORE OPTIMIZATION (Baseline)                   ║")
print("╚══════════════════════════════════════════════════════════════════════╝")
print(baseline_df[['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'CV_Mean']].to_string(index=False))

print("\n╔══════════════════════════════════════════════════════════════════════╗")
print("║                     AFTER OPTIMIZATION                              ║")
print("╚══════════════════════════════════════════════════════════════════════╝")
opt_with_ensemble = pd.concat([optimized_df, pd.DataFrame([ensemble_results])], ignore_index=True)
print(opt_with_ensemble[['Model', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'CV_Mean']].to_string(index=False))

print("\n╔══════════════════════════════════════════════════════════════════════╗")
print("║                     IMPROVEMENT ANALYSIS                            ║")
print("╚══════════════════════════════════════════════════════════════════════╝")
for i, name in enumerate(['SVM', 'Random Forest', 'XGBoost']):
    base_acc = baseline_results[i]['Accuracy']
    opt_acc = optimized_results[i]['Accuracy']
    base_f1 = baseline_results[i]['F1-Score']
    opt_f1 = optimized_results[i]['F1-Score']
    base_cv = baseline_results[i]['CV_Mean']
    opt_cv = optimized_results[i]['CV_Mean']
    
    acc_imp = (opt_acc - base_acc) * 100
    f1_imp = (opt_f1 - base_f1) * 100
    cv_imp = (opt_cv - base_cv) * 100
    
    print(f"\n  {name}:")
    print(f"    Accuracy:  {base_acc:.4f} → {opt_acc:.4f} (Δ = {acc_imp:+.2f}%)")
    print(f"    F1-Score:  {base_f1:.4f} → {opt_f1:.4f} (Δ = {f1_imp:+.2f}%)")
    print(f"    CV Score:  {base_cv:.4f} → {opt_cv:.4f} (Δ = {cv_imp:+.2f}%)")

print(f"\n  Ensemble Performance:")
print(f"    Accuracy:  {ensemble_results['Accuracy']:.4f}")
print(f"    F1-Score:  {ensemble_results['F1-Score']:.4f}")
print(f"    AUC-ROC:   {ensemble_results['AUC-ROC']:.4f}")
print(f"    CV Score:  {ensemble_results['CV_Mean']:.4f}")

# ============================================================
# 9. SAVE ALL RESULTS
# ============================================================
all_results = {
    'baseline': baseline_results,
    'optimized': optimized_results,
    'ensemble': ensemble_results,
    'feature_selection': {
        'original_features': int(X_train.shape[1]),
        'after_lasso': len(lasso_features),
        'lasso_features': lasso_features,
        'after_rf_ranking': len(top_rf_features),
        'rf_ranked_features': top_rf_features,
        'rf_importances': {f: float(v) for f, v in rf_importance.head(n_top).items()},
        'after_rfe': len(final_features),
        'final_features': final_features
    },
    'smote': {
        'before': {str(k): int(v) for k, v in y_train.value_counts().sort_index().items()},
        'after': {str(k): int(v) for k, v in pd.Series(y_train_smote).value_counts().sort_index().items()}
    },
    'best_params': {
        'svm': {k: str(v) if not isinstance(v, (int, float, str, bool, type(None))) else v 
                for k, v in svm_grid.best_params_.items()},
        'rf': {k: str(v) if not isinstance(v, (int, float, str, bool, type(None))) else v 
               for k, v in rf_grid.best_params_.items()},
        'xgb': {k: str(v) if not isinstance(v, (int, float, str, bool, type(None))) else v 
                for k, v in xgb_grid.best_params_.items()}
    },
    'ensemble_weights': {
        'svm': float(normalized_weights[0]),
        'rf': float(normalized_weights[1]),
        'xgb': float(normalized_weights[2])
    }
}

all_results = convert_numpy(all_results)

with open('/home/ubuntu/all_results.json', 'w') as f:
    json.dump(all_results, f, indent=2, default=str)

print("\n\nAll results saved to /home/ubuntu/all_results.json")
print("\n" + "=" * 80)
print("PIPELINE COMPLETED SUCCESSFULLY!")
print("=" * 80)
