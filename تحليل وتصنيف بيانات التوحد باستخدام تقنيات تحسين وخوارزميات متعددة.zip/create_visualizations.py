"""
Create comprehensive visualizations for ASD Classification Results
"""
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

# Load results
with open('/home/ubuntu/all_results.json', 'r') as f:
    results = json.load(f)

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams.update({
    'font.size': 11,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'figure.dpi': 150,
    'savefig.dpi': 150,
    'savefig.bbox': 'tight'
})

colors_baseline = ['#3498db', '#2ecc71', '#e74c3c']
colors_optimized = ['#2980b9', '#27ae60', '#c0392b']
colors_all = ['#3498db', '#2ecc71', '#e74c3c', '#9b59b6']

# ============================================================
# Figure 1: Accuracy Comparison (Before vs After)
# ============================================================
fig, ax = plt.subplots(figsize=(12, 7))

models = ['SVM', 'Random Forest', 'XGBoost']
baseline_acc = [r['Accuracy'] for r in results['baseline']]
optimized_acc = [r['Accuracy'] for r in results['optimized']]
ensemble_acc = results['ensemble']['Accuracy']

x = np.arange(len(models))
width = 0.3

bars1 = ax.bar(x - width/2, baseline_acc, width, label='Before Optimization', 
               color=['#AED6F1', '#A9DFBF', '#F5B7B1'], edgecolor='black', linewidth=0.5)
bars2 = ax.bar(x + width/2, optimized_acc, width, label='After Optimization', 
               color=['#2980B9', '#27AE60', '#C0392B'], edgecolor='black', linewidth=0.5)

# Add ensemble bar
ax.bar(len(models), ensemble_acc, width, label='Weighted Voting Ensemble', 
       color='#8E44AD', edgecolor='black', linewidth=0.5)

# Add value labels
for bar in bars1:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.005,
            f'{height:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
for bar in bars2:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.005,
            f'{height:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
ax.text(len(models), ensemble_acc + 0.005, f'{ensemble_acc:.3f}', 
        ha='center', va='bottom', fontsize=10, fontweight='bold')

ax.set_ylabel('Accuracy')
ax.set_title('Model Accuracy Comparison: Before vs After Optimization', fontweight='bold', fontsize=15)
ax.set_xticks(list(x) + [len(models)])
ax.set_xticklabels(models + ['Ensemble'])
ax.legend(loc='upper left')
ax.set_ylim(0, 1.0)
ax.axhline(y=0.5, color='gray', linestyle='--', alpha=0.3)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig1_accuracy_comparison.png')
plt.close()

# ============================================================
# Figure 2: Multi-Metric Comparison (Grouped Bar Chart)
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(18, 7))

metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']

# Before optimization
for i, model in enumerate(models):
    values = [results['baseline'][i][m] for m in metrics]
    axes[0].bar(np.arange(len(metrics)) + i*0.25, values, 0.25, 
                label=model, color=colors_baseline[i], edgecolor='black', linewidth=0.5)
    for j, v in enumerate(values):
        axes[0].text(j + i*0.25, v + 0.005, f'{v:.3f}', ha='center', va='bottom', fontsize=8)

axes[0].set_xticks(np.arange(len(metrics)) + 0.25)
axes[0].set_xticklabels(metrics)
axes[0].set_title('Before Optimization', fontweight='bold', fontsize=14)
axes[0].set_ylabel('Score')
axes[0].legend()
axes[0].set_ylim(0, 1.0)

# After optimization
for i, model in enumerate(models):
    values = [results['optimized'][i][m] for m in metrics]
    axes[1].bar(np.arange(len(metrics)) + i*0.25, values, 0.25, 
                label=model, color=colors_optimized[i], edgecolor='black', linewidth=0.5)
    for j, v in enumerate(values):
        axes[1].text(j + i*0.25, v + 0.005, f'{v:.3f}', ha='center', va='bottom', fontsize=8)

# Add ensemble
ens_values = [results['ensemble'][m] for m in metrics]
axes[1].bar(np.arange(len(metrics)) + 3*0.25, ens_values, 0.25, 
            label='Ensemble', color='#8E44AD', edgecolor='black', linewidth=0.5)
for j, v in enumerate(ens_values):
    axes[1].text(j + 3*0.25, v + 0.005, f'{v:.3f}', ha='center', va='bottom', fontsize=8)

axes[1].set_xticks(np.arange(len(metrics)) + 0.375)
axes[1].set_xticklabels(metrics)
axes[1].set_title('After Optimization', fontweight='bold', fontsize=14)
axes[1].set_ylabel('Score')
axes[1].legend()
axes[1].set_ylim(0, 1.0)

plt.suptitle('Multi-Metric Performance Comparison', fontweight='bold', fontsize=16, y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig2_multi_metric_comparison.png')
plt.close()

# ============================================================
# Figure 3: Confusion Matrices (2x4 grid)
# ============================================================
fig, axes = plt.subplots(2, 4, figsize=(22, 10))

class_labels = ['Level 0', 'Level 1', 'Level 2']

# Baseline confusion matrices
for i, model in enumerate(models):
    cm = np.array(results['baseline'][i]['Confusion_Matrix'])
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0, i],
                xticklabels=class_labels, yticklabels=class_labels, cbar=False)
    axes[0, i].set_title(f'Baseline {model}', fontweight='bold')
    axes[0, i].set_ylabel('True Label')
    axes[0, i].set_xlabel('Predicted Label')

# Optimized confusion matrices
for i, model in enumerate(models):
    cm = np.array(results['optimized'][i]['Confusion_Matrix'])
    sns.heatmap(cm, annot=True, fmt='d', cmap='Greens', ax=axes[1, i],
                xticklabels=class_labels, yticklabels=class_labels, cbar=False)
    axes[1, i].set_title(f'Optimized {model}', fontweight='bold')
    axes[1, i].set_ylabel('True Label')
    axes[1, i].set_xlabel('Predicted Label')

# Ensemble confusion matrix
cm_ens = np.array(results['ensemble']['Confusion_Matrix'])
sns.heatmap(cm_ens, annot=True, fmt='d', cmap='Purples', ax=axes[1, 3],
            xticklabels=class_labels, yticklabels=class_labels, cbar=False)
axes[1, 3].set_title('Weighted Voting Ensemble', fontweight='bold')
axes[1, 3].set_ylabel('True Label')
axes[1, 3].set_xlabel('Predicted Label')

# Hide unused subplot
axes[0, 3].axis('off')
axes[0, 3].text(0.5, 0.5, 'Baseline Models\n(Before Optimization)', 
                transform=axes[0, 3].transAxes, ha='center', va='center',
                fontsize=14, fontweight='bold', color='#2C3E50',
                bbox=dict(boxstyle='round,pad=0.5', facecolor='#ECF0F1'))

plt.suptitle('Confusion Matrices: Before and After Optimization', fontweight='bold', fontsize=16)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig3_confusion_matrices.png')
plt.close()

# ============================================================
# Figure 4: Feature Selection Pipeline
# ============================================================
fig, ax = plt.subplots(figsize=(12, 6))

fs = results['feature_selection']
stages = ['Original\nFeatures', 'After LASSO\n(Stage 1)', 'After RF Ranking\n(Stage 2)', 'After RFE\n(Stage 3)']
counts = [fs['original_features'], fs['after_lasso'], fs['after_rf_ranking'], fs['after_rfe']]
stage_colors = ['#E74C3C', '#F39C12', '#3498DB', '#27AE60']

bars = ax.bar(stages, counts, color=stage_colors, edgecolor='black', linewidth=0.5, width=0.6)
for bar, count in zip(bars, counts):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.5,
            str(count), ha='center', va='bottom', fontsize=14, fontweight='bold')

# Add arrows
for i in range(len(stages)-1):
    ax.annotate('', xy=(i+1, counts[i+1] + 3), xytext=(i, counts[i] + 3),
                arrowprops=dict(arrowstyle='->', color='#2C3E50', lw=2))
    reduction = counts[i] - counts[i+1]
    pct = (reduction / counts[i]) * 100
    ax.text(i + 0.5, max(counts[i], counts[i+1]) + 5, f'-{reduction} ({pct:.0f}%)',
            ha='center', fontsize=10, color='#E74C3C', fontweight='bold')

ax.set_ylabel('Number of Features')
ax.set_title('Hybrid Feature Selection Pipeline (LASSO → RF → RFE)', fontweight='bold', fontsize=15)
ax.set_ylim(0, max(counts) + 15)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig4_feature_selection.png')
plt.close()

# ============================================================
# Figure 5: Feature Importance (Top features from RF)
# ============================================================
fig, ax = plt.subplots(figsize=(14, 8))

# Get top 20 RF importances
rf_imp = results['feature_selection']['rf_importances']
features = list(rf_imp.keys())[:20]
importances = list(rf_imp.values())[:20]

# Reverse for horizontal bar
features = features[::-1]
importances = importances[::-1]

# Color final selected features differently
final_feats = set(results['feature_selection']['final_features'])
bar_colors = ['#27AE60' if f in final_feats else '#BDC3C7' for f in features]

bars = ax.barh(features, importances, color=bar_colors, edgecolor='black', linewidth=0.5)
for bar, imp in zip(bars, importances):
    ax.text(imp + 0.001, bar.get_y() + bar.get_height()/2., f'{imp:.4f}',
            va='center', fontsize=9)

# Legend
selected_patch = mpatches.Patch(color='#27AE60', label='Final Selected Features')
other_patch = mpatches.Patch(color='#BDC3C7', label='Not Selected (after RFE)')
ax.legend(handles=[selected_patch, other_patch], loc='lower right')

ax.set_xlabel('Feature Importance (Random Forest)')
ax.set_title('Top 20 Feature Importances (Green = Final Selected)', fontweight='bold', fontsize=15)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig5_feature_importance.png')
plt.close()

# ============================================================
# Figure 6: CV Score Comparison
# ============================================================
fig, ax = plt.subplots(figsize=(12, 7))

baseline_cv = [r['CV_Mean'] for r in results['baseline']]
baseline_cv_std = [r['CV_Std'] for r in results['baseline']]
optimized_cv = [r['CV_Mean'] for r in results['optimized']]
optimized_cv_std = [r['CV_Std'] for r in results['optimized']]
ensemble_cv = results['ensemble']['CV_Mean']
ensemble_cv_std = results['ensemble']['CV_Std']

x = np.arange(len(models))
width = 0.3

bars1 = ax.bar(x - width/2, baseline_cv, width, yerr=baseline_cv_std, 
               label='Before Optimization', color=['#AED6F1', '#A9DFBF', '#F5B7B1'],
               edgecolor='black', linewidth=0.5, capsize=5)
bars2 = ax.bar(x + width/2, optimized_cv, width, yerr=optimized_cv_std,
               label='After Optimization', color=['#2980B9', '#27AE60', '#C0392B'],
               edgecolor='black', linewidth=0.5, capsize=5)

ax.bar(len(models), ensemble_cv, width, yerr=ensemble_cv_std,
       label='Ensemble', color='#8E44AD', edgecolor='black', linewidth=0.5, capsize=5)

for bar in bars1:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.02,
            f'{height:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
for bar in bars2:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.02,
            f'{height:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
ax.text(len(models), ensemble_cv + 0.02, f'{ensemble_cv:.3f}',
        ha='center', va='bottom', fontsize=10, fontweight='bold')

ax.set_ylabel('Cross-Validation Accuracy (10-fold)')
ax.set_title('10-Fold Cross-Validation Scores Comparison', fontweight='bold', fontsize=15)
ax.set_xticks(list(x) + [len(models)])
ax.set_xticklabels(models + ['Ensemble'])
ax.legend()
ax.set_ylim(0, 1.0)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig6_cv_comparison.png')
plt.close()

# ============================================================
# Figure 7: SMOTE Class Distribution
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

smote_data = results['smote']
before_classes = list(smote_data['before'].keys())
before_counts = list(smote_data['before'].values())
after_classes = list(smote_data['after'].keys())
after_counts = list(smote_data['after'].values())

class_colors = ['#E74C3C', '#3498DB', '#2ECC71']

bars1 = axes[0].bar(before_classes, before_counts, color=class_colors, edgecolor='black', linewidth=0.5)
for bar, count in zip(bars1, before_counts):
    axes[0].text(bar.get_x() + bar.get_width()/2., bar.get_height() + 1,
                str(count), ha='center', fontsize=12, fontweight='bold')
axes[0].set_title('Before SMOTE', fontweight='bold', fontsize=14)
axes[0].set_xlabel('Class')
axes[0].set_ylabel('Number of Samples')
axes[0].set_ylim(0, max(before_counts) + 15)

bars2 = axes[1].bar(after_classes, after_counts, color=class_colors, edgecolor='black', linewidth=0.5)
for bar, count in zip(bars2, after_counts):
    axes[1].text(bar.get_x() + bar.get_width()/2., bar.get_height() + 1,
                str(count), ha='center', fontsize=12, fontweight='bold')
axes[1].set_title('After SMOTE', fontweight='bold', fontsize=14)
axes[1].set_xlabel('Class')
axes[1].set_ylabel('Number of Samples')
axes[1].set_ylim(0, max(after_counts) + 15)

plt.suptitle('Class Distribution: Before and After SMOTE', fontweight='bold', fontsize=16, y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig7_smote_distribution.png')
plt.close()

# ============================================================
# Figure 8: Per-Class F1-Score Comparison
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(16, 7))

class_names = ['Class 0\n(Level 0)', 'Class 1\n(Level 1)', 'Class 2\n(Level 2)']

# Before
for i, model in enumerate(models):
    f1_per = results['baseline'][i]['Per_Class_F1']
    axes[0].bar(np.arange(3) + i*0.25, f1_per, 0.25, label=model, 
                color=colors_baseline[i], edgecolor='black', linewidth=0.5)
    for j, v in enumerate(f1_per):
        axes[0].text(j + i*0.25, v + 0.01, f'{v:.3f}', ha='center', fontsize=8)

axes[0].set_xticks(np.arange(3) + 0.25)
axes[0].set_xticklabels(class_names)
axes[0].set_title('Before Optimization', fontweight='bold')
axes[0].set_ylabel('F1-Score')
axes[0].legend()
axes[0].set_ylim(0, 1.1)

# After
for i, model in enumerate(models):
    f1_per = results['optimized'][i]['Per_Class_F1']
    axes[1].bar(np.arange(3) + i*0.2, f1_per, 0.2, label=model,
                color=colors_optimized[i], edgecolor='black', linewidth=0.5)
    for j, v in enumerate(f1_per):
        axes[1].text(j + i*0.2, v + 0.01, f'{v:.3f}', ha='center', fontsize=8)

# Ensemble
ens_f1 = results['ensemble']['Per_Class_F1']
axes[1].bar(np.arange(3) + 3*0.2, ens_f1, 0.2, label='Ensemble',
            color='#8E44AD', edgecolor='black', linewidth=0.5)
for j, v in enumerate(ens_f1):
    axes[1].text(j + 3*0.2, v + 0.01, f'{v:.3f}', ha='center', fontsize=8)

axes[1].set_xticks(np.arange(3) + 0.3)
axes[1].set_xticklabels(class_names)
axes[1].set_title('After Optimization', fontweight='bold')
axes[1].set_ylabel('F1-Score')
axes[1].legend()
axes[1].set_ylim(0, 1.1)

plt.suptitle('Per-Class F1-Score Comparison', fontweight='bold', fontsize=16, y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig8_per_class_f1.png')
plt.close()

# ============================================================
# Figure 9: Improvement Radar Chart
# ============================================================
fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))

metrics_radar = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC']
angles = np.linspace(0, 2*np.pi, len(metrics_radar), endpoint=False).tolist()
angles += angles[:1]

for i, model in enumerate(models):
    base_vals = [results['baseline'][i][m] for m in metrics_radar]
    base_vals += base_vals[:1]
    ax.plot(angles, base_vals, 'o--', linewidth=1.5, label=f'Baseline {model}', 
            color=colors_baseline[i], alpha=0.6)
    
    opt_vals = [results['optimized'][i][m] for m in metrics_radar]
    opt_vals += opt_vals[:1]
    ax.plot(angles, opt_vals, 'o-', linewidth=2, label=f'Optimized {model}',
            color=colors_optimized[i])

# Ensemble
ens_vals = [results['ensemble'][m] for m in metrics_radar]
ens_vals += ens_vals[:1]
ax.plot(angles, ens_vals, 's-', linewidth=2.5, label='Ensemble', color='#8E44AD')

ax.set_xticks(angles[:-1])
ax.set_xticklabels(metrics_radar, fontsize=12)
ax.set_ylim(0, 1)
ax.set_title('Performance Radar Chart', fontweight='bold', fontsize=15, pad=20)
ax.legend(loc='upper right', bbox_to_anchor=(1.35, 1.1), fontsize=9)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig9_radar_chart.png')
plt.close()

print("All 9 figures saved successfully!")
print("Files: fig1 through fig9")
