import pandas as pd
import numpy as np

# Load data
df = pd.read_excel('/home/ubuntu/upload/Enhanced_Dataset_61_Features.xlsx')

# Clean column names
df.columns = df.columns.str.strip()

print("=" * 60)
print("DATASET OVERVIEW")
print("=" * 60)
print(f"Shape: {df.shape}")
print(f"\nColumn names:\n{list(df.columns)}")
print(f"\nData types:\n{df.dtypes}")
print(f"\nFirst 5 rows:\n{df.head()}")
print(f"\nBasic statistics:\n{df.describe()}")
print(f"\nMissing values:\n{df.isnull().sum()}")
print(f"\nTarget variable (Class) distribution:\n{df['Class'].value_counts()}")
print(f"\nTarget variable percentages:\n{df['Class'].value_counts(normalize=True)*100}")
print(f"\nTotal missing values: {df.isnull().sum().sum()}")
print(f"\nDuplicate rows: {df.duplicated().sum()}")
