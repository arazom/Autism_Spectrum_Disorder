#!/usr/bin/env python3
"""
Clustering Analysis: K-Means, Hierarchical Clustering, and GMM
Applied to Autism Severity Classification Dataset
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score, calinski_harabasz_score, davies_bouldin_score,
    adjusted_rand_score, normalized_mutual_info_score,
    confusion_matrix, accuracy_score, classification_report
)
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.optimize import linear_sum_assignment
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. Load and Prepare Data
# ============================================================
print("=" * 70)
print("1. LOADING AND PREPARING DATA")
print("=" * 70)

df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

# Clean column names (remove whitespace and newlines)
df.columns = df.columns.str.strip().str.replace('\n', '')

print(f"Dataset shape: {df.shape}")
print(f"Number of samples: {df.shape[0]}")
print(f"Number of features: {df.shape[1] - 1}")  # excluding Class

# Separate features and true labels
X = df.drop('Class', axis=1)
y_true = df['Class'].values

feature_names = X.columns.tolist()
print(f"\nFeature names: {feature_names}")
print(f"\nTrue class distribution:")
for cls in sorted(df['Class'].unique()):
    count = (y_true == cls).sum()
    print(f"  Class {cls}: {count} samples ({count/len(y_true)*100:.1f}%)")

# ============================================================
# 2. Standardize Features
# ============================================================
print("\n" + "=" * 70)
print("2. STANDARDIZING FEATURES")
print("=" * 70)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
print(f"Scaled data shape: {X_scaled.shape}")
print(f"Mean after scaling: {X_scaled.mean(axis=0).mean():.6f}")
print(f"Std after scaling: {X_scaled.std(axis=0).mean():.6f}")

# PCA for visualization (2D)
pca_2d = PCA(n_components=2)
X_pca_2d = pca_2d.fit_transform(X_scaled)
print(f"\nPCA 2D explained variance ratio: {pca_2d.explained_variance_ratio_}")
print(f"Total variance explained (2D): {sum(pca_2d.explained_variance_ratio_)*100:.2f}%")

# PCA for visualization (3D)
pca_3d = PCA(n_components=3)
X_pca_3d = pca_3d.fit_transform(X_scaled)
print(f"Total variance explained (3D): {sum(pca_3d.explained_variance_ratio_)*100:.2f}%")

# ============================================================
# 3. Helper function for label mapping
# ============================================================
def map_clusters_to_labels(y_true, y_pred):
    """Map cluster labels to true labels using Hungarian algorithm."""
    n_classes = len(np.unique(y_true))
    n_clusters = len(np.unique(y_pred))
    
    # Build cost matrix
    cost_matrix = np.zeros((n_clusters, n_classes))
    for i in range(n_clusters):
        for j in range(n_classes):
            cost_matrix[i, j] = -np.sum((y_pred == i) & (y_true == j))
    
    row_ind, col_ind = linear_sum_assignment(cost_matrix)
    
    mapping = {}
    for r, c in zip(row_ind, col_ind):
        mapping[r] = c
    
    y_mapped = np.array([mapping.get(label, label) for label in y_pred])
    return y_mapped, mapping

# ============================================================
# 4. Apply Clustering Algorithms
# ============================================================
print("\n" + "=" * 70)
print("3. APPLYING CLUSTERING ALGORITHMS")
print("=" * 70)

results = {}

# --- K-Means ---
print("\n--- K-Means Clustering (k=3) ---")
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10, max_iter=300)
kmeans_labels = kmeans.fit_predict(X_scaled)
kmeans_mapped, kmeans_mapping = map_clusters_to_labels(y_true, kmeans_labels)

print(f"Cluster mapping: {kmeans_mapping}")
print(f"Inertia: {kmeans.inertia_:.2f}")
print(f"Number of iterations: {kmeans.n_iter_}")

for i in range(3):
    print(f"  Cluster {i}: {(kmeans_labels == i).sum()} samples")

results['K-Means'] = {
    'labels': kmeans_labels,
    'mapped_labels': kmeans_mapped,
    'model': kmeans
}

# --- Hierarchical Clustering (Ward's linkage) ---
print("\n--- Hierarchical Clustering (Ward's Linkage) ---")
hierarchical = AgglomerativeClustering(n_clusters=3, linkage='ward')
hier_labels = hierarchical.fit_predict(X_scaled)
hier_mapped, hier_mapping = map_clusters_to_labels(y_true, hier_labels)

print(f"Cluster mapping: {hier_mapping}")
for i in range(3):
    print(f"  Cluster {i}: {(hier_labels == i).sum()} samples")

results['Hierarchical'] = {
    'labels': hier_labels,
    'mapped_labels': hier_mapped,
    'model': hierarchical
}

# --- Gaussian Mixture Model ---
print("\n--- Gaussian Mixture Model (3 components) ---")
gmm = GaussianMixture(n_components=3, random_state=42, covariance_type='full', n_init=5)
gmm.fit(X_scaled)
gmm_labels = gmm.predict(X_scaled)
gmm_probs = gmm.predict_proba(X_scaled)
gmm_mapped, gmm_mapping = map_clusters_to_labels(y_true, gmm_labels)

print(f"Cluster mapping: {gmm_mapping}")
print(f"Converged: {gmm.converged_}")
print(f"Number of iterations: {gmm.n_iter_}")
print(f"BIC: {gmm.bic(X_scaled):.2f}")
print(f"AIC: {gmm.aic(X_scaled):.2f}")
for i in range(3):
    print(f"  Component {i}: {(gmm_labels == i).sum()} samples")

results['GMM'] = {
    'labels': gmm_labels,
    'mapped_labels': gmm_mapped,
    'model': gmm,
    'probabilities': gmm_probs
}

# ============================================================
# 5. Evaluation Metrics
# ============================================================
print("\n" + "=" * 70)
print("4. EVALUATION METRICS")
print("=" * 70)

metrics_data = []
for name, res in results.items():
    labels = res['labels']
    mapped = res['mapped_labels']
    
    # Internal metrics
    sil = silhouette_score(X_scaled, labels)
    ch = calinski_harabasz_score(X_scaled, labels)
    db = davies_bouldin_score(X_scaled, labels)
    
    # External metrics (comparing with true labels)
    ari = adjusted_rand_score(y_true, labels)
    nmi = normalized_mutual_info_score(y_true, labels)
    acc = accuracy_score(y_true, mapped)
    
    metrics = {
        'Algorithm': name,
        'Silhouette Score': sil,
        'Calinski-Harabasz Index': ch,
        'Davies-Bouldin Index': db,
        'Adjusted Rand Index (ARI)': ari,
        'Normalized Mutual Info (NMI)': nmi,
        'Accuracy (mapped)': acc
    }
    metrics_data.append(metrics)
    
    print(f"\n--- {name} ---")
    print(f"  Silhouette Score:          {sil:.4f}")
    print(f"  Calinski-Harabasz Index:   {ch:.4f}")
    print(f"  Davies-Bouldin Index:      {db:.4f}")
    print(f"  Adjusted Rand Index:       {ari:.4f}")
    print(f"  Normalized Mutual Info:    {nmi:.4f}")
    print(f"  Accuracy (mapped):         {acc:.4f} ({acc*100:.2f}%)")

metrics_df = pd.DataFrame(metrics_data)
print("\n\nComparison Table:")
print(metrics_df.to_string(index=False))

# ============================================================
# 6. Confusion Matrices
# ============================================================
print("\n" + "=" * 70)
print("5. CONFUSION MATRICES (Mapped Labels vs True Labels)")
print("=" * 70)

for name, res in results.items():
    mapped = res['mapped_labels']
    cm = confusion_matrix(y_true, mapped)
    print(f"\n--- {name} ---")
    print(cm)
    print(f"\nClassification Report:")
    print(classification_report(y_true, mapped, target_names=['Class 0 (Mild)', 'Class 1 (Moderate)', 'Class 2 (Severe)']))

# ============================================================
# 7. Cluster Centers Analysis (K-Means)
# ============================================================
print("\n" + "=" * 70)
print("6. K-MEANS CLUSTER CENTERS (Top Features)")
print("=" * 70)

centers = scaler.inverse_transform(kmeans.cluster_centers_)
centers_df = pd.DataFrame(centers, columns=feature_names)
print(centers_df.round(2).to_string())

# ============================================================
# 8. Save Results to Excel
# ============================================================
print("\n" + "=" * 70)
print("7. SAVING RESULTS")
print("=" * 70)

# Add cluster labels to original dataframe
df_results = df.copy()
df_results['KMeans_Cluster'] = kmeans_labels
df_results['KMeans_Mapped'] = kmeans_mapped
df_results['Hierarchical_Cluster'] = hier_labels
df_results['Hierarchical_Mapped'] = hier_mapped
df_results['GMM_Cluster'] = gmm_labels
df_results['GMM_Mapped'] = gmm_mapped

# GMM probabilities
for i in range(3):
    df_results[f'GMM_Prob_Cluster{i}'] = gmm_probs[:, i]

df_results.to_excel('/home/ubuntu/clustering_results.xlsx', index=False)
metrics_df.to_excel('/home/ubuntu/clustering_metrics.xlsx', index=False)
print("Results saved to clustering_results.xlsx")
print("Metrics saved to clustering_metrics.xlsx")

# ============================================================
# 9. VISUALIZATIONS
# ============================================================
print("\n" + "=" * 70)
print("8. GENERATING VISUALIZATIONS")
print("=" * 70)

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
colors = ['#2196F3', '#FF9800', '#4CAF50']
severity_labels = ['Mild (0)', 'Moderate (1)', 'Severe (2)']

# ---- Figure 1: True Labels PCA ----
fig, ax = plt.subplots(figsize=(10, 8))
for i, label in enumerate(severity_labels):
    mask = y_true == i
    ax.scatter(X_pca_2d[mask, 0], X_pca_2d[mask, 1], c=colors[i], 
               label=label, alpha=0.6, s=50, edgecolors='white', linewidth=0.5)
ax.set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0]*100:.1f}%)', fontsize=12)
ax.set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1]*100:.1f}%)', fontsize=12)
ax.set_title('True Labels - PCA Visualization', fontsize=14, fontweight='bold')
ax.legend(title='Severity Level', fontsize=11)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig1_true_labels_pca.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig1_true_labels_pca.png")

# ---- Figure 2: All Clustering Results Side by Side ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
algo_names = ['K-Means', 'Hierarchical', 'GMM']

for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    labels = results[name]['labels']
    for i in range(3):
        mask = labels == i
        ax.scatter(X_pca_2d[mask, 0], X_pca_2d[mask, 1], c=colors[i],
                   label=f'Cluster {i}', alpha=0.6, s=40, edgecolors='white', linewidth=0.5)
    ax.set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0]*100:.1f}%)', fontsize=11)
    ax.set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1]*100:.1f}%)', fontsize=11)
    ax.set_title(f'{name} Clustering', fontsize=13, fontweight='bold')
    ax.legend(fontsize=9)

plt.suptitle('Clustering Results Comparison (PCA 2D)', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig2_clustering_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig2_clustering_comparison.png")

# ---- Figure 3: Mapped Labels vs True Labels ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))

for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    mapped = results[name]['mapped_labels']
    correct = mapped == y_true
    ax.scatter(X_pca_2d[correct, 0], X_pca_2d[correct, 1], c='#4CAF50',
               label='Correct', alpha=0.5, s=40, edgecolors='white', linewidth=0.5)
    ax.scatter(X_pca_2d[~correct, 0], X_pca_2d[~correct, 1], c='#F44336',
               label='Misclassified', alpha=0.7, s=40, edgecolors='white', linewidth=0.5, marker='x')
    acc = accuracy_score(y_true, mapped)
    ax.set_xlabel(f'PC1', fontsize=11)
    ax.set_ylabel(f'PC2', fontsize=11)
    ax.set_title(f'{name} (Accuracy: {acc*100:.1f}%)', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)

plt.suptitle('Correct vs Misclassified Samples', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig3_correct_vs_misclassified.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig3_correct_vs_misclassified.png")

# ---- Figure 4: Confusion Matrices ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
class_labels = ['Class 0\n(Mild)', 'Class 1\n(Moderate)', 'Class 2\n(Severe)']

for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    mapped = results[name]['mapped_labels']
    cm = confusion_matrix(y_true, mapped)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=class_labels, yticklabels=class_labels,
                cbar_kws={'shrink': 0.8})
    acc = accuracy_score(y_true, mapped)
    ax.set_xlabel('Predicted', fontsize=11)
    ax.set_ylabel('True', fontsize=11)
    ax.set_title(f'{name}\nAccuracy: {acc*100:.1f}%', fontsize=13, fontweight='bold')

plt.suptitle('Confusion Matrices', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig4_confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig4_confusion_matrices.png")

# ---- Figure 5: Metrics Comparison Bar Chart ----
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
metric_names = ['Silhouette Score', 'Calinski-Harabasz Index', 'Davies-Bouldin Index',
                'Adjusted Rand Index (ARI)', 'Normalized Mutual Info (NMI)', 'Accuracy (mapped)']
bar_colors = ['#2196F3', '#FF9800', '#4CAF50']

for idx, (metric, ax) in enumerate(zip(metric_names, axes.flat)):
    values = [metrics_df[metrics_df['Algorithm'] == algo][metric].values[0] for algo in algo_names]
    bars = ax.bar(algo_names, values, color=bar_colors, edgecolor='white', linewidth=1.5, width=0.5)
    
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.01 * max(values),
                f'{val:.4f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax.set_title(metric, fontsize=12, fontweight='bold')
    ax.set_ylabel('Score', fontsize=10)
    ax.grid(axis='y', alpha=0.3)

plt.suptitle('Clustering Evaluation Metrics Comparison', fontsize=15, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig5_metrics_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig5_metrics_comparison.png")

# ---- Figure 6: Dendrogram for Hierarchical Clustering ----
fig, ax = plt.subplots(figsize=(16, 8))
Z = linkage(X_scaled, method='ward')
dendrogram(Z, ax=ax, truncate_mode='lastp', p=30, leaf_rotation=90,
           leaf_font_size=8, color_threshold=0.7 * max(Z[:, 2]))
ax.set_title('Hierarchical Clustering Dendrogram (Ward\'s Linkage)', fontsize=14, fontweight='bold')
ax.set_xlabel('Sample Index (or cluster size)', fontsize=12)
ax.set_ylabel('Distance', fontsize=12)
ax.axhline(y=0.7 * max(Z[:, 2]), color='r', linestyle='--', label='Cut threshold')
ax.legend(fontsize=11)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig6_dendrogram.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig6_dendrogram.png")

# ---- Figure 7: Cluster Size Distribution ----
fig, axes = plt.subplots(1, 4, figsize=(20, 5))

# True labels
true_counts = [np.sum(y_true == i) for i in range(3)]
axes[0].bar(severity_labels, true_counts, color=colors, edgecolor='white', linewidth=1.5)
axes[0].set_title('True Labels', fontsize=13, fontweight='bold')
axes[0].set_ylabel('Count', fontsize=11)
for i, v in enumerate(true_counts):
    axes[0].text(i, v + 2, str(v), ha='center', fontweight='bold')

for idx, name in enumerate(algo_names):
    labels = results[name]['labels']
    counts = [np.sum(labels == i) for i in range(3)]
    axes[idx+1].bar([f'Cluster {i}' for i in range(3)], counts, color=colors, edgecolor='white', linewidth=1.5)
    axes[idx+1].set_title(f'{name}', fontsize=13, fontweight='bold')
    axes[idx+1].set_ylabel('Count', fontsize=11)
    for i, v in enumerate(counts):
        axes[idx+1].text(i, v + 2, str(v), ha='center', fontweight='bold')

plt.suptitle('Cluster Size Distribution', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig7_cluster_sizes.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig7_cluster_sizes.png")

# ---- Figure 8: GMM Probability Distribution ----
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for i in range(3):
    axes[i].hist(gmm_probs[:, i], bins=30, color=colors[i], edgecolor='white', alpha=0.8)
    axes[i].set_title(f'Component {i} Probability', fontsize=13, fontweight='bold')
    axes[i].set_xlabel('Probability', fontsize=11)
    axes[i].set_ylabel('Frequency', fontsize=11)
    axes[i].axvline(x=0.5, color='red', linestyle='--', alpha=0.7, label='p=0.5')
    axes[i].legend()

plt.suptitle('GMM - Posterior Probability Distribution', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig8_gmm_probabilities.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig8_gmm_probabilities.png")

# ---- Figure 9: Silhouette Analysis per Algorithm ----
from sklearn.metrics import silhouette_samples

fig, axes = plt.subplots(1, 3, figsize=(20, 6))

for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    labels = results[name]['labels']
    sil_vals = silhouette_samples(X_scaled, labels)
    y_lower = 10
    
    for i in range(3):
        cluster_sil = sil_vals[labels == i]
        cluster_sil.sort()
        size = cluster_sil.shape[0]
        y_upper = y_lower + size
        
        ax.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                         facecolor=colors[i], edgecolor=colors[i], alpha=0.7)
        ax.text(-0.05, y_lower + 0.5 * size, str(i), fontsize=10, fontweight='bold')
        y_lower = y_upper + 10
    
    avg_sil = silhouette_score(X_scaled, labels)
    ax.axvline(x=avg_sil, color='red', linestyle='--', label=f'Avg: {avg_sil:.3f}')
    ax.set_title(f'{name}', fontsize=13, fontweight='bold')
    ax.set_xlabel('Silhouette Coefficient', fontsize=11)
    ax.set_ylabel('Cluster', fontsize=11)
    ax.legend(fontsize=10)

plt.suptitle('Silhouette Analysis', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig9_silhouette_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig9_silhouette_analysis.png")

# ---- Figure 10: Feature Importance (K-Means Centers Heatmap) ----
fig, ax = plt.subplots(figsize=(16, 8))
centers_scaled = kmeans.cluster_centers_
# Use behavioral features only (columns 8 onwards)
behavioral_features = [f for f in feature_names if f[0].isdigit()]
behavioral_indices = [feature_names.index(f) for f in behavioral_features]
centers_behavioral = centers_scaled[:, behavioral_indices]

sns.heatmap(centers_behavioral, annot=True, fmt='.2f', cmap='RdYlBu_r', ax=ax,
            xticklabels=[f.split('Child')[1] if 'Child' in f else f for f in behavioral_features],
            yticklabels=['Cluster 0', 'Cluster 1', 'Cluster 2'])
ax.set_title('K-Means Cluster Centers - Behavioral Features (Standardized)', fontsize=14, fontweight='bold')
ax.set_xlabel('Features', fontsize=12)
ax.set_ylabel('Cluster', fontsize=12)
plt.xticks(rotation=45, ha='right', fontsize=9)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig10_kmeans_centers_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig10_kmeans_centers_heatmap.png")

# ---- Figure 11: Elbow Method for K-Means ----
fig, ax = plt.subplots(figsize=(10, 6))
inertias = []
sil_scores = []
K_range = range(2, 11)
for k in K_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_score(X_scaled, km.labels_))

ax.plot(K_range, inertias, 'bo-', linewidth=2, markersize=8)
ax.set_xlabel('Number of Clusters (k)', fontsize=12)
ax.set_ylabel('Inertia', fontsize=12)
ax.set_title('Elbow Method for Optimal k', fontsize=14, fontweight='bold')
ax.axvline(x=3, color='red', linestyle='--', label='k=3 (selected)')
ax.legend(fontsize=11)
ax.grid(True, alpha=0.3)

# Secondary axis for silhouette
ax2 = ax.twinx()
ax2.plot(K_range, sil_scores, 'rs-', linewidth=2, markersize=8, label='Silhouette Score')
ax2.set_ylabel('Silhouette Score', fontsize=12, color='red')
ax2.tick_params(axis='y', labelcolor='red')
ax2.legend(loc='upper right', fontsize=11)

plt.tight_layout()
plt.savefig('/home/ubuntu/fig11_elbow_method.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig11_elbow_method.png")

# ---- Figure 12: Cross-tabulation Heatmaps ----
fig, axes = plt.subplots(1, 3, figsize=(20, 5))

for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    labels = results[name]['labels']
    ct = pd.crosstab(y_true, labels, rownames=['True'], colnames=['Cluster'])
    sns.heatmap(ct, annot=True, fmt='d', cmap='YlOrRd', ax=ax,
                xticklabels=[f'Cluster {i}' for i in range(3)],
                yticklabels=['Class 0', 'Class 1', 'Class 2'])
    ax.set_title(f'{name}', fontsize=13, fontweight='bold')

plt.suptitle('Cross-Tabulation: True Labels vs Cluster Assignments', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig12_cross_tabulation.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig12_cross_tabulation.png")

print("\n" + "=" * 70)
print("ANALYSIS COMPLETE!")
print("=" * 70)
print(f"\nAll figures saved to /home/ubuntu/")
print(f"Results Excel: /home/ubuntu/clustering_results.xlsx")
print(f"Metrics Excel: /home/ubuntu/clustering_metrics.xlsx")
