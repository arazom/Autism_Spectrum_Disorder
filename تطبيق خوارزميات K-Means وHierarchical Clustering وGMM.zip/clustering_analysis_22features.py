#!/usr/bin/env python3
"""
Clustering Analysis: K-Means, Hierarchical Clustering, and GMM
Applied on 22 Selected Features (from original 33)
With comparison to the previous 33-feature results
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score, calinski_harabasz_score, davies_bouldin_score,
    adjusted_rand_score, normalized_mutual_info_score,
    confusion_matrix, accuracy_score, classification_report,
    silhouette_samples
)
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.optimize import linear_sum_assignment
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. Load and Prepare Data (22 Features)
# ============================================================
print("=" * 70)
print("1. LOADING DATA (22 FEATURES)")
print("=" * 70)

df = pd.read_excel('/home/ubuntu/upload/From_34_22_Features.xlsx')
df.columns = df.columns.str.strip().str.replace('\n', '')

print(f"Dataset shape: {df.shape}")
print(f"Number of samples: {df.shape[0]}")
print(f"Number of features: {df.shape[1] - 1}")

X = df.drop('Class', axis=1)
y_true = df['Class'].values
feature_names = X.columns.tolist()

print(f"\n22 Selected Features:")
for i, f in enumerate(feature_names, 1):
    print(f"  {i:2d}. {f}")

print(f"\nTrue class distribution:")
for cls in sorted(df['Class'].unique()):
    count = (y_true == cls).sum()
    print(f"  Class {cls}: {count} samples ({count/len(y_true)*100:.1f}%)")

# Identify removed features
all_33 = ['Gender', 'Age', 'Fam_Hist', 'No_OfChild', 'Seq_ofChild', 'Father_Emp', 
           'Mother_Emp', 'Blood_Relat', '1childName_response', '2ChildEye_contact',
           '3ChildObject_lining', '4ChildSpeech_clarity', '5ChildRequest_pointing',
           '6ChildJoint_attention', '7ChildRestriced_interests', '8ChildVocabulary_size',
           '9ChildSymbolic_play', '10ChildShared_attention', '11ChildSensory_seeking',
           '12ChildHand_prompting', '13Child_walkONtiptoe', '14ChildAdaptability_Flexibility',
           '15Child_empathy', '16Child_Repetitive_behaviors', '17ChildFirst_words',
           '18ChildEchoin_voice', '19ChildGesture_use', '20ChildFinger_move',
           '21ChildChecks_reactions', '22ChildFocused_attention', '23ChildRepetitive_manipulation',
           '24ChildNoise_sensitivity', '25ChildBlank_staring']

removed = [f for f in all_33 if f not in feature_names]
print(f"\n11 Removed Features:")
for i, f in enumerate(removed, 1):
    print(f"  {i:2d}. {f}")

# ============================================================
# 2. Standardize Features
# ============================================================
print("\n" + "=" * 70)
print("2. STANDARDIZING FEATURES")
print("=" * 70)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
print(f"Scaled data shape: {X_scaled.shape}")

pca_2d = PCA(n_components=2)
X_pca_2d = pca_2d.fit_transform(X_scaled)
print(f"PCA 2D explained variance: {pca_2d.explained_variance_ratio_}")
print(f"Total variance explained (2D): {sum(pca_2d.explained_variance_ratio_)*100:.2f}%")

# ============================================================
# 3. Helper function
# ============================================================
def map_clusters_to_labels(y_true, y_pred):
    n_classes = len(np.unique(y_true))
    n_clusters = len(np.unique(y_pred))
    cost_matrix = np.zeros((n_clusters, n_classes))
    for i in range(n_clusters):
        for j in range(n_classes):
            cost_matrix[i, j] = -np.sum((y_pred == i) & (y_true == j))
    row_ind, col_ind = linear_sum_assignment(cost_matrix)
    mapping = {r: c for r, c in zip(row_ind, col_ind)}
    y_mapped = np.array([mapping.get(label, label) for label in y_pred])
    return y_mapped, mapping

# ============================================================
# 4. Apply Clustering Algorithms
# ============================================================
print("\n" + "=" * 70)
print("3. APPLYING CLUSTERING ALGORITHMS (22 FEATURES)")
print("=" * 70)

results = {}

# --- K-Means ---
print("\n--- K-Means Clustering (k=3) ---")
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10, max_iter=300)
kmeans_labels = kmeans.fit_predict(X_scaled)
kmeans_mapped, kmeans_mapping = map_clusters_to_labels(y_true, kmeans_labels)
print(f"Cluster mapping: {kmeans_mapping}")
print(f"Inertia: {kmeans.inertia_:.2f}")
for i in range(3):
    print(f"  Cluster {i}: {(kmeans_labels == i).sum()} samples")
results['K-Means'] = {'labels': kmeans_labels, 'mapped_labels': kmeans_mapped, 'model': kmeans}

# --- Hierarchical Clustering ---
print("\n--- Hierarchical Clustering (Ward's Linkage) ---")
hierarchical = AgglomerativeClustering(n_clusters=3, linkage='ward')
hier_labels = hierarchical.fit_predict(X_scaled)
hier_mapped, hier_mapping = map_clusters_to_labels(y_true, hier_labels)
print(f"Cluster mapping: {hier_mapping}")
for i in range(3):
    print(f"  Cluster {i}: {(hier_labels == i).sum()} samples")
results['Hierarchical'] = {'labels': hier_labels, 'mapped_labels': hier_mapped, 'model': hierarchical}

# --- GMM ---
print("\n--- Gaussian Mixture Model (3 components) ---")
gmm = GaussianMixture(n_components=3, random_state=42, covariance_type='full', n_init=5)
gmm.fit(X_scaled)
gmm_labels = gmm.predict(X_scaled)
gmm_probs = gmm.predict_proba(X_scaled)
gmm_mapped, gmm_mapping = map_clusters_to_labels(y_true, gmm_labels)
print(f"Cluster mapping: {gmm_mapping}")
print(f"Converged: {gmm.converged_}")
print(f"BIC: {gmm.bic(X_scaled):.2f}")
print(f"AIC: {gmm.aic(X_scaled):.2f}")
for i in range(3):
    print(f"  Component {i}: {(gmm_labels == i).sum()} samples")
results['GMM'] = {'labels': gmm_labels, 'mapped_labels': gmm_mapped, 'model': gmm, 'probabilities': gmm_probs}

# ============================================================
# 5. Evaluation Metrics (22 Features)
# ============================================================
print("\n" + "=" * 70)
print("4. EVALUATION METRICS (22 FEATURES)")
print("=" * 70)

metrics_22 = []
algo_names = ['K-Means', 'Hierarchical', 'GMM']

for name in algo_names:
    res = results[name]
    labels = res['labels']
    mapped = res['mapped_labels']
    
    sil = silhouette_score(X_scaled, labels)
    ch = calinski_harabasz_score(X_scaled, labels)
    db = davies_bouldin_score(X_scaled, labels)
    ari = adjusted_rand_score(y_true, labels)
    nmi = normalized_mutual_info_score(y_true, labels)
    acc = accuracy_score(y_true, mapped)
    
    metrics = {
        'Algorithm': name,
        'Silhouette Score': sil,
        'Calinski-Harabasz Index': ch,
        'Davies-Bouldin Index': db,
        'Adjusted Rand Index (ARI)': ari,
        'Normalized Mutual Info (NMI)': nmi,
        'Accuracy (mapped)': acc
    }
    metrics_22.append(metrics)
    
    print(f"\n--- {name} ---")
    print(f"  Silhouette Score:          {sil:.4f}")
    print(f"  Calinski-Harabasz Index:   {ch:.4f}")
    print(f"  Davies-Bouldin Index:      {db:.4f}")
    print(f"  Adjusted Rand Index:       {ari:.4f}")
    print(f"  Normalized Mutual Info:    {nmi:.4f}")
    print(f"  Accuracy (mapped):         {acc:.4f} ({acc*100:.2f}%)")

metrics_22_df = pd.DataFrame(metrics_22)

# ============================================================
# 6. Confusion Matrices
# ============================================================
print("\n" + "=" * 70)
print("5. CONFUSION MATRICES (22 Features)")
print("=" * 70)

for name in algo_names:
    mapped = results[name]['mapped_labels']
    cm = confusion_matrix(y_true, mapped)
    print(f"\n--- {name} ---")
    print(cm)
    print(classification_report(y_true, mapped, 
          target_names=['Class 0 (Mild)', 'Class 1 (Moderate)', 'Class 2 (Severe)']))

# ============================================================
# 7. COMPARISON: 33 Features vs 22 Features
# ============================================================
print("\n" + "=" * 70)
print("6. COMPARISON: 33 FEATURES vs 22 FEATURES")
print("=" * 70)

# Previous results (33 features) - from earlier analysis
metrics_33 = pd.DataFrame([
    {'Algorithm': 'K-Means', 'Silhouette Score': 0.056810, 'Calinski-Harabasz Index': 20.004728,
     'Davies-Bouldin Index': 3.445714, 'Adjusted Rand Index (ARI)': 0.085324,
     'Normalized Mutual Info (NMI)': 0.086516, 'Accuracy (mapped)': 0.455882},
    {'Algorithm': 'Hierarchical', 'Silhouette Score': 0.044055, 'Calinski-Harabasz Index': 15.885165,
     'Davies-Bouldin Index': 3.934337, 'Adjusted Rand Index (ARI)': 0.118723,
     'Normalized Mutual Info (NMI)': 0.116748, 'Accuracy (mapped)': 0.470588},
    {'Algorithm': 'GMM', 'Silhouette Score': 0.055601, 'Calinski-Harabasz Index': 19.786090,
     'Davies-Bouldin Index': 3.474587, 'Adjusted Rand Index (ARI)': 0.102057,
     'Normalized Mutual Info (NMI)': 0.102877, 'Accuracy (mapped)': 0.464706}
])

print("\n--- 33 Features Results ---")
print(metrics_33.to_string(index=False))
print("\n--- 22 Features Results ---")
print(metrics_22_df.to_string(index=False))

# Compute differences
print("\n--- DIFFERENCE (22 Features - 33 Features) ---")
print("Positive = improvement for Silhouette, CH, ARI, NMI, Accuracy")
print("Negative = improvement for Davies-Bouldin")

for algo in algo_names:
    m33 = metrics_33[metrics_33['Algorithm'] == algo].iloc[0]
    m22 = metrics_22_df[metrics_22_df['Algorithm'] == algo].iloc[0]
    
    print(f"\n  {algo}:")
    for metric in ['Silhouette Score', 'Calinski-Harabasz Index', 'Davies-Bouldin Index',
                    'Adjusted Rand Index (ARI)', 'Normalized Mutual Info (NMI)', 'Accuracy (mapped)']:
        diff = m22[metric] - m33[metric]
        pct = (diff / abs(m33[metric])) * 100 if m33[metric] != 0 else 0
        direction = "↑" if diff > 0 else "↓" if diff < 0 else "="
        
        # Determine if change is good or bad
        if metric == 'Davies-Bouldin Index':
            quality = "better" if diff < 0 else "worse" if diff > 0 else "same"
        else:
            quality = "better" if diff > 0 else "worse" if diff < 0 else "same"
        
        print(f"    {metric:35s}: {m33[metric]:.4f} → {m22[metric]:.4f} ({direction} {abs(diff):.4f}, {pct:+.1f}%) [{quality}]")

# ============================================================
# 8. Save Results
# ============================================================
print("\n" + "=" * 70)
print("7. SAVING RESULTS")
print("=" * 70)

df_results = df.copy()
df_results['KMeans_Cluster'] = kmeans_labels
df_results['KMeans_Mapped'] = kmeans_mapped
df_results['Hierarchical_Cluster'] = hier_labels
df_results['Hierarchical_Mapped'] = hier_mapped
df_results['GMM_Cluster'] = gmm_labels
df_results['GMM_Mapped'] = gmm_mapped
for i in range(3):
    df_results[f'GMM_Prob_Cluster{i}'] = gmm_probs[:, i]

df_results.to_excel('/home/ubuntu/clustering_results_22features.xlsx', index=False)
metrics_22_df.to_excel('/home/ubuntu/clustering_metrics_22features.xlsx', index=False)

# Save comparison table
comparison_rows = []
for algo in algo_names:
    m33 = metrics_33[metrics_33['Algorithm'] == algo].iloc[0]
    m22 = metrics_22_df[metrics_22_df['Algorithm'] == algo].iloc[0]
    for metric in ['Silhouette Score', 'Calinski-Harabasz Index', 'Davies-Bouldin Index',
                    'Adjusted Rand Index (ARI)', 'Normalized Mutual Info (NMI)', 'Accuracy (mapped)']:
        diff = m22[metric] - m33[metric]
        pct = (diff / abs(m33[metric])) * 100 if m33[metric] != 0 else 0
        comparison_rows.append({
            'Algorithm': algo,
            'Metric': metric,
            '33 Features': m33[metric],
            '22 Features': m22[metric],
            'Difference': diff,
            'Change (%)': pct
        })

comparison_df = pd.DataFrame(comparison_rows)
comparison_df.to_excel('/home/ubuntu/comparison_33vs22.xlsx', index=False)
print("Saved: clustering_results_22features.xlsx")
print("Saved: clustering_metrics_22features.xlsx")
print("Saved: comparison_33vs22.xlsx")

# ============================================================
# 9. VISUALIZATIONS
# ============================================================
print("\n" + "=" * 70)
print("8. GENERATING VISUALIZATIONS")
print("=" * 70)

plt.style.use('seaborn-v0_8-whitegrid')
colors = ['#2196F3', '#FF9800', '#4CAF50']
severity_labels = ['Mild (0)', 'Moderate (1)', 'Severe (2)']

# ---- Figure 1: True Labels PCA (22 Features) ----
fig, ax = plt.subplots(figsize=(10, 8))
for i, label in enumerate(severity_labels):
    mask = y_true == i
    ax.scatter(X_pca_2d[mask, 0], X_pca_2d[mask, 1], c=colors[i],
               label=label, alpha=0.6, s=50, edgecolors='white', linewidth=0.5)
ax.set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0]*100:.1f}%)', fontsize=12)
ax.set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1]*100:.1f}%)', fontsize=12)
ax.set_title('True Labels - PCA Visualization (22 Features)', fontsize=14, fontweight='bold')
ax.legend(title='Severity Level', fontsize=11)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_1_true_labels_pca.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_1_true_labels_pca.png")

# ---- Figure 2: All Clustering Results Side by Side ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    labels = results[name]['labels']
    for i in range(3):
        mask = labels == i
        ax.scatter(X_pca_2d[mask, 0], X_pca_2d[mask, 1], c=colors[i],
                   label=f'Cluster {i}', alpha=0.6, s=40, edgecolors='white', linewidth=0.5)
    ax.set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0]*100:.1f}%)', fontsize=11)
    ax.set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1]*100:.1f}%)', fontsize=11)
    ax.set_title(f'{name} Clustering', fontsize=13, fontweight='bold')
    ax.legend(fontsize=9)
plt.suptitle('Clustering Results Comparison - 22 Features (PCA 2D)', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_2_clustering_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_2_clustering_comparison.png")

# ---- Figure 3: Correct vs Misclassified ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    mapped = results[name]['mapped_labels']
    correct = mapped == y_true
    ax.scatter(X_pca_2d[correct, 0], X_pca_2d[correct, 1], c='#4CAF50',
               label='Correct', alpha=0.5, s=40, edgecolors='white', linewidth=0.5)
    ax.scatter(X_pca_2d[~correct, 0], X_pca_2d[~correct, 1], c='#F44336',
               label='Misclassified', alpha=0.7, s=40, edgecolors='white', linewidth=0.5, marker='x')
    acc = accuracy_score(y_true, mapped)
    ax.set_xlabel('PC1', fontsize=11)
    ax.set_ylabel('PC2', fontsize=11)
    ax.set_title(f'{name} (Accuracy: {acc*100:.1f}%)', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
plt.suptitle('Correct vs Misclassified - 22 Features', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_3_correct_vs_misclassified.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_3_correct_vs_misclassified.png")

# ---- Figure 4: Confusion Matrices ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
class_labels = ['Class 0\n(Mild)', 'Class 1\n(Moderate)', 'Class 2\n(Severe)']
for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    mapped = results[name]['mapped_labels']
    cm = confusion_matrix(y_true, mapped)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=class_labels, yticklabels=class_labels,
                cbar_kws={'shrink': 0.8})
    acc = accuracy_score(y_true, mapped)
    ax.set_xlabel('Predicted', fontsize=11)
    ax.set_ylabel('True', fontsize=11)
    ax.set_title(f'{name}\nAccuracy: {acc*100:.1f}%', fontsize=13, fontweight='bold')
plt.suptitle('Confusion Matrices - 22 Features', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_4_confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_4_confusion_matrices.png")

# ---- Figure 5: Metrics Comparison (22 Features only) ----
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
metric_names = ['Silhouette Score', 'Calinski-Harabasz Index', 'Davies-Bouldin Index',
                'Adjusted Rand Index (ARI)', 'Normalized Mutual Info (NMI)', 'Accuracy (mapped)']
bar_colors = ['#2196F3', '#FF9800', '#4CAF50']
for idx, (metric, ax) in enumerate(zip(metric_names, axes.flat)):
    values = [metrics_22_df[metrics_22_df['Algorithm'] == algo][metric].values[0] for algo in algo_names]
    bars = ax.bar(algo_names, values, color=bar_colors, edgecolor='white', linewidth=1.5, width=0.5)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.01 * max(values),
                f'{val:.4f}', ha='center', va='bottom', fontsize=10, fontweight='bold')
    ax.set_title(metric, fontsize=12, fontweight='bold')
    ax.set_ylabel('Score', fontsize=10)
    ax.grid(axis='y', alpha=0.3)
plt.suptitle('Clustering Evaluation Metrics - 22 Features', fontsize=15, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_5_metrics_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_5_metrics_comparison.png")

# ---- Figure 6: Dendrogram ----
fig, ax = plt.subplots(figsize=(16, 8))
Z = linkage(X_scaled, method='ward')
dendrogram(Z, ax=ax, truncate_mode='lastp', p=30, leaf_rotation=90,
           leaf_font_size=8, color_threshold=0.7 * max(Z[:, 2]))
ax.set_title("Hierarchical Clustering Dendrogram - 22 Features (Ward's Linkage)", fontsize=14, fontweight='bold')
ax.set_xlabel('Sample Index (or cluster size)', fontsize=12)
ax.set_ylabel('Distance', fontsize=12)
ax.axhline(y=0.7 * max(Z[:, 2]), color='r', linestyle='--', label='Cut threshold')
ax.legend(fontsize=11)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_6_dendrogram.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_6_dendrogram.png")

# ---- Figure 7: Silhouette Analysis ----
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    labels = results[name]['labels']
    sil_vals = silhouette_samples(X_scaled, labels)
    y_lower = 10
    for i in range(3):
        cluster_sil = sil_vals[labels == i]
        cluster_sil.sort()
        size = cluster_sil.shape[0]
        y_upper = y_lower + size
        ax.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                         facecolor=colors[i], edgecolor=colors[i], alpha=0.7)
        ax.text(-0.05, y_lower + 0.5 * size, str(i), fontsize=10, fontweight='bold')
        y_lower = y_upper + 10
    avg_sil = silhouette_score(X_scaled, labels)
    ax.axvline(x=avg_sil, color='red', linestyle='--', label=f'Avg: {avg_sil:.3f}')
    ax.set_title(f'{name}', fontsize=13, fontweight='bold')
    ax.set_xlabel('Silhouette Coefficient', fontsize=11)
    ax.set_ylabel('Cluster', fontsize=11)
    ax.legend(fontsize=10)
plt.suptitle('Silhouette Analysis - 22 Features', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_7_silhouette_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_7_silhouette_analysis.png")

# ============================================================
# KEY COMPARISON FIGURE: 33 vs 22 Features
# ============================================================

# ---- Figure 8: Side-by-side Accuracy Comparison ----
fig, axes = plt.subplots(2, 3, figsize=(20, 12))

# Row 1: Accuracy, ARI, NMI comparison bars
comparison_metrics = ['Accuracy (mapped)', 'Adjusted Rand Index (ARI)', 'Normalized Mutual Info (NMI)']
for idx, metric in enumerate(comparison_metrics):
    ax = axes[0, idx]
    vals_33 = [metrics_33[metrics_33['Algorithm'] == a][metric].values[0] for a in algo_names]
    vals_22 = [metrics_22_df[metrics_22_df['Algorithm'] == a][metric].values[0] for a in algo_names]
    
    x = np.arange(len(algo_names))
    width = 0.3
    bars1 = ax.bar(x - width/2, vals_33, width, label='33 Features', color='#E57373', edgecolor='white')
    bars2 = ax.bar(x + width/2, vals_22, width, label='22 Features', color='#4CAF50', edgecolor='white')
    
    for bar, val in zip(bars1, vals_33):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.002,
                f'{val:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold', color='#C62828')
    for bar, val in zip(bars2, vals_22):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.002,
                f'{val:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold', color='#2E7D32')
    
    ax.set_xticks(x)
    ax.set_xticklabels(algo_names, fontsize=11)
    ax.set_title(metric, fontsize=13, fontweight='bold')
    ax.set_ylabel('Score', fontsize=11)
    ax.legend(fontsize=10)
    ax.grid(axis='y', alpha=0.3)

# Row 2: Silhouette, CH, DB comparison
comparison_metrics2 = ['Silhouette Score', 'Calinski-Harabasz Index', 'Davies-Bouldin Index']
for idx, metric in enumerate(comparison_metrics2):
    ax = axes[1, idx]
    vals_33 = [metrics_33[metrics_33['Algorithm'] == a][metric].values[0] for a in algo_names]
    vals_22 = [metrics_22_df[metrics_22_df['Algorithm'] == a][metric].values[0] for a in algo_names]
    
    x = np.arange(len(algo_names))
    width = 0.3
    bars1 = ax.bar(x - width/2, vals_33, width, label='33 Features', color='#E57373', edgecolor='white')
    bars2 = ax.bar(x + width/2, vals_22, width, label='22 Features', color='#4CAF50', edgecolor='white')
    
    for bar, val in zip(bars1, vals_33):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.002,
                f'{val:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold', color='#C62828')
    for bar, val in zip(bars2, vals_22):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.002,
                f'{val:.4f}', ha='center', va='bottom', fontsize=9, fontweight='bold', color='#2E7D32')
    
    ax.set_xticks(x)
    ax.set_xticklabels(algo_names, fontsize=11)
    ax.set_title(metric, fontsize=13, fontweight='bold')
    ax.set_ylabel('Score', fontsize=11)
    ax.legend(fontsize=10)
    ax.grid(axis='y', alpha=0.3)

plt.suptitle('Comparison: 33 Features vs 22 Features', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_8_comparison_33vs22.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_8_comparison_33vs22.png")

# ---- Figure 9: Accuracy Change Arrow Chart ----
fig, ax = plt.subplots(figsize=(12, 7))
metrics_to_plot = ['Accuracy (mapped)', 'Adjusted Rand Index (ARI)', 'Normalized Mutual Info (NMI)',
                   'Silhouette Score']
y_positions = np.arange(len(metrics_to_plot))
bar_height = 0.2

for algo_idx, algo in enumerate(algo_names):
    for m_idx, metric in enumerate(metrics_to_plot):
        v33 = metrics_33[metrics_33['Algorithm'] == algo][metric].values[0]
        v22 = metrics_22_df[metrics_22_df['Algorithm'] == algo][metric].values[0]
        diff = v22 - v33
        y = m_idx + (algo_idx - 1) * bar_height
        color = '#4CAF50' if diff > 0 else '#F44336'
        ax.barh(y, diff, height=bar_height * 0.8, color=color, edgecolor='white',
                label=algo if m_idx == 0 else None, alpha=0.8)
        ax.text(diff + (0.001 if diff >= 0 else -0.001), y,
                f'{diff:+.4f}', va='center', ha='left' if diff >= 0 else 'right',
                fontsize=9, fontweight='bold')

ax.set_yticks(y_positions)
ax.set_yticklabels(metrics_to_plot, fontsize=11)
ax.axvline(x=0, color='black', linewidth=1)
ax.set_xlabel('Change (22 Features - 33 Features)', fontsize=12)
ax.set_title('Impact of Feature Reduction on Clustering Performance', fontsize=14, fontweight='bold')

# Custom legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor=bar_colors[i], label=algo_names[i]) for i in range(3)]
legend_elements.extend([Patch(facecolor='#4CAF50', label='Improvement'),
                        Patch(facecolor='#F44336', label='Degradation')])
ax.legend(handles=legend_elements, fontsize=10, loc='lower right')
ax.grid(axis='x', alpha=0.3)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_9_impact_feature_reduction.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_9_impact_feature_reduction.png")

# ---- Figure 10: Cross-tabulation ----
fig, axes = plt.subplots(1, 3, figsize=(20, 5))
for idx, (name, ax) in enumerate(zip(algo_names, axes)):
    labels = results[name]['labels']
    ct = pd.crosstab(y_true, labels, rownames=['True'], colnames=['Cluster'])
    sns.heatmap(ct, annot=True, fmt='d', cmap='YlOrRd', ax=ax,
                xticklabels=[f'Cluster {i}' for i in range(3)],
                yticklabels=['Class 0', 'Class 1', 'Class 2'])
    ax.set_title(f'{name}', fontsize=13, fontweight='bold')
plt.suptitle('Cross-Tabulation - 22 Features', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_10_cross_tabulation.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_10_cross_tabulation.png")

# ---- Figure 11: K-Means Centers Heatmap ----
fig, ax = plt.subplots(figsize=(16, 6))
centers_scaled = kmeans.cluster_centers_
sns.heatmap(centers_scaled, annot=True, fmt='.2f', cmap='RdYlBu_r', ax=ax,
            xticklabels=feature_names, yticklabels=['Cluster 0', 'Cluster 1', 'Cluster 2'])
ax.set_title('K-Means Cluster Centers - 22 Features (Standardized)', fontsize=14, fontweight='bold')
ax.set_xlabel('Features', fontsize=12)
ax.set_ylabel('Cluster', fontsize=12)
plt.xticks(rotation=45, ha='right', fontsize=8)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_11_kmeans_centers_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_11_kmeans_centers_heatmap.png")

# ---- Figure 12: GMM Probabilities ----
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for i in range(3):
    axes[i].hist(gmm_probs[:, i], bins=30, color=colors[i], edgecolor='white', alpha=0.8)
    axes[i].set_title(f'Component {i} Probability', fontsize=13, fontweight='bold')
    axes[i].set_xlabel('Probability', fontsize=11)
    axes[i].set_ylabel('Frequency', fontsize=11)
    axes[i].axvline(x=0.5, color='red', linestyle='--', alpha=0.7, label='p=0.5')
    axes[i].legend()
plt.suptitle('GMM Posterior Probability - 22 Features', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_12_gmm_probabilities.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_12_gmm_probabilities.png")

# ---- Figure 13: Cluster Size Comparison ----
fig, axes = plt.subplots(1, 4, figsize=(20, 5))
true_counts = [np.sum(y_true == i) for i in range(3)]
axes[0].bar(severity_labels, true_counts, color=colors, edgecolor='white', linewidth=1.5)
axes[0].set_title('True Labels', fontsize=13, fontweight='bold')
axes[0].set_ylabel('Count', fontsize=11)
for i, v in enumerate(true_counts):
    axes[0].text(i, v + 2, str(v), ha='center', fontweight='bold')

for idx, name in enumerate(algo_names):
    labels = results[name]['labels']
    counts = [np.sum(labels == i) for i in range(3)]
    axes[idx+1].bar([f'Cluster {i}' for i in range(3)], counts, color=colors, edgecolor='white', linewidth=1.5)
    axes[idx+1].set_title(f'{name}', fontsize=13, fontweight='bold')
    axes[idx+1].set_ylabel('Count', fontsize=11)
    for i, v in enumerate(counts):
        axes[idx+1].text(i, v + 2, str(v), ha='center', fontweight='bold')
plt.suptitle('Cluster Size Distribution - 22 Features', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/home/ubuntu/fig22_13_cluster_sizes.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: fig22_13_cluster_sizes.png")

print("\n" + "=" * 70)
print("ANALYSIS COMPLETE!")
print("=" * 70)
