"""
Autism Spectrum Disorder (ASD) Classification - Complete Pipeline
================================================================
Three-level classification using SVM, Random Forest, and XGBoost
Before and After Optimization Techniques
"""

import pandas as pd
import numpy as np
import warnings
import json
import os
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             classification_report, confusion_matrix, roc_auc_score)
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression, Lasso
from sklearn.feature_selection import RFE
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['figure.dpi'] = 150
plt.rcParams['savefig.dpi'] = 150
plt.rcParams['figure.figsize'] = (12, 8)

RESULTS_DIR = '/home/ubuntu/results'
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# PHASE 1: DATA LOADING AND PREPROCESSING
# ============================================================
print("="*70)
print("PHASE 1: DATA LOADING AND PREPROCESSING")
print("="*70)

df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

# Clean column names (remove whitespace and newlines)
df.columns = df.columns.str.strip().str.replace('\n', '')

print(f"Dataset shape: {df.shape}")
print(f"Target variable 'Class' distribution:")
print(df['Class'].value_counts().sort_index())

# Separate features and target
X = df.drop('Class', axis=1)
y = df['Class']

# Check for missing values
print(f"\nMissing values: {X.isnull().sum().sum()}")

# Handle missing values if any
if X.isnull().sum().sum() > 0:
    X = X.fillna(X.median())

print(f"Features: {X.shape[1]}")
print(f"Samples: {X.shape[0]}")
print(f"Classes: {sorted(y.unique())}")
print(f"Class distribution:\n  Class 0: {(y==0).sum()} ({(y==0).mean()*100:.1f}%)")
print(f"  Class 1: {(y==1).sum()} ({(y==1).mean()*100:.1f}%)")
print(f"  Class 2: {(y==2).sum()} ({(y==2).mean()*100:.1f}%)")

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\nTrain set: {X_train.shape[0]} samples")
print(f"Test set: {X_test.shape[0]} samples")

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert back to DataFrame for feature names
X_train_scaled_df = pd.DataFrame(X_train_scaled, columns=X.columns, index=X_train.index)
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=X.columns, index=X_test.index)

# ============================================================
# PHASE 2: BASELINE MODELS (Before Optimization)
# ============================================================
print("\n" + "="*70)
print("PHASE 2: BASELINE MODELS (Before Optimization)")
print("="*70)

def evaluate_model(model, X_train, X_test, y_train, y_test, model_name, cv=10):
    """Comprehensive model evaluation"""
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    # Cross-validation
    cv_scores = cross_val_score(model, X_train, y_train, cv=StratifiedKFold(n_splits=cv, shuffle=True, random_state=42), scoring='accuracy')
    
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    rec = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
    
    # Per-class metrics
    prec_per = precision_score(y_test, y_pred, average=None, zero_division=0)
    rec_per = recall_score(y_test, y_pred, average=None, zero_division=0)
    f1_per = f1_score(y_test, y_pred, average=None, zero_division=0)
    
    results = {
        'model_name': model_name,
        'accuracy': acc,
        'precision_weighted': prec,
        'recall_weighted': rec,
        'f1_weighted': f1,
        'cv_mean': cv_scores.mean(),
        'cv_std': cv_scores.std(),
        'y_pred': y_pred,
        'confusion_matrix': confusion_matrix(y_test, y_pred),
        'classification_report': classification_report(y_test, y_pred, zero_division=0),
        'precision_per_class': prec_per,
        'recall_per_class': rec_per,
        'f1_per_class': f1_per,
        'cv_scores': cv_scores
    }
    
    print(f"\n--- {model_name} ---")
    print(f"Accuracy: {acc:.4f}")
    print(f"Precision (weighted): {prec:.4f}")
    print(f"Recall (weighted): {rec:.4f}")
    print(f"F1-Score (weighted): {f1:.4f}")
    print(f"CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
    print(f"\nClassification Report:\n{results['classification_report']}")
    print(f"Confusion Matrix:\n{results['confusion_matrix']}")
    
    return results

# Baseline SVM
svm_base = SVC(kernel='rbf', random_state=42)
svm_base_results = evaluate_model(svm_base, X_train_scaled, X_test_scaled, y_train, y_test, "SVM (Baseline)")

# Baseline Random Forest
rf_base = RandomForestClassifier(n_estimators=100, random_state=42)
rf_base_results = evaluate_model(rf_base, X_train_scaled, X_test_scaled, y_train, y_test, "Random Forest (Baseline)")

# Baseline XGBoost
xgb_base = XGBClassifier(n_estimators=100, random_state=42, eval_metric='mlogloss', use_label_encoder=False)
xgb_base_results = evaluate_model(xgb_base, X_train_scaled, X_test_scaled, y_train, y_test, "XGBoost (Baseline)")

baseline_results = {
    'SVM': svm_base_results,
    'Random Forest': rf_base_results,
    'XGBoost': xgb_base_results
}

# ============================================================
# PHASE 3: HYBRID FEATURE SELECTION (LASSO → RF → RFE)
# ============================================================
print("\n" + "="*70)
print("PHASE 3: HYBRID FEATURE SELECTION STRATEGY")
print("LASSO → Random Forest Importance → RFE")
print("="*70)

# --- Stage 1: LASSO Initial Screening ---
print("\n--- Stage 1: LASSO Initial Screening ---")
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier

# Use Logistic Regression with L1 penalty (LASSO equivalent for classification)
lasso_model = LogisticRegression(penalty='l1', solver='saga', C=0.5, max_iter=10000, random_state=42)
lasso_model.fit(X_train_scaled, y_train)

# Get feature importance from LASSO coefficients
lasso_importance = np.mean(np.abs(lasso_model.coef_), axis=0)
lasso_features_mask = lasso_importance > 0

lasso_selected_features = X.columns[lasso_features_mask].tolist()
print(f"LASSO selected {len(lasso_selected_features)} features out of {X.shape[1]}")
print(f"Selected features: {lasso_selected_features}")

# If LASSO selects too few features, relax the threshold
if len(lasso_selected_features) < 10:
    threshold = np.percentile(lasso_importance[lasso_importance > 0], 10) if np.sum(lasso_importance > 0) > 0 else 0
    lasso_features_mask = lasso_importance >= threshold
    lasso_selected_features = X.columns[lasso_features_mask].tolist()
    print(f"Relaxed LASSO: selected {len(lasso_selected_features)} features")

X_train_lasso = X_train_scaled_df[lasso_selected_features]
X_test_lasso = X_test_scaled_df[lasso_selected_features]

# --- Stage 2: Random Forest Importance Ranking ---
print("\n--- Stage 2: Random Forest Importance Ranking ---")
rf_selector = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
rf_selector.fit(X_train_lasso, y_train)

rf_importances = pd.Series(rf_selector.feature_importances_, index=lasso_selected_features)
rf_importances_sorted = rf_importances.sort_values(ascending=False)

print("\nFeature Importance Ranking (from RF):")
for feat, imp in rf_importances_sorted.items():
    print(f"  {feat}: {imp:.4f}")

# Select top features (up to 30 or available)
n_top = min(30, len(lasso_selected_features))
top_rf_features = rf_importances_sorted.head(n_top).index.tolist()
print(f"\nTop {n_top} features selected for RFE stage")

X_train_rf = X_train_scaled_df[top_rf_features]
X_test_rf = X_test_scaled_df[top_rf_features]

# --- Stage 3: RFE with XGBoost ---
print("\n--- Stage 3: RFE Refinement with XGBoost ---")
xgb_for_rfe = XGBClassifier(n_estimators=100, random_state=42, eval_metric='mlogloss', use_label_encoder=False)

# Try different numbers of features to find optimal
best_score = 0
best_n_features = n_top
cv_rfe = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)

rfe_results_list = []
for n_feat in range(max(3, n_top//3), n_top+1):
    rfe = RFE(estimator=XGBClassifier(n_estimators=100, random_state=42, eval_metric='mlogloss', use_label_encoder=False),
              n_features_to_select=n_feat, step=1)
    rfe.fit(X_train_rf, y_train)
    
    X_train_rfe_temp = X_train_rf.loc[:, rfe.support_]
    scores = cross_val_score(XGBClassifier(n_estimators=100, random_state=42, eval_metric='mlogloss', use_label_encoder=False),
                            X_train_rfe_temp, y_train, cv=cv_rfe, scoring='accuracy')
    mean_score = scores.mean()
    rfe_results_list.append({'n_features': n_feat, 'cv_accuracy': mean_score, 'cv_std': scores.std()})
    
    if mean_score > best_score:
        best_score = mean_score
        best_n_features = n_feat
        best_rfe = rfe

print(f"\nBest number of features: {best_n_features} (CV Accuracy: {best_score:.4f})")

# Get final selected features
final_selected_features = X_train_rf.columns[best_rfe.support_].tolist()
print(f"\nFinal Selected Features ({len(final_selected_features)}):")
for i, feat in enumerate(final_selected_features, 1):
    print(f"  {i}. {feat}")

# Prepare optimized feature sets
X_train_optimized = X_train_scaled_df[final_selected_features]
X_test_optimized = X_test_scaled_df[final_selected_features]

# Plot RFE results
rfe_df = pd.DataFrame(rfe_results_list)
fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(rfe_df['n_features'], rfe_df['cv_accuracy'], 'b-o', markersize=4)
ax.fill_between(rfe_df['n_features'], 
                rfe_df['cv_accuracy'] - rfe_df['cv_std'],
                rfe_df['cv_accuracy'] + rfe_df['cv_std'], alpha=0.2)
ax.axvline(x=best_n_features, color='r', linestyle='--', label=f'Best: {best_n_features} features')
ax.set_xlabel('Number of Features', fontsize=12)
ax.set_ylabel('CV Accuracy', fontsize=12)
ax.set_title('RFE: Cross-Validation Accuracy vs Number of Features', fontsize=14)
ax.legend(fontsize=11)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/rfe_feature_selection.png', bbox_inches='tight')
plt.close()

# Plot Feature Importance
fig, ax = plt.subplots(figsize=(12, max(6, len(final_selected_features)*0.4)))
rf_importances_final = rf_importances[final_selected_features].sort_values(ascending=True)
colors = plt.cm.viridis(np.linspace(0.3, 0.9, len(rf_importances_final)))
ax.barh(range(len(rf_importances_final)), rf_importances_final.values, color=colors)
ax.set_yticks(range(len(rf_importances_final)))
ax.set_yticklabels(rf_importances_final.index, fontsize=10)
ax.set_xlabel('Feature Importance (Random Forest)', fontsize=12)
ax.set_title('Selected Features Importance (Hybrid Strategy)', fontsize=14)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/feature_importance.png', bbox_inches='tight')
plt.close()

# ============================================================
# PHASE 4: SMOTE + GRID SEARCH WITH 10-FOLD CV
# ============================================================
print("\n" + "="*70)
print("PHASE 4: SMOTE + GRID SEARCH WITH 10-FOLD CV")
print("="*70)

# Apply SMOTE to training data
print("\n--- Applying SMOTE ---")
smote = SMOTE(random_state=42, k_neighbors=5)
X_train_smote, y_train_smote = smote.fit_resample(X_train_optimized, y_train)

print(f"Before SMOTE: {dict(pd.Series(y_train).value_counts().sort_index())}")
print(f"After SMOTE:  {dict(pd.Series(y_train_smote).value_counts().sort_index())}")

# --- Grid Search for SVM ---
print("\n--- Grid Search: SVM ---")
svm_param_grid = {
    'C': [0.1, 1, 10, 100],
    'gamma': ['scale', 'auto', 0.01, 0.1],
    'kernel': ['rbf', 'poly', 'linear']
}

svm_grid = GridSearchCV(
    SVC(random_state=42, probability=True),
    svm_param_grid,
    cv=StratifiedKFold(n_splits=10, shuffle=True, random_state=42),
    scoring='accuracy',
    n_jobs=-1,
    verbose=0
)
svm_grid.fit(X_train_smote, y_train_smote)
print(f"Best SVM params: {svm_grid.best_params_}")
print(f"Best SVM CV accuracy: {svm_grid.best_score_:.4f}")

# --- Grid Search for Random Forest ---
print("\n--- Grid Search: Random Forest ---")
rf_param_grid = {
    'n_estimators': [100, 200, 500],
    'max_depth': [5, 10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

rf_grid = GridSearchCV(
    RandomForestClassifier(random_state=42),
    rf_param_grid,
    cv=StratifiedKFold(n_splits=10, shuffle=True, random_state=42),
    scoring='accuracy',
    n_jobs=-1,
    verbose=0
)
rf_grid.fit(X_train_smote, y_train_smote)
print(f"Best RF params: {rf_grid.best_params_}")
print(f"Best RF CV accuracy: {rf_grid.best_score_:.4f}")

# --- Grid Search for XGBoost ---
print("\n--- Grid Search: XGBoost ---")
xgb_param_grid = {
    'n_estimators': [100, 200, 500],
    'max_depth': [3, 5, 7, 10],
    'learning_rate': [0.01, 0.05, 0.1, 0.2],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.8, 1.0]
}

xgb_grid = GridSearchCV(
    XGBClassifier(random_state=42, eval_metric='mlogloss', use_label_encoder=False),
    xgb_param_grid,
    cv=StratifiedKFold(n_splits=10, shuffle=True, random_state=42),
    scoring='accuracy',
    n_jobs=-1,
    verbose=0
)
xgb_grid.fit(X_train_smote, y_train_smote)
print(f"Best XGBoost params: {xgb_grid.best_params_}")
print(f"Best XGBoost CV accuracy: {xgb_grid.best_score_:.4f}")

# Evaluate optimized models on test set
print("\n--- Evaluating Optimized Models on Test Set ---")
X_test_final = X_test_optimized

svm_opt_results = evaluate_model(svm_grid.best_estimator_, X_train_smote, X_test_final, y_train_smote, y_test, "SVM (Optimized)")
rf_opt_results = evaluate_model(rf_grid.best_estimator_, X_train_smote, X_test_final, y_train_smote, y_test, "Random Forest (Optimized)")
xgb_opt_results = evaluate_model(xgb_grid.best_estimator_, X_train_smote, X_test_final, y_train_smote, y_test, "XGBoost (Optimized)")

optimized_results = {
    'SVM': svm_opt_results,
    'Random Forest': rf_opt_results,
    'XGBoost': xgb_opt_results
}

# ============================================================
# PHASE 5: WEIGHTED VOTING ENSEMBLE
# ============================================================
print("\n" + "="*70)
print("PHASE 5: WEIGHTED VOTING ENSEMBLE")
print("="*70)

# Calculate weights based on individual model performance (F1 scores)
svm_weight = svm_opt_results['f1_weighted']
rf_weight = rf_opt_results['f1_weighted']
xgb_weight = xgb_opt_results['f1_weighted']

total_weight = svm_weight + rf_weight + xgb_weight
svm_w = svm_weight / total_weight
rf_w = rf_weight / total_weight
xgb_w = xgb_weight / total_weight

print(f"\nEnsemble Weights (based on F1-scores):")
print(f"  SVM: {svm_w:.4f} (F1: {svm_weight:.4f})")
print(f"  RF:  {rf_w:.4f} (F1: {rf_weight:.4f})")
print(f"  XGB: {xgb_w:.4f} (F1: {xgb_weight:.4f})")

# Create weighted voting ensemble
ensemble_model = VotingClassifier(
    estimators=[
        ('svm', svm_grid.best_estimator_),
        ('rf', rf_grid.best_estimator_),
        ('xgb', xgb_grid.best_estimator_)
    ],
    voting='soft',
    weights=[svm_w, rf_w, xgb_w]
)

ensemble_results = evaluate_model(ensemble_model, X_train_smote, X_test_final, y_train_smote, y_test, "Weighted Voting Ensemble")

# ============================================================
# PHASE 6: COMPREHENSIVE RESULTS AND VISUALIZATIONS
# ============================================================
print("\n" + "="*70)
print("PHASE 6: COMPREHENSIVE RESULTS COMPARISON")
print("="*70)

# Create comparison table
comparison_data = []
for name in ['SVM', 'Random Forest', 'XGBoost']:
    base = baseline_results[name]
    opt = optimized_results[name]
    comparison_data.append({
        'Model': f"{name} (Before)",
        'Accuracy': base['accuracy'],
        'Precision': base['precision_weighted'],
        'Recall': base['recall_weighted'],
        'F1-Score': base['f1_weighted'],
        'CV Mean': base['cv_mean'],
        'CV Std': base['cv_std']
    })
    comparison_data.append({
        'Model': f"{name} (After)",
        'Accuracy': opt['accuracy'],
        'Precision': opt['precision_weighted'],
        'Recall': opt['recall_weighted'],
        'F1-Score': opt['f1_weighted'],
        'CV Mean': opt['cv_mean'],
        'CV Std': opt['cv_std']
    })

comparison_data.append({
    'Model': 'Weighted Ensemble',
    'Accuracy': ensemble_results['accuracy'],
    'Precision': ensemble_results['precision_weighted'],
    'Recall': ensemble_results['recall_weighted'],
    'F1-Score': ensemble_results['f1_weighted'],
    'CV Mean': ensemble_results['cv_mean'],
    'CV Std': ensemble_results['cv_std']
})

comparison_df = pd.DataFrame(comparison_data)
print("\n" + comparison_df.to_string(index=False, float_format='%.4f'))

# Save comparison table
comparison_df.to_csv(f'{RESULTS_DIR}/comparison_results.csv', index=False)

# ============================================================
# VISUALIZATIONS
# ============================================================
print("\n--- Generating Visualizations ---")

# 1. Before vs After Comparison Bar Chart
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
models = ['SVM', 'Random Forest', 'XGBoost']

for idx, metric in enumerate(metrics):
    ax = axes[idx//2][idx%2]
    before_vals = [baseline_results[m][metric.lower().replace('-', '_').replace('score', 'weighted').replace('accuracy', 'accuracy').replace('precision', 'precision_weighted').replace('recall', 'recall_weighted').replace('f1_weighted', 'f1_weighted')] for m in models]
    
    # Get values properly
    before_vals = []
    after_vals = []
    for m in models:
        if metric == 'Accuracy':
            before_vals.append(baseline_results[m]['accuracy'])
            after_vals.append(optimized_results[m]['accuracy'])
        elif metric == 'Precision':
            before_vals.append(baseline_results[m]['precision_weighted'])
            after_vals.append(optimized_results[m]['precision_weighted'])
        elif metric == 'Recall':
            before_vals.append(baseline_results[m]['recall_weighted'])
            after_vals.append(optimized_results[m]['recall_weighted'])
        elif metric == 'F1-Score':
            before_vals.append(baseline_results[m]['f1_weighted'])
            after_vals.append(optimized_results[m]['f1_weighted'])
    
    ensemble_val = ensemble_results['accuracy'] if metric == 'Accuracy' else \
                   ensemble_results['precision_weighted'] if metric == 'Precision' else \
                   ensemble_results['recall_weighted'] if metric == 'Recall' else \
                   ensemble_results['f1_weighted']
    
    x = np.arange(len(models))
    width = 0.25
    
    bars1 = ax.bar(x - width, before_vals, width, label='Before Optimization', color='#e74c3c', alpha=0.8)
    bars2 = ax.bar(x, after_vals, width, label='After Optimization', color='#2ecc71', alpha=0.8)
    bars3 = ax.bar(x + width, [ensemble_val]*3, width, label='Ensemble', color='#3498db', alpha=0.8)
    
    ax.set_xlabel('Model', fontsize=11)
    ax.set_ylabel(metric, fontsize=11)
    ax.set_title(f'{metric} Comparison', fontsize=13, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(models, fontsize=10)
    ax.legend(fontsize=9)
    ax.set_ylim(0, 1.1)
    
    # Add value labels
    for bars in [bars1, bars2, bars3]:
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f'{height:.3f}', xy=(bar.get_x() + bar.get_width()/2, height),
                       xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=8)

plt.suptitle('Model Performance: Before vs After Optimization', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/performance_comparison.png', bbox_inches='tight')
plt.close()

# 2. Confusion Matrices
fig, axes = plt.subplots(2, 4, figsize=(24, 10))
all_results = [
    (baseline_results['SVM'], 'SVM\n(Before)'),
    (baseline_results['Random Forest'], 'RF\n(Before)'),
    (baseline_results['XGBoost'], 'XGBoost\n(Before)'),
    (optimized_results['SVM'], 'SVM\n(After)'),
    (optimized_results['Random Forest'], 'RF\n(After)'),
    (optimized_results['XGBoost'], 'XGBoost\n(After)'),
    (ensemble_results, 'Weighted\nEnsemble'),
]

for idx, (result, title) in enumerate(all_results):
    row = 0 if idx < 4 else 1
    col = idx if idx < 4 else idx - 4
    ax = axes[row][col]
    cm = result['confusion_matrix']
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax, 
                xticklabels=['Class 0', 'Class 1', 'Class 2'],
                yticklabels=['Class 0', 'Class 1', 'Class 2'])
    ax.set_title(title, fontsize=11, fontweight='bold')
    ax.set_xlabel('Predicted', fontsize=9)
    ax.set_ylabel('Actual', fontsize=9)

# Hide empty subplot
axes[1][3].axis('off')

plt.suptitle('Confusion Matrices - All Models', fontsize=15, fontweight='bold')
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/confusion_matrices.png', bbox_inches='tight')
plt.close()

# 3. Per-class F1-Score comparison
fig, ax = plt.subplots(figsize=(14, 7))
class_labels = ['Class 0 (Level 1)', 'Class 1 (Level 2)', 'Class 2 (Level 3)']
model_labels = ['SVM\n(Before)', 'RF\n(Before)', 'XGB\n(Before)', 
                'SVM\n(After)', 'RF\n(After)', 'XGB\n(After)', 'Ensemble']
all_f1_per_class = []
for name in ['SVM', 'Random Forest', 'XGBoost']:
    all_f1_per_class.append(baseline_results[name]['f1_per_class'])
for name in ['SVM', 'Random Forest', 'XGBoost']:
    all_f1_per_class.append(optimized_results[name]['f1_per_class'])
all_f1_per_class.append(ensemble_results['f1_per_class'])

all_f1_per_class = np.array(all_f1_per_class)
x = np.arange(len(model_labels))
width = 0.25

for i, class_name in enumerate(class_labels):
    ax.bar(x + i*width, all_f1_per_class[:, i], width, label=class_name, alpha=0.85)

ax.set_xlabel('Model', fontsize=12)
ax.set_ylabel('F1-Score', fontsize=12)
ax.set_title('Per-Class F1-Score Comparison', fontsize=14, fontweight='bold')
ax.set_xticks(x + width)
ax.set_xticklabels(model_labels, fontsize=9)
ax.legend(fontsize=10)
ax.set_ylim(0, 1.15)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/per_class_f1_comparison.png', bbox_inches='tight')
plt.close()

# 4. Class distribution before and after SMOTE
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
train_counts = pd.Series(y_train).value_counts().sort_index()
smote_counts = pd.Series(y_train_smote).value_counts().sort_index()

axes[0].bar(train_counts.index, train_counts.values, color=['#e74c3c', '#3498db', '#2ecc71'], alpha=0.8)
axes[0].set_title('Before SMOTE', fontsize=13, fontweight='bold')
axes[0].set_xlabel('Class', fontsize=11)
axes[0].set_ylabel('Count', fontsize=11)
for i, v in enumerate(train_counts.values):
    axes[0].text(i, v+1, str(v), ha='center', fontsize=11, fontweight='bold')

axes[1].bar(smote_counts.index, smote_counts.values, color=['#e74c3c', '#3498db', '#2ecc71'], alpha=0.8)
axes[1].set_title('After SMOTE', fontsize=13, fontweight='bold')
axes[1].set_xlabel('Class', fontsize=11)
axes[1].set_ylabel('Count', fontsize=11)
for i, v in enumerate(smote_counts.values):
    axes[1].text(i, v+1, str(v), ha='center', fontsize=11, fontweight='bold')

plt.suptitle('Class Distribution: Before and After SMOTE', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/smote_distribution.png', bbox_inches='tight')
plt.close()

# 5. Radar chart for model comparison
fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))
categories = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'CV Mean']
N = len(categories)
angles = [n / float(N) * 2 * np.pi for n in range(N)]
angles += angles[:1]

radar_models = {
    'SVM (Before)': [baseline_results['SVM']['accuracy'], baseline_results['SVM']['precision_weighted'],
                     baseline_results['SVM']['recall_weighted'], baseline_results['SVM']['f1_weighted'],
                     baseline_results['SVM']['cv_mean']],
    'SVM (After)': [optimized_results['SVM']['accuracy'], optimized_results['SVM']['precision_weighted'],
                    optimized_results['SVM']['recall_weighted'], optimized_results['SVM']['f1_weighted'],
                    optimized_results['SVM']['cv_mean']],
    'RF (Before)': [baseline_results['Random Forest']['accuracy'], baseline_results['Random Forest']['precision_weighted'],
                    baseline_results['Random Forest']['recall_weighted'], baseline_results['Random Forest']['f1_weighted'],
                    baseline_results['Random Forest']['cv_mean']],
    'RF (After)': [optimized_results['Random Forest']['accuracy'], optimized_results['Random Forest']['precision_weighted'],
                   optimized_results['Random Forest']['recall_weighted'], optimized_results['Random Forest']['f1_weighted'],
                   optimized_results['Random Forest']['cv_mean']],
    'XGB (Before)': [baseline_results['XGBoost']['accuracy'], baseline_results['XGBoost']['precision_weighted'],
                     baseline_results['XGBoost']['recall_weighted'], baseline_results['XGBoost']['f1_weighted'],
                     baseline_results['XGBoost']['cv_mean']],
    'XGB (After)': [optimized_results['XGBoost']['accuracy'], optimized_results['XGBoost']['precision_weighted'],
                    optimized_results['XGBoost']['recall_weighted'], optimized_results['XGBoost']['f1_weighted'],
                    optimized_results['XGBoost']['cv_mean']],
    'Ensemble': [ensemble_results['accuracy'], ensemble_results['precision_weighted'],
                 ensemble_results['recall_weighted'], ensemble_results['f1_weighted'],
                 ensemble_results['cv_mean']]
}

colors = ['#e74c3c', '#ff6b6b', '#2ecc71', '#27ae60', '#3498db', '#2980b9', '#f39c12']
linestyles = ['--', '-', '--', '-', '--', '-', '-']

for (name, values), color, ls in zip(radar_models.items(), colors, linestyles):
    values += values[:1]
    ax.plot(angles, values, 'o-', linewidth=2, label=name, color=color, linestyle=ls)
    ax.fill(angles, values, alpha=0.05, color=color)

ax.set_xticks(angles[:-1])
ax.set_xticklabels(categories, fontsize=11)
ax.set_ylim(0, 1.05)
ax.set_title('Model Performance Radar Chart', fontsize=14, fontweight='bold', pad=20)
ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=9)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/radar_chart.png', bbox_inches='tight')
plt.close()

# 6. Improvement chart
fig, ax = plt.subplots(figsize=(12, 6))
improvements = []
for name in ['SVM', 'Random Forest', 'XGBoost']:
    imp = {
        'Model': name,
        'Accuracy Δ': optimized_results[name]['accuracy'] - baseline_results[name]['accuracy'],
        'Precision Δ': optimized_results[name]['precision_weighted'] - baseline_results[name]['precision_weighted'],
        'Recall Δ': optimized_results[name]['recall_weighted'] - baseline_results[name]['recall_weighted'],
        'F1-Score Δ': optimized_results[name]['f1_weighted'] - baseline_results[name]['f1_weighted'],
    }
    improvements.append(imp)

imp_df = pd.DataFrame(improvements)
x = np.arange(len(models))
width = 0.2
metrics_imp = ['Accuracy Δ', 'Precision Δ', 'Recall Δ', 'F1-Score Δ']
colors_imp = ['#e74c3c', '#3498db', '#2ecc71', '#f39c12']

for i, (metric, color) in enumerate(zip(metrics_imp, colors_imp)):
    bars = ax.bar(x + i*width, imp_df[metric]*100, width, label=metric, color=color, alpha=0.85)
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{height:+.1f}%', xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3 if height >= 0 else -12), textcoords="offset points", 
                   ha='center', va='bottom', fontsize=8)

ax.set_xlabel('Model', fontsize=12)
ax.set_ylabel('Improvement (%)', fontsize=12)
ax.set_title('Performance Improvement After Optimization', fontsize=14, fontweight='bold')
ax.set_xticks(x + 1.5*width)
ax.set_xticklabels(models, fontsize=11)
ax.legend(fontsize=10)
ax.axhline(y=0, color='black', linewidth=0.5)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/improvement_chart.png', bbox_inches='tight')
plt.close()

# Save all results to JSON
results_summary = {
    'dataset_info': {
        'total_samples': int(X.shape[0]),
        'total_features': int(X.shape[1]),
        'train_samples': int(X_train.shape[0]),
        'test_samples': int(X_test.shape[0]),
        'class_distribution': {str(k): int(v) for k, v in y.value_counts().sort_index().items()}
    },
    'feature_selection': {
        'lasso_selected': len(lasso_selected_features),
        'rf_top_features': n_top,
        'rfe_final_features': len(final_selected_features),
        'final_features': final_selected_features
    },
    'smote': {
        'before': {str(k): int(v) for k, v in pd.Series(y_train).value_counts().sort_index().items()},
        'after': {str(k): int(v) for k, v in pd.Series(y_train_smote).value_counts().sort_index().items()}
    },
    'grid_search_best_params': {
        'SVM': svm_grid.best_params_,
        'Random Forest': rf_grid.best_params_,
        'XGBoost': {k: (str(v) if not isinstance(v, (int, float, str, bool, type(None))) else v) for k, v in xgb_grid.best_params_.items()}
    },
    'ensemble_weights': {
        'SVM': float(svm_w),
        'Random Forest': float(rf_w),
        'XGBoost': float(xgb_w)
    },
    'baseline_results': {name: {
        'accuracy': float(r['accuracy']),
        'precision': float(r['precision_weighted']),
        'recall': float(r['recall_weighted']),
        'f1_score': float(r['f1_weighted']),
        'cv_mean': float(r['cv_mean']),
        'cv_std': float(r['cv_std'])
    } for name, r in baseline_results.items()},
    'optimized_results': {name: {
        'accuracy': float(r['accuracy']),
        'precision': float(r['precision_weighted']),
        'recall': float(r['recall_weighted']),
        'f1_score': float(r['f1_weighted']),
        'cv_mean': float(r['cv_mean']),
        'cv_std': float(r['cv_std'])
    } for name, r in optimized_results.items()},
    'ensemble_results': {
        'accuracy': float(ensemble_results['accuracy']),
        'precision': float(ensemble_results['precision_weighted']),
        'recall': float(ensemble_results['recall_weighted']),
        'f1_score': float(ensemble_results['f1_weighted']),
        'cv_mean': float(ensemble_results['cv_mean']),
        'cv_std': float(ensemble_results['cv_std'])
    }
}

with open(f'{RESULTS_DIR}/results_summary.json', 'w') as f:
    json.dump(results_summary, f, indent=2)

print("\n" + "="*70)
print("ALL PHASES COMPLETED SUCCESSFULLY!")
print("="*70)
print(f"\nResults saved to: {RESULTS_DIR}/")
print("Files generated:")
print("  - comparison_results.csv")
print("  - results_summary.json")
print("  - performance_comparison.png")
print("  - confusion_matrices.png")
print("  - per_class_f1_comparison.png")
print("  - smote_distribution.png")
print("  - radar_chart.png")
print("  - improvement_chart.png")
print("  - rfe_feature_selection.png")
print("  - feature_importance.png")
