"""
Create journal-quality figures for the second experiment (raw 33-feature dataset)
Figures numbered 6-10 to continue from the existing paper
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import os

# Set journal-quality style
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'axes.spines.top': False,
    'axes.spines.right': False,
})

RESULTS_DIR = '/home/ubuntu/journal_figures'
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# DATA FROM THE EXPERIMENT
# ============================================================

# Feature importance (top 22 selected features from RF)
features_importance = {
    '25ChildBlank_staring': 0.0550,
    'Age': 0.0522,
    '16Child_Repetitive_behaviors': 0.0476,
    '23ChildRepetitive_manipulation': 0.0474,
    '8ChildVocabulary_size': 0.0436,
    '2ChildEye_contact': 0.0431,
    '11ChildSensory_seeking': 0.0424,
    '20ChildFinger_move': 0.0400,
    'No_OfChild': 0.0377,
    '13Child_walkONtiptoe': 0.0377,
    '4ChildSpeech_clarity': 0.0367,
    '6ChildJoint_attention': 0.0349,
    '10ChildShared_attention': 0.0348,
    'Seq_ofChild': 0.0330,
    '22ChildFocused_attention': 0.0330,
    '24ChildNoise_sensitivity': 0.0327,
    '21ChildChecks_reactions': 0.0284,
    '7ChildRestriced_interests': 0.0284,
    '17ChildFirst_words': 0.0280,
    '12ChildHand_prompting': 0.0259,
    '5ChildRequest_pointing': 0.0249,
    '9ChildSymbolic_play': 0.0236,
}

# Feature selection pipeline numbers
pipeline_stages = {
    'Original\nFeatures': 33,
    'After\nLASSO': 31,
    'After RF\nImportance\n(Top 30)': 30,
    'After\nRFE': 22
}

# Model results
baseline = {
    'SVM': {'acc': 0.6471, 'prec': 0.6440, 'rec': 0.6471, 'f1': 0.6453, 'cv': 0.6177},
    'RF': {'acc': 0.5147, 'prec': 0.5103, 'rec': 0.5147, 'f1': 0.5092, 'cv': 0.6033},
    'XGB': {'acc': 0.5588, 'prec': 0.5618, 'rec': 0.5588, 'f1': 0.5601, 'cv': 0.5335},
}

optimized = {
    'SVM': {'acc': 0.7059, 'prec': 0.7018, 'rec': 0.7059, 'f1': 0.7010, 'cv': 0.6325},
    'RF': {'acc': 0.5882, 'prec': 0.5766, 'rec': 0.5882, 'f1': 0.5804, 'cv': 0.6255},
    'XGB': {'acc': 0.5441, 'prec': 0.5502, 'rec': 0.5441, 'f1': 0.5414, 'cv': 0.5974},
}

ensemble = {'acc': 0.6029, 'prec': 0.5934, 'rec': 0.6029, 'f1': 0.5965, 'cv': 0.6113}

# Confusion matrices
cm_baseline = {
    'SVM': np.array([[16, 4, 1], [6, 12, 6], [0, 7, 16]]),
    'RF': np.array([[11, 7, 3], [7, 8, 9], [0, 7, 16]]),
    'XGB': np.array([[12, 8, 1], [8, 10, 6], [0, 7, 16]]),
}

cm_optimized = {
    'SVM': np.array([[17, 3, 1], [6, 13, 5], [1, 4, 18]]),
    'RF': np.array([[16, 3, 2], [7, 9, 8], [0, 8, 15]]),
    'XGB': np.array([[9, 10, 2], [6, 11, 7], [0, 6, 17]]),
}

cm_ensemble = np.array([[13, 6, 2], [8, 10, 6], [0, 5, 18]])

# Per-class F1 scores
f1_per_class_baseline = {
    'SVM': [0.74, 0.51, 0.70],
    'RF': [0.56, 0.35, 0.63],
    'XGB': [0.59, 0.41, 0.70],
}

f1_per_class_optimized = {
    'SVM': [0.76, 0.59, 0.77],
    'RF': [0.73, 0.41, 0.62],
    'XGB': [0.50, 0.43, 0.69],
}

f1_per_class_ensemble = [0.62, 0.44, 0.73]

# SMOTE distribution
smote_before = {0: 83, 1: 95, 2: 94}
smote_after = {0: 95, 1: 95, 2: 95}

# Grid Search best params
best_params = {
    'SVM': 'C=10, gamma=0.01, kernel=rbf',
    'RF': 'max_depth=5, min_samples_leaf=2, min_samples_split=10, n_estimators=100',
    'XGB': 'colsample_bytree=0.8, learning_rate=0.2, max_depth=10, n_estimators=500, subsample=0.8'
}

# Color scheme (consistent, professional)
colors = {
    'before': '#2196F3',  # Blue
    'after': '#4CAF50',   # Green
    'ensemble': '#FF9800', # Orange
    'class0': '#E91E63',  # Pink
    'class1': '#3F51B5',  # Indigo
    'class2': '#009688',  # Teal
}

# ============================================================
# FIGURE 6: Feature Selection Pipeline + Feature Importance
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(14, 6), gridspec_kw={'width_ratios': [1, 1.3]})

# (a) Feature Selection Pipeline
ax = axes[0]
stages = list(pipeline_stages.keys())
values = list(pipeline_stages.values())
reductions = ['', '-6.1%', '-3.2%', '-26.7%']
bar_colors = ['#78909C', '#42A5F5', '#66BB6A', '#EF5350']

bars = ax.bar(range(len(stages)), values, color=bar_colors, width=0.6, edgecolor='white', linewidth=1.5)
for i, (bar, val, red) in enumerate(zip(bars, values, reductions)):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, 
            str(val), ha='center', va='bottom', fontweight='bold', fontsize=12)
    if red:
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height()/2, 
                red, ha='center', va='center', fontsize=9, color='white', fontweight='bold')

# Draw arrows
for i in range(len(stages)-1):
    ax.annotate('', xy=(i+0.7, values[i+1]+1), xytext=(i+0.3, values[i]-1),
                arrowprops=dict(arrowstyle='->', color='gray', lw=1.5))

ax.set_xticks(range(len(stages)))
ax.set_xticklabels(stages, fontsize=9)
ax.set_ylabel('Number of Features', fontsize=12)
ax.set_title('(a) Hybrid Feature Selection Pipeline', fontsize=13, fontweight='bold')
ax.set_ylim(0, 40)

# (b) Feature Importance
ax = axes[1]
feat_names = list(features_importance.keys())[::-1]  # Reverse for horizontal bar
feat_vals = [features_importance[f] for f in feat_names]

# Color gradient
n = len(feat_names)
cmap = plt.cm.RdYlGn
norm_vals = np.linspace(0.3, 0.9, n)
bar_colors_feat = [cmap(v) for v in norm_vals]

bars = ax.barh(range(n), feat_vals, color=bar_colors_feat, edgecolor='white', linewidth=0.5, height=0.7)
ax.set_yticks(range(n))
ax.set_yticklabels(feat_names, fontsize=8)
ax.set_xlabel('Feature Importance (Random Forest)', fontsize=11)
ax.set_title('(b) Top 22 Selected Features (RFE)', fontsize=13, fontweight='bold')

plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/fig6_feature_selection.png', bbox_inches='tight')
plt.close()
print("Figure 6 saved.")

# ============================================================
# FIGURE 7: Test Accuracy and CV Accuracy Comparison
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

models = ['SVM', 'RF', 'XGB']
x = np.arange(len(models))
width = 0.3

# (a) Test Accuracy
ax = axes[0]
before_acc = [baseline[m]['acc'] for m in models]
after_acc = [optimized[m]['acc'] for m in models]

bars1 = ax.bar(x - width/2, before_acc, width, label='Before Optimization', color=colors['before'], alpha=0.85, edgecolor='white')
bars2 = ax.bar(x + width/2, after_acc, width, label='After Optimization', color=colors['after'], alpha=0.85, edgecolor='white')
ax.axhline(y=ensemble['acc'], color=colors['ensemble'], linestyle='--', linewidth=2, label=f'Ensemble ({ensemble["acc"]:.3f})')

for bars in [bars1, bars2]:
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.005, f'{h:.3f}', ha='center', va='bottom', fontsize=9)

ax.set_ylabel('Test Accuracy', fontsize=12)
ax.set_title('(a) Test Set Accuracy', fontsize=13, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(models, fontsize=11)
ax.set_ylim(0.4, 0.85)
ax.legend(fontsize=9, loc='upper left')

# (b) CV Accuracy
ax = axes[1]
before_cv = [baseline[m]['cv'] for m in models]
after_cv = [optimized[m]['cv'] for m in models]

bars1 = ax.bar(x - width/2, before_cv, width, label='Before Optimization', color=colors['before'], alpha=0.85, edgecolor='white')
bars2 = ax.bar(x + width/2, after_cv, width, label='After Optimization', color=colors['after'], alpha=0.85, edgecolor='white')
ax.axhline(y=ensemble['cv'], color=colors['ensemble'], linestyle='--', linewidth=2, label=f'Ensemble ({ensemble["cv"]:.3f})')

for bars in [bars1, bars2]:
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.005, f'{h:.3f}', ha='center', va='bottom', fontsize=9)

ax.set_ylabel('10-Fold CV Accuracy', fontsize=12)
ax.set_title('(b) Cross-Validation Accuracy', fontsize=13, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(models, fontsize=11)
ax.set_ylim(0.4, 0.85)
ax.legend(fontsize=9, loc='upper left')

plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/fig7_acc_cv.png', bbox_inches='tight')
plt.close()
print("Figure 7 saved.")

# ============================================================
# FIGURE 8: Confusion Matrices (Before and After)
# ============================================================
fig, axes = plt.subplots(2, 4, figsize=(18, 9))
class_labels = ['Class 0\n(Mild)', 'Class 1\n(Moderate)', 'Class 2\n(Severe)']

# Row 1: Baseline
for i, (name, cm) in enumerate(cm_baseline.items()):
    ax = axes[0][i]
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=class_labels, yticklabels=class_labels,
                cbar=False, linewidths=1, linecolor='white',
                annot_kws={'size': 14, 'fontweight': 'bold'})
    ax.set_title(f'{name}\n(Before Optimization)', fontsize=11, fontweight='bold')
    ax.set_xlabel('Predicted', fontsize=10)
    ax.set_ylabel('Actual', fontsize=10)

# Row 2: Optimized
for i, (name, cm) in enumerate(cm_optimized.items()):
    ax = axes[1][i]
    sns.heatmap(cm, annot=True, fmt='d', cmap='Greens', ax=ax,
                xticklabels=class_labels, yticklabels=class_labels,
                cbar=False, linewidths=1, linecolor='white',
                annot_kws={'size': 14, 'fontweight': 'bold'})
    ax.set_title(f'{name}\n(After Optimization)', fontsize=11, fontweight='bold')
    ax.set_xlabel('Predicted', fontsize=10)
    ax.set_ylabel('Actual', fontsize=10)

# Ensemble
ax = axes[0][3]
sns.heatmap(cm_ensemble, annot=True, fmt='d', cmap='Oranges', ax=ax,
            xticklabels=class_labels, yticklabels=class_labels,
            cbar=False, linewidths=1, linecolor='white',
            annot_kws={'size': 14, 'fontweight': 'bold'})
ax.set_title('Weighted Ensemble', fontsize=11, fontweight='bold')
ax.set_xlabel('Predicted', fontsize=10)
ax.set_ylabel('Actual', fontsize=10)

axes[1][3].axis('off')

plt.suptitle('Confusion Matrices: Raw Data Experiment', fontsize=14, fontweight='bold', y=1.01)
plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/fig8_confusion.png', bbox_inches='tight')
plt.close()
print("Figure 8 saved.")

# ============================================================
# FIGURE 9: Per-Class F1-Score Heatmap
# ============================================================
fig, ax = plt.subplots(figsize=(8, 6))

model_labels = ['SVM (Before)', 'RF (Before)', 'XGB (Before)',
                'SVM (After)', 'RF (After)', 'XGB (After)', 'Ensemble']
class_names = ['Class 0 (Mild)', 'Class 1 (Moderate)', 'Class 2 (Severe)']

f1_data = np.array([
    f1_per_class_baseline['SVM'],
    f1_per_class_baseline['RF'],
    f1_per_class_baseline['XGB'],
    f1_per_class_optimized['SVM'],
    f1_per_class_optimized['RF'],
    f1_per_class_optimized['XGB'],
    f1_per_class_ensemble
])

sns.heatmap(f1_data, annot=True, fmt='.3f', cmap='RdYlGn', ax=ax,
            xticklabels=class_names, yticklabels=model_labels,
            linewidths=1.5, linecolor='white', vmin=0.3, vmax=0.85,
            annot_kws={'size': 12, 'fontweight': 'bold'})

# Add horizontal line to separate before/after
ax.axhline(y=3, color='black', linewidth=3)

ax.set_title('Per-Class F1-Score: Raw Data Experiment', fontsize=13, fontweight='bold')
ax.set_xlabel('', fontsize=1)
ax.set_ylabel('', fontsize=1)

plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/fig9_f1_heatmap.png', bbox_inches='tight')
plt.close()
print("Figure 9 saved.")

# ============================================================
# FIGURE 10: Comprehensive Comparison (Both Experiments)
# ============================================================
fig, ax = plt.subplots(figsize=(14, 6))

# Data from Experiment 1 (60 features, engineered)
exp1_optimized = {
    'SVM': 0.647, 'RF': 0.765, 'XGB': 0.721, 'Ensemble': 0.706
}

# Data from Experiment 2 (33 features, raw)
exp2_optimized = {
    'SVM': 0.706, 'RF': 0.588, 'XGB': 0.544, 'Ensemble': 0.603
}

model_names = ['SVM', 'Random Forest', 'XGBoost', 'Ensemble']
model_keys = ['SVM', 'RF', 'XGB', 'Ensemble']
x = np.arange(len(model_names))
width = 0.3

bars1 = ax.bar(x - width/2, [exp1_optimized[k] for k in model_keys], width,
               label='Experiment 1 (60 Engineered Features → 9)', color='#5C6BC0', alpha=0.85, edgecolor='white')
bars2 = ax.bar(x + width/2, [exp2_optimized[k] for k in model_keys], width,
               label='Experiment 2 (33 Raw Features → 22)', color='#26A69A', alpha=0.85, edgecolor='white')

for bars in [bars1, bars2]:
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.005, f'{h:.3f}', 
                ha='center', va='bottom', fontsize=10, fontweight='bold')

ax.set_ylabel('Test Accuracy (After Optimization)', fontsize=12)
ax.set_title('Cross-Experiment Comparison: Engineered vs. Raw Features', fontsize=14, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(model_names, fontsize=11)
ax.set_ylim(0.4, 0.9)
ax.legend(fontsize=11, loc='upper right')

plt.tight_layout()
plt.savefig(f'{RESULTS_DIR}/fig10_cross_experiment.png', bbox_inches='tight')
plt.close()
print("Figure 10 saved.")

print("\nAll journal figures generated successfully!")
print(f"Saved to: {RESULTS_DIR}/")
