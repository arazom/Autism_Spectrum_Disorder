import pandas as pd
import numpy as np

# Load data
df = pd.read_excel('/home/ubuntu/upload/1CLSnewDatNOsum.xlsx')

print("="*60)
print("DATASET OVERVIEW")
print("="*60)
print(f"Shape: {df.shape}")
print(f"\nColumn names ({len(df.columns)}):")
for i, col in enumerate(df.columns):
    print(f"  {i}: {col} (dtype: {df[col].dtype})")

print(f"\nFirst 5 rows:")
print(df.head())

print(f"\nLast 5 rows:")
print(df.tail())

print(f"\nBasic statistics:")
print(df.describe())

print(f"\nMissing values:")
print(df.isnull().sum()[df.isnull().sum() > 0])

print(f"\nTotal missing: {df.isnull().sum().sum()}")

# Check target variable
print(f"\n{'='*60}")
print("TARGET VARIABLE ANALYSIS")
print("="*60)
# Try to identify target column (usually last column or named 'class', 'label', etc.)
for col in df.columns:
    if df[col].nunique() <= 5:
        print(f"\nPotential target: '{col}' - unique values: {df[col].unique()} - counts:")
        print(df[col].value_counts())

print(f"\nData types summary:")
print(df.dtypes.value_counts())
